@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Voer eerst SETUP.cmd uit.
    pause
    exit /b 1
)
echo Installatie van PyTorch voor de NVIDIA-GPU. Download is enkele GB.
".venv\Scripts\python.exe" -m pip install torch==2.5.1+cu118 torchvision==0.20.1+cu118 --index-url https://download.pytorch.org/whl/cu118
if errorlevel 1 (
    echo Installatie mislukt. Bewaar de foutmelding.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-model.lock.txt
if errorlevel 1 (
    echo Installatie mislukt. Bewaar de foutmelding.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m nibbit doctor
pause
