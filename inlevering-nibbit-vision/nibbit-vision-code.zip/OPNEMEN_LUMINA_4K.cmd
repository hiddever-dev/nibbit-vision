@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Voer eerst SETUP.cmd uit.
    pause
    exit /b 1
)
echo Lumina-opname met de rechtstreeks opgeslagen camerabeelden: lumina-raw-v3
echo Laat camera, zoom en uitsnede gelijk aan de laatste foto met de papierstroken.
echo Sluit andere camera-apps. Kies de fysieke Raw-camera.
echo Preview toont de werkelijke resolutie; gewenst is 3840x2160.
echo Het cameranummer verschilt per computer. Controleer of je het lichtbord ziet.
echo Windows-cameraverbinding wordt automatisch geprobeerd op meerdere manieren.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0; probeer 1 of 2 als nodig]: "
".venv\Scripts\python.exe" -m nibbit capture --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-raw-v3 --output data/raw/lumina-raw-v3
pause
