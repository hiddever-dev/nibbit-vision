@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Voer eerst SETUP.cmd uit.
 pause
 exit /b 1
)
echo NIEUWE TRAININGSFOTOS - houd de 23 teststukken apart.
echo Lees STAPPEN_NIEUWE_TRAINING.txt voor je begint.
echo Maak eerst 1 leeg bord en 1 foto van alle nieuwe stukken los.
echo Daarna 20 paren: telkens onderstuk alleen, dan dezelfde onderstick met bovenstick.
echo S of spatie bewaart een foto; Q stopt. Wacht na neerleggen tot het beeld stabiel is.
echo Verander camera, zoom en helderheid tijdens de serie niet.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit capture --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-training-bright-v1 --output data/raw/training-bright-v1
pause
