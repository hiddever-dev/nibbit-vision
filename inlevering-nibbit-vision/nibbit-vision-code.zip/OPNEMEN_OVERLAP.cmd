@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Voer eerst SETUP.cmd uit.
    pause
    exit /b 1
)
echo Gecontroleerde overlapparen - dezelfde raw-v3-cameraopstelling
echo Maak per situatie eerst de onderste stick alleen en daarna de kruising.
echo Laat de onderste stick en de camera tussen die twee foto's liggen.
echo S of spatie bewaart een foto. Q sluit het cameravenster.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit capture --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-raw-v3 --output data/raw/overlap-pairs-v1
pause
