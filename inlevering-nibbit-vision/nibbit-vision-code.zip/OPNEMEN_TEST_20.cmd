@echo off
setlocal
cd /d "%~dp0"
echo Testserie met twintig sticks of stukken vanaf 5 mm.
echo Gebruik bij voorkeur nieuwe sticks die nog niet in eerdere foto's stonden.
echo Houd alles binnen de vier markeringen. Maximaal een bovenliggende stick per stick.
echo Bewaar eerst een foto zonder overlap, daarna vijf verschillende hopen.
echo S of spatie bewaart een foto. Q stopt. Laat de camera op zijn plek.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit capture --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-raw-v3 --output data/raw/challenge-20-v1
pause
