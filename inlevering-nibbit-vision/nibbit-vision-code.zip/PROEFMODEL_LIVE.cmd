@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Voer eerst SETUP.cmd en INSTALL_MODEL.cmd uit.
    pause
    exit /b 1
)
if not exist "runs\pilot-synthetic-01\best.pt" (
    echo De gewichten van het eerste proefmodel zijn nog niet aanwezig.
    pause
    exit /b 1
)
echo EERSTE PROEFMODEL - getraind op synthetische overlap, nog geen betrouwbare docententest.
echo Gebruik dezelfde Lumina-opstelling en 4K-beeldkadering als de raw-v3-kalibratie.
echo Sluit andere camera-apps. Q stopt de live detectie.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit infer --weights runs/pilot-synthetic-01/best.pt --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-raw-v3 --calibration calibration/lumina-raw-v3.json --output runs/pilot-live
pause
