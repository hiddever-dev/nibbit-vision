@echo off
setlocal
cd /d "%~dp0"
if not exist "runs\pilot-real-overlap-01\best.pt" (
 echo Het overlap-proefmodel ontbreekt nog.
 pause
 exit /b 1
)
echo OVERLAP-PROEFMODEL - nog geen geslaagde eindtest met 20 sticks.
echo Sluit andere camera-apps. Laat camera en lichtbord op hun plek. Q stopt.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit infer --weights runs/pilot-real-overlap-01/best.pt --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-raw-v3 --calibration calibration/lumina-raw-v3.json --output runs/real-overlap-live
pause
