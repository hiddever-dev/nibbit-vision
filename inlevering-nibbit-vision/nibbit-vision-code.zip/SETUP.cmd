@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>nul
if not errorlevel 1 (
    py -3.12 -m venv .venv
    if not errorlevel 1 goto install
)
echo Python 3.12 is nodig. Installeer Python 3.12 van python.org en start opnieuw.
pause
exit /b 1
:install
".venv\Scripts\python.exe" -m pip install -r requirements-base.lock.txt
if errorlevel 1 (
    echo Installatie mislukt. Bewaar de melding hierboven.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m nibbit doctor
echo.
echo Basis klaar. Open START_HIER.cmd. Modelbibliotheken kunnen later worden toegevoegd.
pause
