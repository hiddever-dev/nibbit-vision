@echo off
setlocal
cd /d "%~dp0"
if not exist "runs\bright-overlap-01\best.pt" (
 echo De nieuwe trainingsgewichten ontbreken nog.
 pause
 exit /b 1
)
echo NIEUW GETRAIND MODEL - nog te controleren op de volledige docententest.
echo Dubbele-maskerfilter V6 van 13 november. S bewaart een testbeeld.
echo Gebruik Lumina Camera Raw en dezelfde opstelling als de laatste trainingsfoto.
echo Laat lichtsterkte en camera staan. Sluit andere camera-apps. Q stopt.
echo Schaal door jou gecontroleerd. Bedekte vorm en lengte blijven schattingen.
echo De browser opent automatisch met scherpe tekst, nummers en een schuifbare tabel.
echo Houd sticks stil: laatste vijf analyses ondersteunen elkaar. Reset of R wist het geheugen.
echo Hussel de sticks, haal je handen weg en druk daarna op R.
echo Gebruik Foto opslaan of S. Afsluiten of Q stopt de verwerking.
set "cameraIndex=0"
set /p "cameraIndex=Camera-index [Enter voor 0]: "
".venv\Scripts\python.exe" -m nibbit infer --weights runs/bright-overlap-01/best.pt --threshold 0.3 --camera %cameraIndex% --width 3840 --height 2160 --setup-id lumina-training-bright-v1 --calibration calibration/lumina-training-bright-v1.json --output runs/bright-live
pause
