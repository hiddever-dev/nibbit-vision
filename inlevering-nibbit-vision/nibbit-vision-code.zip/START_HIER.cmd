@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Voer eerst SETUP.cmd uit.
    pause
    exit /b 1
)
echo Nibbit Vision - startversie, nog geen getraind Nibbit-model
echo 1. Kunstmatig softwarevoorbeeld maken, zonder camera
echo 2. Camerabeeld en foto's opslaan, zonder detectie
echo 3. Installatie controleren
set /p "taskChoice=Kies 1, 2 of 3: "
if "%taskChoice%"=="1" (
    ".venv\Scripts\python.exe" -m nibbit demo
    if not errorlevel 1 start "" "runs\software-demo\synthetic_measurement.png"
)
if "%taskChoice%"=="2" (
    set /p "cameraIndex=Camera-index [0 voor de huidige Lumina; probeer zo nodig 1 of 2]: "
    call :camera
)
if "%taskChoice%"=="3" ".venv\Scripts\python.exe" -m nibbit doctor
pause
exit /b
:camera
if not defined cameraIndex set "cameraIndex=0"
".venv\Scripts\python.exe" -m nibbit capture --camera %cameraIndex%
exit /b
