# Dataset

Pak de dataset-ZIP uit in de hoofdmap van de repository. De map `data/` moet naast `nibbit/` staan. Bewaar de onderlinge mappenstructuur: annotaties verwijzen ook naar afbeeldingen in naastgelegen datasets.

| Annotatiebestand onder data/ | Beelden | Instanties | Gebruik |
|---|---:|---:|---|
| bright-training-v1/annotations.json | 149 | 1573 | Definitieve trainingsinvoer: 148 train, 1 validatie |
| bright-real-v1/annotations.json | 44 | 93 | Echte bronbeelden voor deze trainingsinvoer |
| real-overlap-v1/annotations.json | 5 | 57 | Gecontroleerde echte overlapparen |
| synthetic-pilot-v1/annotations.json | 120 | 1691 | Eerste training, initialisatie definitief model |
| isolated-raw-v3/annotations.json | 5 | 50 | Vijf opnamen van dezelfde tien fysieke sticks |
| challenge-evaluation-v1/annotations.json | 1 | 23 | Geannoteerd diagnostisch beeld |

Dit zijn overlappende verzamelingen, geen optelbare aantallen unieke foto's. De definitieve invoer bevat 100 samengestelde beelden en 49 echte beelden. `raw/` bevat ook niet-geannoteerde opnamen. Voorstellen en reviewbestanden zijn geen gecontroleerde eindannotaties. Het archief bewaart deze bestanden voor herkomst en verdere ontwikkeling.

## Annotatieformaat

JSON `schema_version: 1`, met een lijst `images`. Ieder beeld heeft `file` (relatief aan het JSON-bestand), `size`, `group_id` en `instances`. Een instantie heeft een `id`, `status` (`visible` of `occluded`), `z_order`, `amodal` en `visible` polygonen. Polygonen bestaan uit beeldcoordinaten [x,y]. `amodal` omvat de geschatte verborgen contour; `visible` bevat alleen zichtbare delen. Gescheiden zichtbare delen van dezelfde stick blijven een instantie. Afgebroken, losliggende stukken zijn afzonderlijke instanties.

Verborgen contouren in echte overlapbeelden zijn geschat; samengestelde beelden hebben bekende bronmaskers. Kalibratie en de grens van 5 mm worden bij detectie toegepast, niet als vaste pixeloppervlaktegrens in deze annotaties.

## Scheiding en beperkingen

Beelden met dezelfde fysieke sticks horen bij dezelfde groep. Houd groepen en hun samengestelde afgeleiden binnen dezelfde partitie. De vijf eerdere overlapparen gebruiken per paar andere sticks. De challenge-serie gebruikt steeds dezelfde 23 stukken. Deze challengebeelden zijn al gebruikt voor foutanalyse en vormen geen onaangeroerde eindtest meer. De validatieset van het definitieve model bevat slechts een beeld met tien sticks. Test voor de demo ook met nieuwe sticks en nieuwe schikkingen.

Controleer met `python -m nibbit validate --annotations data/bright-training-v1/annotations.json`. De meegeleverde code controleert onder andere beeldpaden, polygonen, zichtbare maskers en overlapvolgorde.
