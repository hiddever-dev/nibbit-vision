# Nibbit Vision

Startrepository voor de opdracht: afzonderlijke Nibbit sticks segmenteren, inclusief
delen achter een andere stick, hun zichtbaarheid bepalen en de geprojecteerde
middenlijnlengte meten. Deadline: dinsdag 17 november 2026.

**Status: ontwikkelversie met eerste echte proefdata en voorlopige kalibratie.**
De eerste dataset bevat vijf nieuwe foto's met vijftig maskers van tien fysieke
sticks. Er is een eerste model op synthetische overlap getraind. Het vindt tien
objecten in een echte foto met tien losse sticks, maar geeft vijf voorspellingen
voor een echte kruising van twee sticks. Echte overlap is dus nog niet betrouwbaar.
Prestaties op de docententest zijn nog niet aangetoond. De eenvoudige kunstmatige voorbeeldvormen
onder `examples` controleren alleen de software. Zie de actuele voortgang onderaan.

## Wat kan nu al, zonder sticks of kalibratie?

- De installatie controleren.
- Kunstmatige voorbeeldmaskers verwerken en het resultaat bekijken.
- Met een aangesloten kleurenwebcam originele foto's opslaan (PNG plus metadata).
- Annotaties tekenen en controleren op formaat, zichtbaarheid en overlapregels.
- De modelketen testen met willekeurige gewichten, zonder herkenningsclaims.

Foto- en livedetectie vereisen zelf getrainde gewichten. Zonder kalibratie blijven
alle lengtes in pixels en is `length_mm` leeg (`null`). De software verzint geen
pixels-per-mm-factor en dwingt geen totaal van twintig detecties af.

## Starten op Windows

1. Houd de volledige projectmap bij elkaar, ook als je de ZIP uitpakt.
2. Dubbelklik op **SETUP.cmd**. Dit maakt een aparte `.venv` en installeert de
   vastgelegde beeldbibliotheken. Internet is nodig. Er worden geen globale
   Python-pakketten aangepast.
3. Dubbelklik op **START_HIER.cmd** en kies **1** voor het softwarevoorbeeld.
4. Kies **2** voor camera-preview. Probeer camera-index 0, 1 of 2 totdat je de
   Lumina ziet. De index is geen vaste cameranaam en kan na opnieuw aansluiten wijzigen.
5. In het cameravenster: **S** of **spatie** slaat een oorspronkelijke foto op;
   **Q** of **Esc** sluit af. Foto's staan in `data/raw`.

De setup gebruikt Python 3.12 via de Windows Python Launcher. Op een andere computer: installeer Python 3.12 van python.org als
de setup daarom vraagt. Geen administratorrechten nodig voor deze projectomgeving.
De code probeert Windows DirectShow, Media Foundation en automatische selectie
als de eerste methode geen beeld levert. Het cameranummer blijft daarbij gelijk.
Met `--backend dshow`, `msmf` of `any` kun je een methode expliciet kiezen.
Op deze laptop is op 12 november vastgesteld dat de actieve Lumina **camera 0**
is; de ingebouwde camera staat uitgeschakeld. De Lumina leverde bij de controle
daadwerkelijk 3840 x 2160 pixels. OPNEMEN_LUMINA_4K.cmd kiest nu standaard index 0.

Gebruik bij de Lumina de fysieke **Lumina Camera - Raw**. Zet automatische framing,
zoom en effecten uit, ook in eventueel aanwezige Lumina-software. Kies een vaste
opstelling en gelijkmatige belichting. De aangevraagde resolutie kan afwijken van
de geleverde resolutie: preview en metadata tonen de werkelijke afmetingen.
Sluit Camera, Teams en andere camera-apps voordat je de opnamefunctie opent.

## Opdrachten vanuit PowerShell

Open een terminal in deze projectmap. Gebruik steeds de lokale Python:

```powershell
.\.venv\Scripts\python.exe -m nibbit doctor
.\.venv\Scripts\python.exe -m nibbit camera-check --camera 0 --width 3840 --height 2160
.\.venv\Scripts\python.exe -m nibbit demo
.\.venv\Scripts\python.exe -m nibbit capture --camera 1 --width 1920 --height 1080 --setup-id lab-v1
```

Optioneel 4K aanvragen: `--width 3840 --height 2160`. Controleer de daadwerkelijk
ontvangen resolutie en de scherpte. Een screenshot is geen originele datasetopname.

## Later: dataset annoteren

Sla de beelden eerst op in `data/raw`. Teken de hele vorm van elk fysiek object,
inclusief het verborgen deel, als één instance. De amodale maskers van twee sticks
mogen dezelfde pixels bevatten. Een bedekte stick heeft daarnaast een zichtbaar
masker dat uit meerdere losse polygonen mag bestaan, maar nog steeds bij diezelfde
instance hoort.

```powershell
.\.venv\Scripts\python.exe -m nibbit annotate --image data/raw/foto.png --annotations data/annotations.json --group-id sessie-01-bronset-A
```

Bediening van de eenvoudige annotator:

- Teken **onderste sticks vóór bovenste sticks**. Later getekend betekent hoger
  in de stapel (`z_order`). Niet-overlappende sticks mogen in willekeurige volgorde.
- Klik rondom de volledige stick; **Enter** sluit een polygoon.
- Bij een volledig zichtbare stick: **V** slaat die stick op. Het zichtbare masker
  is dan gelijk aan het volledige masker.
- Bij een bedekte stick: teken eerst het volledige masker en druk **O**. Teken
  daarna de zichtbare stukken, ieder afsluiten met **Enter**, en druk **C**.
- **Backspace** verwijdert het laatste huidige punt, **R** reset de huidige stick,
  **D** verwijdert de laatst toegevoegde stick.
- **S** slaat de afbeelding met alle voltooide sticks op. **Q/Esc** annuleert zonder
  op te slaan. Een bestaande afbeelding wordt geladen en bij S bijgewerkt.

```powershell
.\.venv\Scripts\python.exe -m nibbit validate --annotations data/annotations.json
```

Annotaties gebruiken JSON-schema versie 1, met `images` en per afbeelding:
`file` (relatief aan het annotatiebestand), `size: [breedte, hoogte]`, `group_id`,
`instances`. Iedere instance bevat `id`, `status` (`visible`/`occluded`), `z_order`,
`amodal` en `visible`. Die laatste twee zijn lijsten van polygonen; een polygoon
is een lijst `[x,y]`-punten. Het gegenereerde `runs/software-demo/annotations.json`
is een volledig formaatvoorbeeld.

**Datakwaliteit:** gebruik voor training gecontroleerde volledige vormen. Maak
beeldparen vóór en na het neerleggen van een bovenliggende stick zonder de onderste
te verschuiven. Verborgen afgebroken uiteinden zijn niet altijd objectief afleidbaar;
verzin daar geen zekere ground truth voor. Volledig onzichtbare objecten vallen
buiten deze baseline. Een foreground-masker van de hele hoop is geen instance-annotatie.

`group_id` voorkomt dat sterk verwante beelden willekeurig worden verdeeld.
Gebruik dezelfde group-id voor alle varianten met dezelfde fysieke bronsticks,
uitsneden en opnameserie. Een nieuw nummer op een bijna identiek frame maakt het
geen onafhankelijke test. Reserveer aparte sticks/opnames voor de testset.

Stukken/zichtbare segmenten onder 5 mm mogen volgens de opdracht worden genegeerd.
De eerste annotaties kunnen daarom voorlopige voorbeelden zijn; leg de uiteindelijke
selectie later vast met echte maatvoering. De code koppelt zichtbare stukjes niet
als nieuwe losse objecten: de volledige stick is het trainingsdoel. Bij inferentie
worden alleen volledige objecten met een geldige gemeten lengte onder 5 mm gefilterd.
Zonder kalibratie wordt geen 5mm-filter toegepast.

## Later: model trainen en onafhankelijk testen

Dubbelklik **INSTALL_MODEL.cmd** om de NVIDIA/CUDA 11.8-versie van PyTorch te
installeren (enkele GB). Controleer met `doctor` of CUDA beschikbaar is. Deze
softwareversies zijn bewust vastgezet. Er hoeft geen aparte CUDA Toolkit te worden
geïnstalleerd voor de officiële PyTorch-wheels. CPU-alternatief:

```powershell
.\.venv\Scripts\python.exe -m pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements-model.lock.txt
```

```powershell
.\.venv\Scripts\python.exe -m nibbit train --annotations data/annotations.json --output runs/train-01 --epochs 20
```

De eerste training downloadt COCO-startgewichten. Het model is Mask R-CNN ResNet50
FPN met drie uitgangen: achtergrond, zichtbare stick, bedekte stick. Het leert
**amodale maskers uit de eigen volledige annotaties**. SAM en oriented bounding
boxes worden niet gebruikt. Het model gebruikt intern gewone rechthoekige voorstellen;
de uiteindelijke vorm komt uit pixelmaskers.

De eerste echte serie met dezelfde tien hergebruikte sticks heeft terecht één
brongroep en is op zichzelf niet onafhankelijk in train/validatie te verdelen.
Voor de pilot zijn acht fysieke bronsticks voor training en twee andere voor
synthetische validatie geselecteerd, vóór het maken van overlapbeelden.
De generator gebruikt uitsluitend de eerste foto, zodat dezelfde stick niet via
een ander gezichtspunt in de andere datasethelft belandt:

```powershell
.\.venv\Scripts\python.exe scripts/prepare_isolated_sticks.py
# Voor de reeds beoordeelde labels staat annotations.json naast de voorstellen.
.\.venv\Scripts\python.exe scripts/generate_overlap_dataset.py --annotations data/isolated-raw-v3/annotations.json --output data/synthetic-pilot-v1
.\.venv\Scripts\python.exe -m nibbit train --annotations data/synthetic-pilot-v1/annotations.json --output runs/pilot-synthetic-01 --epochs 5 --min-size 384 --max-size 640 --device cuda
```

Een bestaande synthetische dataset wordt niet overschreven. Kies bij herhaling
een nieuwe uitvoermap. Deze pilot gebruikt 100 trainbeelden en 20 validatiebeelden,
met 8-20 objecten per beeld. De bekende synthetische laagvolgorde levert volledige
maskers, zichtbare maskers en overlapstatus. Ieder object heeft maximaal één
bedekkende stick. Foto's van dezelfde tien fysieke sticks mogen later niet als
een onafhankelijke real-world test van dit model worden opgevoerd.

Batchgrootte 1 en gradiëntaccumulatie 2 beperken het geheugengebruik. Bij onvoldoende
GPU-geheugen: probeer `--min-size 384 --max-size 640`; dit kan kleine fragmenten
minder goed herkenbaar maken. Snelheid en kwaliteit op de echte labdata zijn nog onbekend.

Een vaste seed en groepsverdeling maken de experimenten herhaalbaar; bit-identieke
GPU-resultaten worden niet gegarandeerd. De trainingsmap bevat `split.json`,
`history.json` en `best.pt` (beste validatie-F1 op amodale masker-IoU >= 0.5).
Een bestaande `best.pt` wordt niet stilzwijgend overschreven. Gewichten bewaren de
trainingsconfiguratie, annotatie-hash en gebruikte ontwikkelgroepen.

```powershell
.\.venv\Scripts\python.exe -m nibbit evaluate --weights runs/train-01/best.pt --annotations data/test-annotations.json
```

De testgroepen mogen niet overlappen met training/validatie. Dit rapport bevat
missers, foutpositieven, masker-IoU en overlapstatus op gematchte objecten. Dit is
nog geen complete beoordeling: voeg voor de definitieve opdracht gemeten lengtes,
lengtefouten per zichtbaarheidscategorie, tellingen per hoop en live snelheid toe.

## Later: kalibratie toevoegen

Je hoeft hiervoor geen code om te schrijven. Maak in de definitieve opstelling
een foto van een **vlakke rechthoek met nauwkeurig bekende afmetingen**. Voorbeeld
voor een daadwerkelijk gemeten vlak van 250 bij 180 mm:

```powershell
.\.venv\Scripts\python.exe -m nibbit calibrate --image data/raw/meetvlak.png --width-mm 250 --height-mm 180 --setup-id lab-v1
```

Klik op de hoeken: linksboven, rechtsboven, rechtsonder, linksonder. Enter slaat
op; R reset; Q annuleert. De vier hoeken moeten op hetzelfde vlak liggen.
Gebruik werkelijke meetwaarden; een lichtbord met streepjes is niet automatisch
een betrouwbare referentie. Controleer met andere afstanden op meerdere plekken.

**Dit is een voorlopige vlakke homografie, geen volledige camerakalibratie.**
Lensvervorming en hoogteverschillen van de sticks worden nog niet gecorrigeerd.
Daarvoor zijn straks extra kalibratiebeelden en foutmetingen nodig. Meetnauwkeurigheid
is nog niet aangetoond. Na cameraverplaatsing, zoom, gewijzigde uitsnede of resolutie
moet je opnieuw kalibreren. De software controleert resolutie en setup-id, maar
kan een fysiek verschoven camera niet zelfstandig herkennen.

## Later: foto en live detectie

```powershell
# Geen kalibratie: alleen pixels
.\.venv\Scripts\python.exe -m nibbit infer --weights runs/train-01/best.pt --image data/raw/foto.png

# Vlakke meting in mm (nog valideren)
.\.venv\Scripts\python.exe -m nibbit infer --weights runs/train-01/best.pt --image data/raw/foto.png --calibration calibration/lab-v1.json --setup-id lab-v1

# Live met opgeslagen filmpje
.\.venv\Scripts\python.exe -m nibbit infer --weights runs/train-01/best.pt --camera 1 --record
```

Fotodetectie schrijft een ingetekende PNG, JSON met lengtes/status en een NPZ met
onafhankelijke binaire maskers. Liveopname schrijft MP4 en JSON met frame-tijdstippen.
Het filmpje speelt af op vaste 10 fps; de JSON bevat de werkelijke verwerkingstijden,
dus afspeelsnelheid is niet hetzelfde als werkelijk behaalde live snelheid.
IDs gelden binnen een frame en zijn geen tracking-IDs. Bestanden met dezelfde
fotonaam worden bij opnieuw uitvoeren bijgewerkt; gebruik een andere `--output`
als je alle experimenten wilt bewaren.

De middenlijn volgt de langste route door het geskeletoniseerde volledige masker,
met lichte verzachting van pixeltrapjes en verlenging naar de uiteinden. Dit is
een meetbaseline, geen bewezen metrologie. De code meet niet de totale lengte van
alle skeletzijtakken en gebruikt geen rechte lijn tussen de stickuiteinden.
Bij voldoende lange maskers worden terminale skeletvertakkingen naar hoekige
uiteinden verwijderd vóór de tangentverlenging. Dit voorkomt overmeting van
bijvoorbeeld rechte papierstroken met schuine snijranden.
Niet-aaneengesloten volledige maskers krijgen `disconnected_mask` en geen lengte;
ze worden niet stilzwijgend tot één fragment teruggebracht. Buiten het gekalibreerde
gebied en bij afsnijding aan de beeldrand wordt geen mm-lengte gerapporteerd.
Zeer sterk overlappende vrijwel identieke maskers kunnen door duplicaatonderdrukking
worden samengevoegd: neem bijna-parallelle sticks expliciet mee in de praktijktest.

## Softwarecontrole

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Controles: pixel/mm-scheiding, bekende schaal, kromme middenlijn, perspectief,
weigeren van losse volledige maskers, overlappende instance-maskers, foutieve
annotaties en groepsscheiding. Met PyTorch geïnstalleerd wordt ook een voorwaartse
en achterwaartse modelstap, opslaan/laden en inferentie met willekeurige gewichten
getest. Die test toont alleen dat de code aansluit, geen herkenningskwaliteit.

## Repository en uiteindelijke oplevering

Deze map is lokaal als Git-repository geïnitialiseerd. Een online Git-repository
is nog niet aangemaakt. De ZIP bevat de bronbestanden zonder verborgen Git-geschiedenis;
voer na uitpakken eventueel `git init` uit. De mappen data, runs en weights worden bewust niet automatisch
aan Git toegevoegd: bewaar dataset en gewichten via versiebeheer voor grote bestanden
of een aparte download, en documenteer downloadlocatie plus SHA256-controlesommen.
Gebruik een datasetversie en verander die niet onder bestaande experimenten.

Nog nodig voor de opdracht: echte dataset, kwaliteitscontrole van annotaties,
training en gewichten, definitieve kalibratie, tests met twintig onbekende sticks
inclusief breuken, lengtefouten, detectiebeelden, live filmpje, schone installatie
op een tweede omgeving en de fysieke demo met een zak Nibbits.

## Voortgang op 12 november

Het eerste proefmodel staat in `runs/pilot-synthetic-01/best.pt`. Het bijbehorende
rapport is `runs/pilot-synthetic-01/RESULTAAT.txt`, met datasetbeperkingen,
synthetische validatiematen en de mislukte proef op echte overlap. Op deze laptop
zijn de GPU-bibliotheken geïnstalleerd en de training is uitgevoerd op de RTX 3060.
`PROEFMODEL_LIVE.cmd` opent een voorlopige liveweergave. Sluit eerst andere
camera-apps; Q stopt de weergave. De pilot is nog onbetrouwbaar bij echte overlap
en de statische 4K-verwerking kost rond twee seconden per beeld.

Gebruik voor nieuwe gecontroleerde overlapparen `OPNEMEN_OVERLAP.cmd`. Die
bewaart beelden apart van de losse-sticks-serie, in `data/raw/overlap-pairs-v1`.
Maak per situatie twee foto's: onderste stick alleen, daarna met bovenste
stick zonder de onderste te verschuiven. Gebruik bij voorkeur andere fysieke
sticks dan de eerste tien, varieer kleuren en kruishoeken, en blijf binnen
de vier markeringen. Pak een bron-ZIP altijd uit; gewichten en data worden
apart geleverd en moeten voor overdracht op dezelfde relatieve paden komen.

De vijf nieuwe opnames staan met 50 zichtbare-instance-maskers in
`data/isolated-raw-v3/annotations.json`. `review/isolated-raw-v3/overzicht.jpg`
toont de visueel gecontroleerde eerste contourlabels. De markerafwijking is
minder dan één pixel. Vier objecten liggen deels buiten de meetzone en krijgen
geen mm-lengte, maar blijven bruikbaar voor segmentatie-annotatie.
De synthetische pilot staat in `data/synthetic-pilot-v1`; de bronverdeling is in
het annotatiebestand vastgelegd. Echte overlap, korte afgebroken fragmenten en
andere fysieke sticks moeten nog worden toegevoegd en getest.

**Actuele camerafeed: lumina-raw-v3.** De rechtstreekse opname heeft een andere
beeldkadering dan de eerder gestuurde foto's, ondanks dezelfde 4K-resolutie.
Gebruik nu `calibration/lumina-raw-v3.json` met `--setup-id lumina-raw-v3`.
`OPNEMEN_LUMINA_4K.cmd` slaat nieuwe foto's op in `data/raw/lumina-raw-v3`.
De vier vaste markeringen zijn opnieuw gelokaliseerd; hun fysieke afstanden
blijven 400 x 225 mm. De twee opgegeven 50mm-stroken meten in deze feed 49,63 mm
en 50,43 mm, zonder bijstellen op de stroken. Zie `calibration/ACTIVE_SETUP.txt`.
De waarden hieronder beschrijven de eerdere, anders gekaderde foto's.

De eerste acht echte opnames zijn opgeslagen in `data/session-2026-11-11` met
originele hashes en eerste, nog te controleren maskerannotaties.
De markerfoto hoort bij een licht gewijzigde beeldkadering, met een aparte
kalibratie `calibration/lumina-marked-v2.json` voor 400 x 225 mm. Gebruik hiervoor
`OPNEMEN_LUMINA_4K.cmd`. De kalibratie wordt niet automatisch op de oude serie toegepast.

Een onafhankelijke foto van twee door de gebruiker als 50 mm opgegeven stroken
levert 49,43 mm horizontaal en 50,27 mm verticaal. De bestaande kalibratie is daarbij
ongewijzigd gebleven. Dit is een eerste lokale schaalcontrole, geen aangetoonde
totale Nibbit-meetnauwkeurigheid. Zie `calibration/reference-check-50mm/RESULTAAT.txt`.

Bronnen: [PyTorch fine-tuning](https://docs.pytorch.org/tutorials/intermediate/torchvision_tutorial.html),
[vastgezette PyTorch-versies](https://pytorch.org/get-started/previous-versions/),
[OpenCV-kalibratie](https://docs.opencv.org/4.x/dc/dbb/tutorial_py_calibration.html),
[RobotExchange-projectaanpak](https://www.robotexchange.io/t/how-to-plan-a-basic-vision-based-quality-control-system/4748).


### Echte overlapserie 12 november

De gebruiker bevestigt andere fysieke sticks per voor/na-paar. Vijf groepen,
57 objectannotaties in de vijf na-foto's; vijf onderliggende sticks zijn bedekt.
`scripts/prepare_real_overlap.py` bewaart referenties, maakt labels en reviewbeelden.
De ruwe referentiefoto is alleen een annotatiehulpmiddel, geen modelinvoer bij detectie.
Verborgen vormen zijn benaderingen uit de referentiefoto; zichtbare contouren zijn
gecorrigeerd op het na-beeld. De gele bovenste stick gebruikt een handmatige ruimtelijke
hulplijn. Labels zijn voorlopig visueel gecontroleerd, geen perfecte meetwaarheid.

Vervolgtraining begint bij het synthetische proefmodel met een nieuwe optimizer.
De herkomst en eerdere ontwikkelgroepen blijven in het nieuwe gewichtsbestand staan.
Paren 1-4 zijn training; paar 5 is validatie. De validatiefoto is geen onafhankelijke
finale test nadat hij voor modelkeuze is gebruikt.

```powershell
.venv\Scripts\python.exe scripts/prepare_real_overlap.py
# annotations.json bevat de vastgelegde visuele controle en de train/val-splitsing.
.venv\Scripts\python.exe -m nibbit validate --annotations data/real-overlap-v1/annotations.json
.venv\Scripts\python.exe -m nibbit train --annotations data/real-overlap-v1/annotations.json --initial-weights runs/pilot-synthetic-01/best.pt --output runs/pilot-real-overlap-01 --epochs 20 --min-size 512 --max-size 960 --lr 0.00003 --device cuda
```


### Afzonderlijke testserie met 23 stukken

De tien challenge-opnames zijn gezamenlijk buiten de training gehouden.
De gebruiker bevestigt steeds dezelfde 23 stukken. Bekijk
`runs/challenge-review-v1/BEOORDELING.md` voor bevindingen en beperkingen.
De vier eerdere complexe beelden zijn aparte stresstests; de vier herziene
beelden zijn opdrachtkandidaten waarvan de volledige laagvolgorde nog niet
is geannoteerd. Er zijn geen betrouwbare maskerscores voor de hopen.

```powershell
.venv\Scripts\python.exe scripts/review_challenge.py
.venv\Scripts\python.exe scripts/score_isolated_challenge.py
```

De losse referentiefoto heeft 23 gecontroleerde silhouetlabels in
`data/challenge-evaluation-v1/annotations.json`. De overige beelden hebben
modelvoorspellingen en een kwalitatieve review, geen grondwaarheidmaskers.

### Uitbreiding met feller verlichte trainingsbeelden

`data/bright-real-v1/annotations.json` bevat de eerste visueel gecontroleerde
maskers van 44 nieuwe echte foto's: leeg bord, 30 losse stukken en 21
voor/na-paren. Alle nieuwe fysieke stukken blijven samen in een trainingsgroep.
De onderste volledige contour komt uit de referentie; de bovenste contour
wordt met geometrische interpolatie afgebakend. Dit zijn benaderende labels.

`data/bright-training-v1/annotations.json` combineert dit met 100 samengestelde
beelden op de werkelijke lege achtergrond en de eerdere echte overlapparen:
148 trainingsbeelden met 1563 instanties, 1 bestaande aparte validatiefoto.
De hele challenge-serie met 23 stukken blijft buiten training en modelkeuze.

Zie `review/training-bright-v1/REPRODUCEREN.txt` voor exacte opdrachten.
`START_GETRAIND_MODEL.cmd` opent de nieuwe versie nadat training klaar is.
De bijbehorende vlakke kalibratie is `calibration/lumina-training-bright-v1.json`;
400 x 225 mm, opgegeven tolerantie 5 mm, geen onafhankelijke nieuwe meetcontrole.

### Dubbele maskers en live foutbeelden (13 november)

**Actueel: V6 (`mask-dedup-v6-same-status-partials`).** De onderstaande regel
voor gedeeltelijk dubbele maskers geldt nu ook voor twee visible-voorstellen.
Op foutbeeld `113447_051009` overlapt het extra groene masker #21 voor 85,2%
met masker #17 (oppervlakteverhouding 78,5%). V5 controleerde dit alleen voor
occluded-voorstellen. V6 behoudt het sterkere masker ongewijzigd. Ook echte
bijna samenvallende sticks kunnen hiermee onterecht worden onderdrukt.
Reproductie: `scripts/review_live_v6.py`, uitvoer `runs/live-filter-v6`.
De 57 gelabelde ontwikkelinstanties houden dezelfde scores als V5.

Eerdere V5 (`mask-dedup-v5-partial-suppression`): een lager scorend
occlusievoorstel wordt ook onderdrukt als beide voorstellen occluded zijn,
het kleinere masker minstens de helft van het grotere oppervlak heeft en
minstens 80% van het kleinere overlapt. Het betrouwbaarste masker blijft
ongewijzigd: samenvoegen van de maskers verslechterde een gelabeld ontwikkelbeeld.
Bij vrijwel samenvallende echte sticks kan ook deze regel fout gaan.
Op nieuw foutbeeld `110337_695959` verandert de telling van 21 naar 20;
de lengte van de rode stick rechtsonder blijft onzeker. Geen nieuwe training.
`scripts/review_live_v5.py` herhaalt dit en de vier eerdere foutbeelden;
uitvoer staat in `runs/live-filter-v5`. Op de 57 gelabelde ontwikkelinstanties
blijft het resultaat gelijk aan V4: 57 TP, 6 FP, 0 FN, gemiddelde amodale IoU
0,8735 en status 56/57 correct. Dit zijn ontwikkelcontroles, geen onafhankelijke
eindtest of bewijs dat alle lengtes kloppen.

De eerdere V4-regels (`mask-dedup-v4-covered-proposals`) blijven actief. De live-starter gebruikt
`--threshold 0.3`. De rode stick rechtsonder op foutbeeld `104221_557595`
kreeg een voorstel met score circa 0,35 en verdween dus bij de eerdere grens 0,5.
Naast de onderstaande eerdere regels wordt een lager scorend voorstel verwijderd
als minstens 90% van zijn masker al door de unie van behouden maskers is bedekt,
ook als de status verschilt of het masker verbonden is. Afgewezen voorstellen
tellen niet mee in die unie. Er is geen limiet of afronding naar twintig sticks.
Een echt kort of bijna samenvallend object kan hierdoor eveneens verdwijnen;
dat blijft een beperking van deze heuristiek en moet apart worden getest.

`scripts/review_live_v4.py` herhaalt de vier gemelde ontwikkelfouten:
9 naar 8, 11 naar 10, 20 naar 20 en 23 naar 20. De eerder gemiste rode stick
is nu aanwezig. Uitvoer en bronhashes staan in `runs/live-filter-v4`.
Dit bewijst geen nauwkeurige volledige contouren: sommige uiteinden blijven
te kort en een occlusiemasker kan nog een los foutief stukje bevatten.
De modelgewichten zijn niet opnieuw getraind. Rechtstreeks `infer` blijft
standaard grens 0,5 gebruiken; geef `--threshold 0.3` op voor dezelfde selectie
als de live-starter. Historische resultaten veranderen daardoor niet achteraf.

Dezelfde modelgewichten gebruiken nu een aangepaste maskerfilter: van twee
maskers met IoU > 0,85 blijft de betrouwbaarste voorspelling over. Een lager
scorend klein masker (maximaal 25% van het grotere) dat voor minstens 98%
binnen een reeds behouden masker ligt, wordt ook onderdrukt. Normale
kruisingen blijven afzonderlijk. Dit is een heuristiek: een echt kort stukje
dat vrijwel volledig binnen een ander masker ligt kan ook verdwijnen.
Historische trainings- en challenge-resultaten van 12 november horen bij de
eerdere filter (IoU > 0,95), niet automatisch bij deze gewijzigde inferentie.
`scripts/check_duplicate_filter.py` vergelijkt beide filters op de vijf
bestaande ontwikkel-/validatiebeelden; dit is geen onafhankelijke eindtest.

Start de live-app opnieuw om wijzigingen te laden. S bewaart het oorspronkelijke
camerabeeld, detectiebeeld, maskers en meetgegevens in `runs/bright-live`.
Q sluit het venster. Een screenshot met ingetekende maskers is geen vervanging
voor een onbewerkt camerabeeld bij foutanalyse.

De tweede correctie op 13 november (`mask-dedup-v3-fragment-union`) richt zich
op gefragmenteerde extra maskers. Een masker is daarvoor gefragmenteerd als
de op een na grootste component minstens 4 pixels en 1% van het masker is.
Het wordt onderdrukt wanneer minstens 85% al door betrouwbaardere maskers
wordt bedekt en minstens 70% door een daarvan met dezelfde status. Verbonden
maskers vallen buiten deze extra regel. Ook dit kan bij vrijwel samenvallende
echte sticks fout gaan; geen garantie voor alle hopen.
`scripts/review_live_duplicates.py` herhaalt inferentie op de twee gemelde
foutbeelden en controleert de bestaande 57 ontwikkelinstanties. Resultaten
staan in `runs/duplicate-filter-v3`. Deze foutbeelden zijn ontwikkeldata.


### Scherpe live-interface in de browser (13 november)

Start `START_GETRAIND_MODEL.cmd` opnieuw. De lokale browserinterface opent automatisch.
De URL staat ook in het startvenster. Alles wordt op deze laptop verwerkt.
Er is geen extra installatie nodig. Letters en nummers worden door de browser
getekend en blijven scherp bij vergroten; alleen het camerabeeld wordt geschaald.

Bovenaan staan totaal, volledig zichtbaar, deels bedekt en onbekende lengtes.
Op het beeld staan witte nummers op donkere vlakken. De tabel rechts toont
status en lengte en kan worden geschoven. Groen is volledig zichtbaar, geel deels bedekt.

- Foto opslaan of S: originele 4K-foto, dashboard, maskers en meetgegevens bewaren.
- Afsluiten, Q of Esc: verwerking stoppen (na de lopende analyse).
- Alleen het tabblad sluiten stopt de camera niet; gebruik de knop Afsluiten.

De opgeslagen dashboardfoto en video blijven 1600 x 900 pixels. Originele beelden
en maskers behouden hun bronresolutie; JSON-coordinaten verwijzen naar het origineel.
De browser toont alle rijen in een schuifbare tabel. Het opgeslagen dashboard
bevat maximaal 23 tabelrijen; alle instanties staan in JSON en maskers.
In de live-interface blijven nummers gelijk binnen dezelfde stilstaande opstelling, tot Reset.
Losse fotoanalyse gebruikt nog steeds nummers per beeld.
Ontbrekende lengtes verschijnen als Onbekend in de browser.
Bedekte vormen en lengtes blijven schattingen. De gebruiker heeft op 13 november
de afmetingen gecontroleerd en voldoende bevonden; er zijn geen numerieke
controlemetingen aangeleverd. Modelgewichten, detectiefilter en meetmethode zijn
voor deze interfacewijziging niet veranderd.


### Analyses laten samenwerken en resetten (13 november)

1. Start `START_GETRAIND_MODEL.cmd` opnieuw om deze wijziging te laden.
2. Leg de sticks neer, haal je handen uit beeld en klik op **Reset (R)** of druk
   op **R** terwijl het browsertabblad actief is. Doe dit na iedere herschikking.
3. Houd de opstelling stil. De eerste twee analyses zijn voorlopig. Daarna moet
   een stick in minimaal 60% van de laatste maximaal vijf analyses zijn gevonden.
   De tabel toont de steun, bijvoorbeeld 4/5, en markeert een overgenomen vorig
   masker. Eén gemiste analyse kan worden overbrugd; na twee opeenvolgende
   missers verdwijnt de stick uit het resultaat. Nieuwe sticks kunnen daardoor
   meerdere analyses nodig hebben voordat ze verschijnen.
4. Status gebruikt een meerderheid van de laatste vijf waarnemingen; geldige
   lengtes gebruiken de mediaan van maximaal vijf getoonde metingen. Een nu
   ongeldige lengte blijft onbekend. Maskers blijven op oorspronkelijke resolutie.

Reset wist de verzamelde resultaten direct. Een analyse die tijdens Reset nog
liep, wordt weggegooid. De eerstvolgende nieuwe analyse start een nieuwe sessie.
Steun is GEEN gekalibreerde kans op juistheid. Dit tempert wisselende resultaten;
een fout die steeds terugkomt blijft mogelijk. Het netwerk en de modelgewichten
worden niet bijgeleerd. Identieke beelden geven niet vanzelf extra informatie.
Bij 0,1 analyses/s vergt vijf analyses ongeveer 50 seconden. Deze stabilisatie
maakt de onderliggende modelverwerking niet sneller. De resetknop reageert in
de browser tijdens de lopende analyse; de nieuwe analyse volgt daarna.
Snapshots bevatten steun per stick, het actuele meetresultaat en de gesmoothde
lengte, plus het aantal analyses en de resetsessie. Gewone fotoanalyse blijft
onafhankelijk en gebruikt geen geheugen van andere foto's.

Lengtemeting: losse maskereilandjes bij een volledig zichtbare stick worden alleen verwijderd wanneer het hoofddeel minstens 80% van het masker vormt, elk eiland voor minstens 95% op een andere detectie ligt, en het hoofddeel nauwelijks met andere detecties overlapt. Onverklaarde losse delen en bedekte maskers worden vervolgens door de expliciete terugvalschatting hieronder afgehandeld. Dit voorkomt dat een stukje van een buurstick de lengtemeting blokkeert. Regressie op snapshot 20261113T143532_745194Z: nummer 14 circa 48,9 mm, twintig detecties en geen ontbrekende lengtes. Dit is een softwarecontrole, geen onafhankelijke fysieke lengtemeting.


Lengteschatting bij ontbrekende meting (16 november 2026): ieder niet-leeg detectiemasker krijgt met een geldige kalibratie een numerieke lengte, behalve stukken die de ingestelde 5-mm-filter verwijdert. Een middenlijn buiten het gekalibreerde gebied wordt met dezelfde perspectieftransformatie geëxtrapoleerd. Bij losse maskerdelen worden hun middenlijnen via de dichtstbijzijnde eindpunten verbonden; bij een onbruikbaar skelet wordt een middenlijn langs de hoofdrichting van het masker benaderd. Dit kan verborgen bochten of onzichtbare uiteinden niet reconstrueren met zekerheid. De voorspelde instance-identiteit blijft een aanname. Deze schattingen kunnen fout zijn en vervangen geen validatie.

De interface markeert extra terugvalschattingen met ≈ (snapshot: ~) en telt ze onder Extra geschat. JSON bewaart length_is_estimate, length_estimation_method en de oorspronkelijke measurement_status als verklaring. Bij een tijdelijk onbruikbare meting van een reeds gevolgde stick kan de mediaan van eerdere bruikbare lengtes worden gebruikt, eveneens als schatting gemarkeerd. Terugvalschattingen worden niet aan die meethistorie toegevoegd. R wist ook deze historie. Zonder kalibratie worden geen millimeters verzonnen; ongeldige kalibratie moet worden hersteld. De modelgewichten veranderen niet door deze wijziging.
