# Controle van het inleverpakket

Gecontroleerd op 16 november 2026 in de bestaande Windows/Python-omgeving.

- `python -m unittest discover -s tests -v`: 41 tests geslaagd.
- Alle zes `data/*/annotations.json`-bestanden zijn met de projectvalidator ingelezen; verwijzingen, beeldafmetingen en annotatiestructuur zijn gecontroleerd.
- Het definitieve model `runs/bright-overlap-01/best.pt` heeft een echte 4K-opname verwerkt: `data/raw/training-bright-v1/20261112T141504_201937Z.png`, met de bijbehorende kalibratie en drempel 0.3. De opdracht eindigde succesvol en schreef 30 detecties weg. Dit controleert de uitvoering, niet de juistheid van die 30 detecties.
- De verpakkingscode controleert de SHA-256 van de definitieve gewichten, de initiële pilotgewichten en de definitieve trainingsannotaties tegen het trainingsmanifest. Alle ZIP-bestanden worden op archiefbeschadiging gecontroleerd.

Er is voor deze oplevering geen nieuwe training en geen installatie op een schone computer uitgevoerd. De trainingsresultaten in het modelmanifest zijn historische resultaten; zie README.md voor de kleine validatieset en beperkingen. De Git-bundle kan lokaal worden gekloond; er is geen online Git-remote ingesteld.
