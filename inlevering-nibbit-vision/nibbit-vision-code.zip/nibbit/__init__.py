"""Nibbit Vision: amodal instance segmentation baseline."""
__version__ = "0.1.0"
