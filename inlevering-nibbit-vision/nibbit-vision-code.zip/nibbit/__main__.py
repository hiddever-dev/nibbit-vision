import argparse
import sys


def camera_options(parser):
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--setup-id", default="lab-v1")
    parser.add_argument("--backend", choices=["auto", "dshow", "msmf", "any"], default="auto")


def main():
    parser = argparse.ArgumentParser(description="Nibbit Vision - amodale segmentatiebasis")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="Controleer bibliotheken en GPU; geen camera-opname")
    p = sub.add_parser("camera-check", help="Test de camera zonder venster of foto's op te slaan")
    camera_options(p)
    p = sub.add_parser("demo", help="Kunstmatig softwarevoorbeeld; geen model of echte dataset")
    p.add_argument("--output", default="runs/software-demo")
    p = sub.add_parser("capture", help="Live preview en originele foto's opslaan")
    camera_options(p)
    p.add_argument("--output", default="data/raw")
    p = sub.add_parser("validate", help="Controleer annotaties, maskers en afmetingen")
    p.add_argument("--annotations", required=True)
    p = sub.add_parser("calibrate", help="Later: klik 4 hoeken van een gemeten vlak")
    p.add_argument("--image", required=True)
    p.add_argument("--width-mm", required=True, type=float)
    p.add_argument("--height-mm", required=True, type=float)
    p.add_argument("--setup-id", default="lab-v1")
    p.add_argument("--output", default="calibration/lab-v1.json")
    p = sub.add_parser("annotate", help="Handmatig volledige en zichtbare polygonen tekenen")
    p.add_argument("--image", required=True)
    p.add_argument("--annotations", default="data/annotations.json")
    p.add_argument("--group-id", required=True)
    p = sub.add_parser("train", help="Train met echte geannoteerde data; internet voor startgewichten")
    p.add_argument("--annotations", required=True)
    p.add_argument("--output", default="runs/train-01")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--lr", type=float, default=0.0001)
    p.add_argument("--initial-weights", help="Begin met bestaande Nibbit-gewichten; nieuw optimizertraject")
    p.add_argument("--accumulate", type=int, default=2)
    p.add_argument("--min-size", type=int, default=512)
    p.add_argument("--max-size", type=int, default=960)
    p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    p = sub.add_parser("evaluate", help="Evalueer op een aparte, ongeziene testdataset")
    p.add_argument("--annotations", required=True)
    p.add_argument("--weights", required=True)
    p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    p.add_argument("--output", default="runs/test-metrics.json")
    p = sub.add_parser("infer", help="Segmentatie op foto of livebeeld met getrainde gewichten")
    camera_options(p)
    p.add_argument("--image", help="Laat weg voor live camera")
    p.add_argument("--weights", required=True)
    p.add_argument("--calibration")
    p.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    p.add_argument("--threshold", type=float, default=0.5)
    p.add_argument("--min-mm", type=float, default=5)
    p.add_argument("--output", default="runs/detections")
    p.add_argument("--record", action="store_true", help="Bewaar live MP4 plus tijdstippen en detecties")
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            import platform
            import cv2
            import numpy
            print(f"Python {platform.python_version()} | OpenCV {cv2.__version__} | NumPy {numpy.__version__}")
            try:
                import torch
                import torchvision
                print(f"PyTorch {torch.__version__} | Torchvision {torchvision.__version__}")
                print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CUDA niet beschikbaar (CPU mogelijk)'}")
            except ImportError:
                print("Modelbibliotheken nog niet geïnstalleerd. Gebruik INSTALL_MODEL.cmd wanneer je gaat trainen.")
        elif args.command == "camera-check":
            from .camera import open_camera, camera_metadata
            cap = open_camera(args.camera, args.width, args.height, args.backend)
            try:
                print(camera_metadata(cap))
            finally:
                cap.release()
        elif args.command == "capture":
            from .camera import capture
            capture(args)
        elif args.command == "demo":
            from .demo import demo
            demo(args.output)
        elif args.command == "validate":
            from .data import load_annotations
            doc, _ = load_annotations(args.annotations)
            print(f"Geldig: {len(doc['images'])} beelden, {sum(len(r['instances']) for r in doc['images'])} sticks.")
        elif args.command == "calibrate":
            from .ui import calibrate
            calibrate(args)
        elif args.command == "annotate":
            from .ui import annotate
            annotate(args)
        elif args.command == "train":
            from .training import train
            train(args)
        elif args.command == "infer":
            if not 0 <= args.threshold <= 1 or args.min_mm < 0:
                raise ValueError("threshold moet tussen 0 en 1 liggen en min-mm mag niet negatief zijn.")
            from .inference import run
            run(args)
        elif args.command == "evaluate":
            from .data import load_annotations
            from .io import write_json
            from .model import device_for, load_model
            from .training import evaluate_records
            doc, root = load_annotations(args.annotations)
            device = device_for(args.device)
            model, checkpoint = load_model(args.weights, device)
            if set(checkpoint["development_groups"]) & {r["group_id"] for r in doc["images"]}:
                raise ValueError("Testgroepen overlappen met training/validatie. Gebruik onafhankelijke bronnen.")
            metrics = evaluate_records(model, doc["images"], root, device)
            write_json(args.output, metrics)
            print(metrics)
    except (ValueError, FileNotFoundError, KeyError) as error:
        print(f"FOUT: {error}", file=sys.stderr)
        return 2
    except ImportError as error:
        print(f"Bibliotheek ontbreekt: {error}. Voer SETUP.cmd of INSTALL_MODEL.cmd uit.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
