from datetime import datetime, timezone
from pathlib import Path
import time

import cv2
import numpy as np

from .io import write_image, write_json


def open_camera(index, width, height, backend="auto"):
    if index < 0 or width < 1 or height < 1:
        raise ValueError("Camera-index mag niet negatief zijn; beeldafmetingen moeten positief zijn.")
    available = {"dshow": cv2.CAP_DSHOW, "msmf": cv2.CAP_MSMF, "any": cv2.CAP_ANY}
    if backend not in ("auto", *available):
        raise ValueError("Backend moet auto, dshow, msmf of any zijn.")
    choices = ["dshow", "msmf", "any"] if backend == "auto" else [backend]
    failures = []
    for name in choices:
        # Some drivers expose MJPEG, others require their native pixel format.
        for mjpeg in (True, False):
            cap = None
            opened = False
            try:
                cap = cv2.VideoCapture(index, available[name])
                opened = cap.isOpened()
                if not opened:
                    failures.append(f"{name}: niet geopend")
                else:
                    if mjpeg:
                        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
                    # isOpened() alone does not prove that the driver delivers images.
                    ok, frame = cap.read()
                    if ok and frame is not None and frame.size:
                        h, w = frame.shape[:2]
                        print(f"Camera {index} verbonden via {name}; werkelijk beeld {w}x{h}.", flush=True)
                        if (w, h) != (width, height):
                            print(f"Let op: {width}x{height} aangevraagd, maar {w}x{h} ontvangen. Geen digitale vergroting toegepast.", flush=True)
                        return cap
                    failures.append(f"{name}: geen leesbaar beeld ({'MJPEG' if mjpeg else 'native'})")
            except cv2.error as error:
                failures.append(f"{name}: {error.code}")
            if cap is not None:
                cap.release()
            if not opened:
                break  # Changing pixel format cannot fix a device that did not open.
    raise ValueError(
        f"Camera {index} levert geen beeld. Geprobeerd: {', '.join(failures)}. "
        "Sluit Windows Camera, Teams en andere camera-apps. Probeer een ander cameranummer "
        "(0, 1 of 2). Controleer bij Windows Instellingen > Privacy en beveiliging > Camera "
        "of bureaublad-apps cameratoegang hebben."
    )


def camera_metadata(cap):
    values = {}
    for name, prop in {"width": cv2.CAP_PROP_FRAME_WIDTH, "height": cv2.CAP_PROP_FRAME_HEIGHT,
                       "reported_fps": cv2.CAP_PROP_FPS, "exposure": cv2.CAP_PROP_EXPOSURE,
                       "auto_exposure": cv2.CAP_PROP_AUTO_EXPOSURE, "focus": cv2.CAP_PROP_FOCUS}.items():
        value = float(cap.get(prop))
        values[name] = value if np.isfinite(value) else None
    try:
        values["backend"] = cap.getBackendName()
    except cv2.error:
        values["backend"] = "unknown"
    return values


def preview_image(frame, text, max_width=1200):
    display = frame.copy()
    cv2.rectangle(display, (0, 0), (display.shape[1], 65), (20, 20, 20), -1)
    scale = max(0.45, min(1.0, display.shape[1] / 1300))
    cv2.putText(display, text, (12, 38), cv2.FONT_HERSHEY_SIMPLEX, scale, (255, 255, 255), 1, cv2.LINE_AA)
    if display.shape[1] > max_width:
        display = cv2.resize(display, (max_width, round(display.shape[0] * max_width / display.shape[1])))
    return display


def capture(args):
    cap = open_camera(args.camera, args.width, args.height, args.backend)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    started, count = time.perf_counter(), 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                raise ValueError("Camera levert geen beeld.")
            h, w = frame.shape[:2]
            fps = (count + 1) / max(0.001, time.perf_counter() - started)
            display = preview_image(frame, f"CAM {args.camera} | {w}x{h} | {fps:.1f} fps | S/SPACE: save | Q: quit")
            cv2.imshow("Nibbit - capture (NO DETECTION)", display)
            key = cv2.waitKey(1) & 0xff
            if key in (27, ord('q')):
                break
            if key in (ord('s'), 32):
                now = datetime.now(timezone.utc)
                name = now.strftime("%Y%m%dT%H%M%S_%fZ")
                path = output / f"{name}.png"
                write_image(path, frame)
                write_json(output / f"{name}.json", {
                    "captured_at_utc": now.isoformat(), "setup_id": args.setup_id, "camera_index": args.camera,
                    "requested_size": [args.width, args.height], "actual_size": [w, h],
                    "camera_properties": camera_metadata(cap), "image_file": path.name,
                    "note": "Camera-properties kunnen unsupported/default-waarden bevatten. Controleer optiek en framing handmatig."
                })
                print(f"Opgeslagen: {path} ({w}x{h})", flush=True)
            count += 1
    finally:
        cap.release()
        cv2.destroyAllWindows()
