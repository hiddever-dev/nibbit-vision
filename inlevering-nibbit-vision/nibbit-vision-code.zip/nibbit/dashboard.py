"""Readable presentation; coordinates in exported measurements remain source pixels."""
import cv2
import numpy as np

BG = (22, 18, 15)
PANEL = (38, 32, 27)
WHITE = (245, 245, 245)
MUTED = (185, 177, 167)
GREEN = (100, 225, 135)
AMBER = (80, 205, 255)


def text(frame, value, x, y, size=.55, color=WHITE, thickness=1):
    cv2.putText(frame, str(value), (int(x), int(y)), cv2.FONT_HERSHEY_SIMPLEX,
                size, color, thickness, cv2.LINE_AA)


def compose_dashboard(overlay, rows, calibration=None, fps=None, page=0, notice=""):
    """Fixed 1600x900 layout, with labels drawn AFTER resizing the camera image."""
    frame = np.full((900, 1600, 3), BG, np.uint8)
    text(frame, "NIBBIT VISION", 26, 38, .85, thickness=2)
    text(frame, "Segmentatie | lengte langs de middenlijn", 26, 66, .5, MUTED)
    text(frame, "LIVE" if fps is not None else "FOTO", 1390, 37, .6)
    if fps is not None:
        text(frame, f"{fps:.1f} analyses/s", 1390, 65, .5, MUTED)
    visible = sum(r['status'] == 'visible' for r in rows)
    for x, title, value, color in [(26, 'TOTAAL', len(rows), WHITE),
                                  (405, 'VOLLEDIG ZICHTBAAR', visible, GREEN),
                                  (784, 'DEELS BEDEKT', len(rows)-visible, AMBER)]:
        cv2.rectangle(frame, (x, 88), (x+359, 166), PANEL, -1)
        text(frame, title, x+14, 112, .44, MUTED)
        text(frame, value, x+14, 151, 1.05, color, 2)
    # Letterbox without changing the source's aspect ratio.
    h, w = overlay.shape[:2]
    scale = min(1117/w, 650/h)
    dw, dh = max(1, round(w*scale)), max(1, round(h*scale))
    ox, oy = 26+(1117-dw)//2, 185+(650-dh)//2
    frame[oy:oy+dh, ox:ox+dw] = cv2.resize(overlay, (dw, dh), interpolation=cv2.INTER_AREA)
    occupied = []
    for row in rows:
        anchor = row.get('label_anchor_pixels')
        if anchor is None:
            continue
        ax, ay = ox+round(anchor[0]*dw/w), oy+round(anchor[1]*dh/h)
        label = str(row['id'])
        tw = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, .55, 2)[0][0]
        bw, bh = tw+18, 28
        choices = [(ax-bw//2, ay-40), (ax+18, ay-14), (ax-bw-18, ay-14),
                   (ax-bw//2, ay+16), (ax+24, ay-52), (ax-bw-24, ay+25)]
        candidates = []
        for cx, cy in choices:
            cx, cy = max(26, min(1143-bw, cx)), max(185, min(835-bh, cy))
            overlaps = sum(max(0, min(cx+bw, r)-max(cx, l))*max(0, min(cy+bh, b)-max(cy, t))
                           for l, t, r, b in occupied)
            candidates.append((overlaps, cx, cy))
        _, cx, cy = min(candidates, key=lambda c: c[0])
        occupied.append((cx-3, cy-3, cx+bw+3, cy+bh+3))
        color = AMBER if row['status'] == 'occluded' else GREEN
        cv2.line(frame, (ax, ay), (cx+bw//2, cy+bh//2), (15, 15, 15), 3, cv2.LINE_AA)
        cv2.line(frame, (ax, ay), (cx+bw//2, cy+bh//2), WHITE, 1, cv2.LINE_AA)
        cv2.rectangle(frame, (cx, cy), (cx+bw, cy+bh), (18, 18, 18), -1)
        cv2.rectangle(frame, (cx, cy), (cx+bw, cy+bh), color, 2)
        text(frame, label, cx+9, cy+20, .55, WHITE, 2)
    cv2.rectangle(frame, (1170, 88), (1574, 835), PANEL, -1)
    text(frame, 'STICKS IN DIT BEELD', 1186, 120, .6, thickness=2)
    text(frame, 'ID', 1186, 155, .47, MUTED)
    text(frame, 'STATUS', 1240, 155, .47, MUTED)
    text(frame, 'LENGTE', 1460, 155, .47, MUTED)
    per_page = 23
    pages = max(1, (len(rows)+per_page-1)//per_page)
    page = min(max(0, page), pages-1)
    for i, row in enumerate(rows[page*per_page:(page+1)*per_page]):
        y = 183+i*26
        if i % 2 == 0:
            cv2.rectangle(frame, (1180, y-17), (1564, y+6), (46, 40, 35), -1)
        color = AMBER if row['status'] == 'occluded' else GREEN
        cv2.circle(frame, (1245, y-5), 4, color, -1)
        text(frame, row['id'], 1186, y, .51)
        text(frame, 'Bedekt' if row['status'] == 'occluded' else 'Zichtbaar', 1258, y, .51)
        length = row.get('length_mm')
        prefix = ''
        text(frame, f'{prefix}{length:.1f} mm' if length is not None else '--', 1450, y, .51)
    text(frame, f'Pagina {page+1}/{pages}   B: vorige / N: volgende', 1186, 802, .43, MUTED)
    if calibration:
        checked = calibration.get('validation_status') == 'user_reported_check_accepted'
        status = 'Schaal: door gebruiker gecontroleerd' if checked else 'Schaal: vlakke kalibratie'
    else:
        status = 'Geen kalibratie: mm niet beschikbaar'
    text(frame, status, 26, 857, .48)
    text(frame, '~ = extra lengteschatting. Bedekte vorm/lengte = schatting. IDs gelden alleen voor dit beeld.', 26, 883, .46, MUTED)
    text(frame, notice or 'S: foto opslaan   |   Q / Esc: afsluiten', 930, 874, .48)
    return frame
