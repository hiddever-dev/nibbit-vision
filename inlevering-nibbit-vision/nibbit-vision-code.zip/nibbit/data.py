from pathlib import Path

import cv2
import numpy as np

from .io import read_image, read_json

LABELS = {"visible": 1, "occluded": 2}


def load_annotations(path):
    path = Path(path)
    document = read_json(path)
    if document.get("schema_version") != 1:
        raise ValueError("Annotaties vereisen schema_version 1.")
    records = document.get("images")
    if not isinstance(records, list) or not records:
        raise ValueError("Geen afbeeldingen in annotaties.")
    seen = set()
    for record in records:
        name = record["file"]
        if name in seen:
            raise ValueError(f"Dubbele afbeelding: {name}")
        seen.add(name)
        if not isinstance(record.get("group_id"), str) or not record["group_id"].strip():
            raise ValueError(f"group_id ontbreekt: {name}")
        image_path = path.parent / name
        image = read_image(image_path)
        h, w = image.shape[:2]
        if [w, h] != record.get("size"):
            raise ValueError(f"Afmetingen kloppen niet: {name}")
        ids = set()
        for instance in record["instances"]:
            instance_id = instance["id"]
            if instance_id in ids:
                raise ValueError(f"Dubbel instance-id: {name}/{instance_id}")
            ids.add(instance_id)
            if instance["status"] not in LABELS:
                raise ValueError(f"Status moet visible of occluded zijn: {name}")
            if type(instance.get("z_order")) is not int:
                raise ValueError(f"Integer z_order verplicht: {name}/{instance_id}")
            for field in ("amodal", "visible"):
                polygons = instance.get(field)
                if not isinstance(polygons, list) or not polygons:
                    raise ValueError(f"{field}-polygonen ontbreken: {name}/{instance_id}")
                for polygon in polygons:
                    p = np.asarray(polygon, dtype=float)
                    if p.ndim != 2 or p.shape[1] != 2 or len(p) < 3 or not np.isfinite(p).all():
                        raise ValueError(f"Ongeldige {field}-polygoon: {name}")
                    if np.any(p < 0) or np.any(p[:, 0] > w - 1) or np.any(p[:, 1] > h - 1):
                        raise ValueError(f"Polygoon buiten beeld: {name}")
            full = rasterize(instance["amodal"], (h, w))
            visible = rasterize(instance["visible"], (h, w))
            if not full.any() or not visible.any() or np.any(visible & ~full):
                raise ValueError(f"Zichtbaar masker moet niet-leeg en binnen volledig masker zijn: {name}")
            if instance["status"] == "visible" and not np.array_equal(full, visible):
                raise ValueError(f"Volledig zichtbare stick heeft verschillende maskers: {name}")
            if instance["status"] == "occluded" and np.array_equal(full, visible):
                raise ValueError(f"Bedekte stick heeft geen verborgen pixels: {name}")
            if cv2.connectedComponents(np.uint8(full), connectivity=8)[0] != 2:
                raise ValueError(f"Volledig masker moet aaneengesloten zijn: {name}/{instance_id}")
        # Reject invalid layer/occluder arrangements under the assignment's one-occluder rule.
        masks = [rasterize(i["amodal"], (h, w)) for i in record["instances"]]
        bounds = [cv2.boundingRect(np.uint8(mask)) for mask in masks]
        def overlaps(i, j):
            xi, yi, wi, hi = bounds[i]
            xj, yj, wj, hj = bounds[j]
            x0, y0 = max(xi, xj), max(yi, yj)
            x1, y1 = min(xi + wi, xj + wj), min(yi + hi, yj + hj)
            return x1 > x0 and y1 > y0 and np.any(masks[i][y0:y1, x0:x1] & masks[j][y0:y1, x0:x1])
        for i, instance in enumerate(record["instances"]):
            occluders = [j for j, other in enumerate(record["instances"])
                         if j != i and other["z_order"] > instance["z_order"] and overlaps(i, j)]
            if len(occluders) > 1:
                raise ValueError(f"Meer dan een bovenliggende stick: {name}/{instance['id']}")
            if bool(occluders) != (instance["status"] == "occluded"):
                raise ValueError(f"Overlapstatus past niet bij z_order en volledige maskers: {name}/{instance['id']}")
            for j in range(i):
                if instance["z_order"] == record["instances"][j]["z_order"] and overlaps(i, j):
                    raise ValueError(f"Overlappende maskers met gelijke z_order: {name}")
    return document, path.parent


def rasterize(polygons, shape):
    mask = np.zeros(shape, dtype=np.uint8)
    # Fill separately so distinct polygons form a union, not even-odd holes.
    for polygon in polygons:
        cv2.fillPoly(mask, [np.rint(polygon).astype(np.int32)], 1)
    return mask.astype(bool)


def group_split(records, seed=42, val_fraction=0.2):
    if any('split' in r for r in records):
        if any(r.get('split') not in ('train', 'val') for r in records):
            raise ValueError('Bij expliciete splits moet ieder beeld train of val aangeven.')
        train = [r for r in records if r['split'] == 'train']
        val = [r for r in records if r['split'] == 'val']
        if not train or not val:
            raise ValueError('Train en validatie moeten allebei beelden bevatten.')
        if {r['group_id'] for r in train} & {r['group_id'] for r in val}:
            raise ValueError('Dezelfde brongroep in training en validatie.')
        train_sources = {s for r in train for s in r.get('source_ids', [])}
        val_sources = {s for r in val for s in r.get('source_ids', [])}
        if train_sources & val_sources:
            raise ValueError('Dezelfde fysieke bronstick in training en validatie.')
        return train, val
    groups = sorted({r["group_id"] for r in records})
    if len(groups) < 2:
        raise ValueError("Minimaal twee onafhankelijke group_id's nodig voor train/validatie.")
    rng = np.random.default_rng(seed)
    rng.shuffle(groups)
    n = max(1, min(len(groups) - 1, round(len(groups) * val_fraction)))
    val = set(groups[:n])
    return ([r for r in records if r["group_id"] not in val],
            [r for r in records if r["group_id"] in val])


class StickDataset:
    def __init__(self, records, root, augment=False):
        self.records, self.root, self.augment = records, root, augment

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        import torch
        record = self.records[index]
        image = read_image(self.root / record["file"])
        h, w = image.shape[:2]
        masks = np.array([rasterize(i["amodal"], (h, w)) for i in record["instances"]], dtype=np.uint8)
        masks = masks.reshape(-1, h, w)
        if self.augment and torch.rand(()) < 0.5:
            image = image[:, ::-1].copy()
            masks = masks[:, :, ::-1].copy()
        boxes = []
        for mask in masks:
            y, x = np.where(mask)
            boxes.append([int(x.min()), int(y.min()), min(w, int(x.max()) + 1), min(h, int(y.max()) + 1)])
        target = {
            "boxes": torch.tensor(boxes, dtype=torch.float32).reshape(-1, 4),
            "labels": torch.tensor([LABELS[i["status"]] for i in record["instances"]], dtype=torch.int64),
            "masks": torch.from_numpy(masks),
            "image_id": torch.tensor(index),
        }
        tensor = torch.from_numpy(image[:, :, ::-1].copy()).permute(2, 0, 1).float() / 255
        return tensor, target
