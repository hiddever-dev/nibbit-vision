"""Illustrative shapes only: never advertise these as a Nibbit dataset or model result."""
from pathlib import Path

import cv2
import numpy as np

from .data import rasterize
from .inference import render
from .io import write_image, write_json


def demo(output):
    output = Path(output)
    image = np.full((480, 640, 3), 235, dtype=np.uint8)
    lower = [[100, 230], [535, 230], [535, 250], [100, 250]]
    upper = [[306, 100], [326, 100], [326, 390], [306, 390]]
    visible_lower = [[[100, 230], [305, 230], [305, 250], [100, 250]],
                     [[327, 230], [535, 230], [535, 250], [327, 250]]]
    instances = [
        {"id": "bottom", "status": "occluded", "z_order": 0, "amodal": [lower], "visible": visible_lower},
        {"id": "top", "status": "visible", "z_order": 1, "amodal": [upper], "visible": [upper]},
    ]
    for instance, color in zip(instances, [(45, 150, 220), (70, 75, 210)]):
        image[rasterize(instance["amodal"], image.shape[:2])] = color
    write_image(output / "synthetic_crossing.png", image)
    document = {"schema_version": 1, "purpose": "SOFTWARE TEST ONLY - artificial shapes, not real sticks",
                "images": [{"file": "synthetic_crossing.png", "size": [640, 480],
                            "group_id": "synthetic-example-only", "instances": instances}]}
    write_json(output / "annotations.json", document)
    predictions = [{"mask": rasterize(i["amodal"], image.shape[:2]), "status": i["status"], "score": 1.0} for i in instances]
    annotated, rows, _ = render(image, predictions)
    cv2.putText(annotated, "SYNTHETIC TEST - GIVEN MASKS - NO MODEL", (15, 465),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (30, 30, 30), 1, cv2.LINE_AA)
    write_image(output / "synthetic_measurement.png", annotated)
    write_json(output / "synthetic_measurement.json", {"purpose": document["purpose"], "instances": rows})
    print(f"Kunstmatig softwarevoorbeeld opgeslagen: {output}")
