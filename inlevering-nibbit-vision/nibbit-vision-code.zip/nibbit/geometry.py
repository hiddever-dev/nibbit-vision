"""Geometric baseline; no hidden geometry is asserted to be ground truth."""
import heapq

import cv2
import numpy as np
from skimage.morphology import skeletonize


def make_calibration(points, width_mm, height_mm, image_shape, setup_id):
    points = np.asarray(points, dtype=np.float32)
    if points.shape != (4, 2) or not np.isfinite(points).all():
        raise ValueError("Vier geldige hoekpunten nodig.")
    if width_mm <= 0 or height_mm <= 0:
        raise ValueError("Afmetingen moeten positief zijn.")
    if not cv2.isContourConvex(points.reshape(-1, 1, 2)) or abs(cv2.contourArea(points)) < 10:
        raise ValueError("Klik vier hoeken rondom een rechthoek: linksboven, rechtsboven, rechtsonder, linksonder.")
    target = np.float32([[0, 0], [width_mm, 0], [width_mm, height_mm], [0, height_mm]])
    matrix = cv2.getPerspectiveTransform(points, target)
    h, w = image_shape[:2]
    return {"schema_version": 1, "setup_id": setup_id, "image_size": [w, h],
            "image_to_mm": matrix.tolist(), "roi_pixels": points.tolist(),
            "width_mm": width_mm, "height_mm": height_mm,
            "method": "four_point_planar_approximation",
            "limitations": "Geen lens- of hoogtecorrectie; valideer met onafhankelijke meetpunten."}


def verify_calibration(calibration, image_shape, setup_id):
    h, w = image_shape[:2]
    if calibration["image_size"] != [w, h]:
        raise ValueError("Kalibratie past niet bij deze beeldresolutie. Opnieuw kalibreren.")
    if calibration["setup_id"] != setup_id:
        raise ValueError("Kalibratie hoort bij een andere setup-id.")
    matrix = np.asarray(calibration["image_to_mm"], dtype=float)
    if matrix.shape != (3, 3) or not np.isfinite(matrix).all() or abs(np.linalg.det(matrix)) < 1e-12:
        raise ValueError("Ongeldige kalibratiematrix.")


def transform_points(points, matrix):
    points = np.asarray(points, dtype=np.float64)
    if len(points) == 0:
        return points.reshape(0, 2)
    homogeneous = np.c_[points, np.ones(len(points))] @ np.asarray(matrix).T
    if np.any(np.abs(homogeneous[:, 2]) < 1e-9):
        raise ValueError("Punten vallen buiten een geldige perspectieftransformatie.")
    return homogeneous[:, :2] / homogeneous[:, 2, None]


def polyline_length(points):
    return float(np.linalg.norm(np.diff(np.asarray(points), axis=0), axis=1).sum())


def spine(mask):
    """Longest endpoint-to-endpoint skeleton route, extended towards mask edges.

    Refuse disconnected masks rather than silently measuring one fragment.
    The smoothed skeleton is an estimate, requiring real-world validation.
    """
    mask = np.asarray(mask, dtype=np.uint8)
    yy, xx = np.nonzero(mask)
    if not len(xx):
        return None, "empty_mask"
    left, top, right, bottom = int(xx.min()), int(yy.min()), int(xx.max())+1, int(yy.max())+1
    # Skeletonizing every full 4K frame per object wastes most work on background.
    # Keep all components, pad with background, and restore global coordinates.
    mask = np.pad(mask[top:bottom, left:right], 1)
    offset = np.array([left-1, top-1], dtype=float)
    count, labels = cv2.connectedComponents(mask, connectivity=8)
    if count != 2:
        return None, "empty_mask" if count == 1 else "disconnected_mask"
    yx = np.argwhere(skeletonize(mask > 0))
    if len(yx) < 2:
        return None, "spine_too_short"
    lookup = {tuple(p): i for i, p in enumerate(yx)}
    graph = [[] for _ in yx]
    for i, (y, x) in enumerate(yx):
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if not (dx or dy):
                    continue
                j = lookup.get((y + dy, x + dx))
                if j is not None:
                    graph[i].append((j, float(np.hypot(dx, dy))))
    ends = [i for i, edges in enumerate(graph) if len(edges) == 1]
    if len(ends) < 2:
        return None, "no_two_endpoints"
    # More endpoints indicate branches: choose the longest route, not total skeleton length.
    if len(ends) > 64:
        return None, "too_many_branches"
    best = None
    for start in ends:
        distances = np.full(len(yx), np.inf)
        previous = np.full(len(yx), -1, dtype=int)
        distances[start] = 0
        queue = [(0.0, start)]
        while queue:
            distance, u = heapq.heappop(queue)
            if distance != distances[u]:
                continue
            for v, weight in graph[u]:
                candidate = distance + weight
                if candidate < distances[v]:
                    distances[v] = candidate
                    previous[v] = u
                    heapq.heappush(queue, (candidate, v))
        finish = max(ends, key=lambda e: distances[e])
        if np.isfinite(distances[finish]) and (best is None or distances[finish] > best[0]):
            best = (distances[finish], start, finish, previous)
    if best is None:
        return None, "invalid_skeleton"
    _, start, current, previous = best
    path = [current]
    while current != start:
        current = int(previous[current])
        path.append(current)
    xy = yx[path[::-1], ::-1].astype(float)
    # A rectangular or uneven end can create diagonal skeleton branches towards
    # cap corners. They are not part of the object's centreline. Start extension
    # from the stable interior instead of extending those terminal diagonals.
    distances_inside = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    radii = distances_inside[np.rint(xy[:, 1]).astype(int), np.rint(xy[:, 0]).astype(int)]
    radius = float(np.median(radii))
    cumulative = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(xy, axis=0), axis=1))]
    trim = 2.5 * radius
    if trim >= 2 and cumulative[-1] > 8 * radius:
        inside = (cumulative >= trim) & (cumulative <= cumulative[-1] - trim)
        if inside.sum() >= 7:
            xy = xy[inside]
    # Suppress pixel stair-steps without fitting a straight line through a curved stick.
    if len(xy) >= 7:
        from scipy.ndimage import gaussian_filter1d
        smooth = gaussian_filter1d(xy, sigma=1.0, axis=0, mode="nearest")
        smooth[0], smooth[-1] = xy[0], xy[-1]
        xy = smooth
    # Skeletonization shortens rounded ends. Extend tangents until the mask boundary.
    def extend(endpoint, inner):
        direction = endpoint - inner
        norm = np.linalg.norm(direction)
        if norm == 0:
            return endpoint
        direction /= norm
        last = endpoint.copy()
        for t in np.arange(0.25, max(mask.shape), 0.25):
            p = endpoint + t * direction
            x, y = np.rint(p).astype(int)
            if not (0 <= x < mask.shape[1] and 0 <= y < mask.shape[0]) or not mask[y, x]:
                break
            last = p
        return last
    # Fit the terminal direction over roughly one stick-width rather than five
    # pixels, which are too sensitive to raster stair-steps and edge roughness.
    step = min(max(5, int(round(2 * radius))), len(xy) - 1)
    first = extend(xy[0], xy[step])
    last = extend(xy[-1], xy[-1 - step])
    xy = np.vstack([first, xy, last])
    return xy + offset, "estimated"


def measure(mask, calibration=None):
    points, status = spine(mask)
    output = {"length_px": None, "length_mm": None, "measurement_status": status, "spine_pixels": []}
    if points is None:
        return output
    output["spine_pixels"] = points.tolist()
    output["length_px"] = polyline_length(points)
    if calibration is not None:
        roi = np.asarray(calibration["roi_pixels"], dtype=np.float32)
        # Refuse measurements outside the calibrated area, including mask edges.
        contours, _ = cv2.findContours(np.uint8(mask), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if any(cv2.pointPolygonTest(roi, (float(x), float(y)), False) < 0
               for contour in contours for x, y in contour[:, 0]):
            output["measurement_status"] = "outside_calibrated_roi"
        else:
            output["length_mm"] = polyline_length(transform_points(points, calibration["image_to_mm"]))
            output["measurement_status"] = "estimated_planar_mm"
    return output


def estimate_missing_length(mask, calibration, result):
    """Keep strict measurement separate from an explicitly labelled fallback.

    Join disconnected centreline pieces by nearest endpoints. This assumes the
    pieces belong to one stick (as predicted), and interpolates hidden gaps.
    For an unusable skeleton use a binned principal-axis centreline instead.
    Neither method can recover an invisible end or validate instance identity.
    """
    if result['length_mm'] is not None or calibration is None:
        return result
    yy, xx = np.nonzero(mask)
    if not len(xx):
        return result
    reason = result['measurement_status']
    points = np.asarray(result['spine_pixels'], dtype=float).reshape(-1, 2)
    method = 'extrapolated_calibration'
    if len(points) < 2:
        x0, x1, y0, y1 = xx.min(), xx.max()+1, yy.min(), yy.max()+1
        crop = np.uint8(mask[y0:y1, x0:x1])
        count, labels, stats, _ = cv2.connectedComponentsWithStats(crop, connectivity=8)
        pieces = []
        for k in range(1, count):
            component = labels == k
            # Ignore tiny segmentation specks in the length reconstruction.
            if stats[k, cv2.CC_STAT_AREA] < max(2, .005 * crop.sum()):
                continue
            path, _ = spine(component)
            if path is None:
                cy, cx = np.nonzero(component)
                cloud = np.column_stack([cx, cy]).astype(float)
                centre = cloud.mean(axis=0)
                _, _, axes = np.linalg.svd(cloud-centre, full_matrices=False)
                axis = axes[0]
                projected = (cloud-centre) @ axis
                edges = np.linspace(projected.min(), projected.max(),
                                    max(3, min(64, int(np.ptp(projected)/3)+2)))
                bins = np.digitize(projected, edges[1:-1])
                path = np.array([cloud[bins == b].mean(axis=0)
                                 for b in np.unique(bins)])
                if len(path) < 2:
                    path = np.array([centre-.5*axis, centre+.5*axis])
            pieces.append(path + [x0, y0])
        if not pieces:
            # A nonempty single-pixel mask still has a one-pixel extent.
            points = np.array([[xx.mean()-.5, yy.mean()], [xx.mean()+.5, yy.mean()]])
            method = 'pixel_extent'
        else:
            points = pieces.pop(int(np.argmax([polyline_length(p) for p in pieces])))
            while pieces:
                choices = [(np.linalg.norm(points[a]-p[b]), i, a, b)
                           for i, p in enumerate(pieces) for a in (0, -1) for b in (0, -1)]
                _, i, a, b = min(choices)
                piece = pieces.pop(i)
                if a == 0:
                    points = points[::-1]
                if b == -1:
                    piece = piece[::-1]
                points = np.vstack([points, piece])
            method = 'reconstructed_centreline'
    length = polyline_length(transform_points(points, calibration['image_to_mm']))
    if not np.isfinite(length) or length <= 0:
        raise ValueError('Geen geldige schaal voor de lengteschatting; controleer de kalibratie.')
    return {**result, 'length_px': polyline_length(points), 'length_mm': length,
            'spine_pixels': points.tolist(), 'length_is_estimate': True,
            'length_estimation_method': method, 'measurement_status': reason,
            'length_estimation_note': 'Benadering uit masker; verborgen of afgeknipte uiteinden zijn niet waarneembaar.'}
