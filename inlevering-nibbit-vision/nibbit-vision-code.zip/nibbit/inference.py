from datetime import datetime, timezone
from pathlib import Path
import time

import cv2
import numpy as np

from .camera import open_camera
from .dashboard import compose_dashboard
from .geometry import measure, verify_calibration, estimate_missing_length
from .io import read_image, read_json, write_image, write_json
from .model import device_for, load_model, predict, POSTPROCESSING_VERSION
from .temporal import SceneConsensus


def remove_assigned_fragments(predictions):
    """Remove stray islands on another instance, never bridge a genuine gap.

    Only visible instances with one dominant component qualify. Ambiguous or
    occluded disconnected masks retain the existing unknown-length behavior.
    """
    cleaned = []
    for index, prediction in enumerate(predictions):
        mask = prediction['mask']
        if prediction['status'] == 'visible':
            yy, xx = np.nonzero(mask)
            if len(xx):
                x0, x1, y0, y1 = xx.min(), xx.max()+1, yy.min(), yy.max()+1
                crop = mask[y0:y1, x0:x1]
                count, labels, stats, _ = cv2.connectedComponentsWithStats(crop.astype(np.uint8), connectivity=8)
                if count > 2:
                    main = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
                    dominant = labels == main
                    others = [p['mask'][y0:y1, x0:x1] for j, p in enumerate(predictions) if j != index]
                    islands = [labels == k for k in range(1, count) if k != main]
                    if (dominant.sum() >= .80 * crop.sum() and others
                            and all(np.logical_and(dominant, other).sum() <= .10 * dominant.sum() for other in others)
                            and all(any(np.logical_and(island, other).sum() >= .95 * island.sum()
                                        for other in others) for island in islands)):
                        mask = np.zeros_like(mask)
                        mask[y0:y1, x0:x1] = dominant
                        prediction = {**prediction, 'mask': mask,
                                      'removed_assigned_fragment_pixels': int(crop.sum()-dominant.sum())}
        cleaned.append(prediction)
    return cleaned


def render(image, predictions, calibration=None, min_mm=5, *, fps=None, page=0, notice="", dashboard=True):
    frame = image.copy()
    rows, masks = [], []
    h, w = image.shape[:2]
    for prediction in remove_assigned_fragments(predictions):
        mask = prediction["mask"]
        if not mask.any():
            continue
        row = {"id": prediction.get('track_id', len(rows) + 1), "status": prediction["status"], "score": prediction["score"],
               **measure(mask, calibration)}
        row.update({k: v for k, v in prediction.items() if k.startswith('temporal_')})
        if 'removed_assigned_fragment_pixels' in prediction:
            row['removed_assigned_fragment_pixels'] = prediction['removed_assigned_fragment_pixels']
        row["touches_image_border"] = bool(mask[0].any() or mask[-1].any() or mask[:, 0].any() or mask[:, -1].any())
        if row["touches_image_border"]:
            row["length_mm"] = None
            row["measurement_status"] = "truncated_at_image_border"
        row = estimate_missing_length(mask, calibration, row)
        if row["length_mm"] is not None and row["length_mm"] < min_mm:
            continue
        color = (60, 210, 255) if row["status"] == "occluded" else (60, 230, 80)
        frame[mask] = (frame[mask] * 0.82 + np.array(color) * 0.18).astype(np.uint8)
        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(frame, contours, -1, (20, 20, 20), max(3, w // 500))
        cv2.drawContours(frame, contours, -1, color, max(2, w // 900))
        points = np.asarray(row["spine_pixels"], dtype=np.int32)
        if len(points):
            cv2.polylines(frame, [points], False, (20, 20, 20), max(3, w // 650))
            cv2.polylines(frame, [points], False, (245, 245, 245), max(1, w // 1600))
        ys, xs = np.where(mask)
        row["label_anchor_pixels"] = [float(np.median(xs)), float(np.median(ys))]
        rows.append(row)
        masks.append(mask)
    if dashboard:
        frame = compose_dashboard(frame, rows, calibration, fps=fps, page=page, notice=notice)
    stacked = np.stack(masks) if masks else np.empty((0, h, w), dtype=bool)
    return frame, rows, stacked


def run(args):
    device = device_for(args.device)
    model, checkpoint = load_model(args.weights, device)
    calibration = read_json(args.calibration) if args.calibration else None
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if args.image:
        image = read_image(args.image)
        if calibration:
            verify_calibration(calibration, image.shape, args.setup_id)
        predictions = predict(model, image, device, args.threshold)
        annotated, rows, masks = render(image, predictions, calibration, args.min_mm)
        stem = Path(args.image).stem
        write_image(output / f"{stem}_detections.png", annotated)
        np.savez_compressed(output / f"{stem}_masks.npz", masks=masks)
        write_json(output / f"{stem}_detections.json", {
            "image": str(args.image), "weights": str(args.weights), "setup_id": args.setup_id,
            "calibration": calibration, "instances": rows, "model_epoch": checkpoint["epoch"],
            "postprocessing": POSTPROCESSING_VERSION,
            "note": "Verborgen vorm en lengte zijn schattingen; beeldgebonden IDs zijn geen tracking-IDs."
        })
        print(f"{len(rows)} detecties opgeslagen in {output}")
        return
    cap = open_camera(args.camera, args.width, args.height, args.backend)
    writer, recording_rows = None, []
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    began = time.perf_counter()
    fps, page, notice_until = 0.0, 0, 0.0
    from .live_window import LiveWindow
    window = LiveWindow(calibration)
    consensus = SceneConsensus()
    generation = window.generation
    try:
        while True:
            if window.generation != generation:
                consensus.reset()
                generation = window.generation
            ok, image = cap.read()
            if not ok:
                raise ValueError("Geen camerabeeld.")
            if calibration:
                verify_calibration(calibration, image.shape, args.setup_id)
            tick = time.perf_counter()
            predictions = predict(model, image, device, args.threshold)
            if window.generation != generation:
                continue
            predictions = consensus.update(predictions)
            notice = "Foto opgeslagen" if time.perf_counter() < notice_until else ""
            overlay, rows, masks = render(image, predictions, calibration, args.min_mm,
                                         dashboard=False)
            consensus.smooth_lengths(rows)
            fps = 1 / max(0.001, time.perf_counter() - tick)
            annotated = compose_dashboard(overlay, rows, calibration, fps=fps, page=page)
            if args.record:
                if writer is None:
                    h, w = annotated.shape[:2]
                    writer = cv2.VideoWriter(str(output / f"live_{stamp}.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), 10, (w, h))
                    if not writer.isOpened():
                        raise ValueError("Videobestand kan niet worden geopend.")
                writer.write(annotated)
                recording_rows.append({"elapsed_seconds": time.perf_counter() - began, "instances": rows})
            key = window.show(overlay, rows, fps, notice, analyses=consensus.frames,
                              expected_generation=generation)
            if key in (ord('s'), ord('S')):
                saved_stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
                stem = output / f'snapshot_{saved_stamp}'
                write_image(str(stem) + '_raw.png', image)
                write_image(str(stem) + '_detections.png', annotated)
                np.savez_compressed(str(stem) + '_masks.npz', masks=masks)
                write_json(str(stem) + '.json', {'weights': str(args.weights), 'setup_id': args.setup_id,
                           'calibration': calibration, 'instances': rows,
                           'temporal': {'analyses': consensus.frames, 'window': consensus.window,
                                        'reset_session': generation},
                           'postprocessing': POSTPROCESSING_VERSION})
                print(f'Opname met detecties opgeslagen: {stem}', flush=True)
                notice_until = time.perf_counter() + 4
            if key in (ord('n'), ord('N')):
                page = min(page + 1, max(0, (len(rows)-1)//23))
            if key in (ord('b'), ord('B')):
                page = max(0, page - 1)
            if key in (27, ord('q'), ord('Q')):
                break
    finally:
        if not window.closed:
            window.close()
        cap.release()
        if writer:
            writer.release()
            write_json(output / f"live_{stamp}.json", {
                "weights": str(args.weights), "setup_id": args.setup_id, "calibration": calibration,
                "postprocessing": POSTPROCESSING_VERSION,
                "playback_fps": 10, "note": "Video heeft vaste afspeelsnelheid; echte tijdstippen staan per frame hieronder.",
                "frames": recording_rows})
        cv2.destroyAllWindows()
