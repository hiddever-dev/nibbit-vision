"""Local browser interface: browser-rendered text stays sharp at any window size."""
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from threading import Thread, Lock
import webbrowser

import cv2

HTML = r'''<!doctype html><html lang="nl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Nibbit Vision</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#10151b;color:#f5f7fa;font:16px 'Segoe UI',Arial,sans-serif;padding:24px}header{display:flex;justify-content:space-between;align-items:center}h1{margin:0;font-size:28px}header p,.muted{color:#b7c3d0}button{background:#283746;color:white;border:1px solid #536679;border-radius:8px;padding:12px 18px;cursor:pointer;font:inherit}button:hover{background:#3a5064}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:20px 0}.card,aside{background:#1b232d;border:1px solid #34404c;border-radius:12px;padding:16px}.card span{color:#b7c3d0}.card strong{display:block;font-size:36px;margin-top:6px}.green{color:#8ce276}.yellow{color:#ffce54}main{display:grid;grid-template-columns:minmax(0,1fr) 440px;gap:20px;align-items:start}.camera{position:relative;background:black;border-radius:10px;overflow:hidden}.camera img{width:100%;display:block}.camera svg{position:absolute;inset:0;width:100%;height:100%}aside h2{font-size:20px;margin:0 0 14px}.scroll{max-height:65vh;overflow:auto}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th{position:sticky;top:0;background:#1b232d;text-align:left;color:#b7c3d0}td,th{padding:10px 6px}tbody tr:nth-child(odd){background:#252f3b}td:last-child{text-align:right}footer{margin-top:16px;line-height:1.6}.actions{display:flex;gap:10px;align-items:center}#notice{color:#ffce54} @media(max-width:1000px){main{grid-template-columns:1fr}.scroll{max-height:400px}}@media(max-width:600px){.cards{grid-template-columns:1fr 1fr}body{padding:12px}header{display:block}}
</style><header><div><h1>NIBBIT VISION</h1><p>Segmentatie en lengte langs de middenlijn</p></div><div class="actions"><span id="speed" class="muted">Camera wordt gestart…</span><button onclick="action('r')">Reset (R)</button><button onclick="action('s')">Foto opslaan (S)</button><button onclick="action('q')">Afsluiten</button></div></header>
<div class="cards"><div class="card"><span>Totaal</span><strong id="total">—</strong></div><div class="card"><span>Volledig zichtbaar</span><strong id="visible" class="green">—</strong></div><div class="card"><span>Deels bedekt</span><strong id="covered" class="yellow">—</strong></div></div>
<main><div class="camera"><img id="image" alt="Wachten op het eerste camerabeeld"><svg id="labels"></svg></div><aside><h2>Sticks in dit beeld</h2><div class="scroll"><table><thead><tr><th>ID</th><th>Status</th><th>Steun</th><th>Lengte</th></tr></thead><tbody id="rows"></tbody></table></div></aside></main>
<footer><div id="support" class="muted">Nog geen analyses verzameld.</div><div id="notice"></div><div id="calibration"></div><div class="muted">Groen: volledig zichtbaar · Geel: deels bedekt. Verborgen vorm en lengte zijn schattingen. Nummers blijven gelijk tot Reset. Laat de sticks stil liggen. Hussel de sticks en druk daarna op R zodra je handen uit beeld zijn. Steun is geen kans op juistheid; een herhaalde fout kan blijven bestaan.</div></footer>
<script>
let current=null,version=-1,stopped=false;
async function action(key){try{await fetch('/action',{method:'POST',body:key});if(key==='q'){stopped=true;document.getElementById('speed').textContent='Afsluiten aangevraagd — je kunt dit tabblad sluiten';}}catch(e){}}
document.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(['s','r','q','escape'].includes(k)){e.preventDefault();action(k==='escape'?'q':k)}});
function drawLabels(){if(!current)return;const svg=document.getElementById('labels');svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${current.width} ${current.height}`);const factor=current.width/Math.max(1,svg.clientWidth),occupied=[];
 for(const r of current.rows){if(!r.anchor)continue;const [ax,ay]=r.anchor,bw=40*factor,bh=28*factor;let choices=[[ax,ay-35*factor],[ax+45*factor,ay],[ax-45*factor,ay],[ax,ay+35*factor]];choices.sort((a,b)=>occupied.filter(p=>Math.abs(a[0]-p[0])<bw&&Math.abs(a[1]-p[1])<bh).length-occupied.filter(p=>Math.abs(b[0]-p[0])<bw&&Math.abs(b[1]-p[1])<bh).length);let[x,y]=choices[0];x=Math.max(bw/2,Math.min(current.width-bw/2,x));y=Math.max(bh/2,Math.min(current.height-bh/2,y));occupied.push([x,y]);
 function el(tag,attrs){let e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);svg.appendChild(e);return e}
 el('line',{x1:ax,y1:ay,x2:x,y2:y,stroke:'white','stroke-width':factor*1.5});el('rect',{x:x-bw/2,y:y-bh/2,width:bw,height:bh,rx:3*factor,fill:'#10151b',stroke:r.status==='occluded'?'#ffce54':'#8ce276','stroke-width':2*factor});el('text',{x,y,'text-anchor':'middle','dominant-baseline':'central',fill:'white','font-family':'Segoe UI,Arial','font-size':16*factor,'font-weight':'bold'}).textContent=r.id;
 }}
new ResizeObserver(drawLabels).observe(document.getElementById('image'));
async function poll(){if(stopped)return;try{const response=await fetch('/state');const s=await response.json();if(s.version!==version&&s.image){version=s.version;current=s;document.getElementById('image').style.opacity=s.analyses===0?'0.35':'1';document.getElementById('image').src='data:image/jpeg;base64,'+s.image;const vis=s.rows.filter(r=>r.status==='visible').length;for(const[id,value]of Object.entries({total:s.rows.length,visible:vis,covered:s.rows.length-vis}))document.getElementById(id).textContent=value;
 const tbody=document.getElementById('rows');tbody.replaceChildren();for(const r of s.rows){let tr=document.createElement('tr');for(const value of[r.id,r.status==='occluded'?'● Bedekt':'● Zichtbaar',r.support+(r.provisional?' voorlopig':r.held?' vorig beeld':''),r.length===null?'Onbekend':r.length.toFixed(1)+' mm']){let td=document.createElement('td');td.textContent=value;tr.appendChild(td)}tr.children[1].className=r.status==='occluded'?'yellow':'green';tbody.appendChild(tr)}document.getElementById('speed').textContent='LIVE | '+s.fps.toFixed(1)+' analyses/s';document.getElementById('support').textContent=s.analyses===0?'Geheugen leeg — wachten op nieuwe analyse':s.analyses+' analyses sinds reset · steun uit de laatste '+Math.min(5,s.analyses)+' · '+(s.analyses<3?'opstartfase: voorlopig resultaat':'meerderheid vereist')+' · bij één gemiste analyse kan het vorige masker kort zichtbaar blijven';document.getElementById('calibration').textContent=s.calibration;drawLabels();}document.getElementById('notice').textContent=s.notice||'';}catch(e){document.getElementById('speed').textContent='Geen verbinding met de detectie';}setTimeout(poll,300)}poll();
</script></html>'''


class LiveWindow:
    def __init__(self, calibration=None, *, launch=True):
        self.closed, self.key = False, 255
        self.lock = Lock()
        self._generation = 0
        self.state = {'version': 0, 'image': None, 'notice': ''}
        self.calibration = ('Schaal: door gebruiker gecontroleerd' if calibration and
                            calibration.get('validation_status') == 'user_reported_check_accepted'
                            else 'Schaal: vlakke kalibratie' if calibration else 'Geen kalibratie: mm niet beschikbaar')
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/':
                    body, mime = HTML.encode('utf-8'), 'text/html; charset=utf-8'
                elif self.path == '/state':
                    with owner.lock:
                        body = json.dumps(owner.state).encode('utf-8')
                    mime = 'application/json'
                else:
                    self.send_error(404)
                    return
                self.send_response(200)
                self.send_header('Content-Type', mime)
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                if self.path != '/action':
                    self.send_error(404)
                    return
                # Only accept this local page's control requests.
                if self.headers.get('Origin') not in (None, owner.url.rstrip('/')):
                    self.send_error(403)
                    return
                key = self.rfile.read(min(8, int(self.headers.get('Content-Length', 0)))).decode()
                if key == 'r':
                    with owner.lock:
                        owner._generation += 1
                        owner.state.update(version=owner.state['version']+1, rows=[], analyses=0,
                                           notice='Geheugen gewist. Wachten op een nieuwe analyse…')
                elif key in ('s', 'q'):
                    with owner.lock:
                        owner.key = ord(key)
                self.send_response(204)
                self.end_headers()

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.url = f'http://127.0.0.1:{self.server.server_port}/'
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        print(f'Live-interface: {self.url}', flush=True)
        if launch:
            webbrowser.open(self.url)

    @property
    def generation(self):
        with self.lock:
            return self._generation

    def show(self, overlay, rows, fps, notice='', *, analyses=0, expected_generation=None):
        h, w = overlay.shape[:2]
        scale = min(1., 1920/w)
        display = cv2.resize(overlay, (round(w*scale), round(h*scale))) if scale < 1 else overlay
        ok, encoded = cv2.imencode('.jpg', display, [cv2.IMWRITE_JPEG_QUALITY, 90])
        if not ok:
            raise ValueError('Camerabeeld kon niet voor de interface worden gemaakt.')
        with self.lock:
            # A reset during a slow inference must not republish the old scene.
            if expected_generation is not None and expected_generation != self._generation:
                return 255
            self.state = {'version': self.state['version']+1,
                          'image': base64.b64encode(encoded).decode('ascii'),
                          'width': w, 'height': h, 'fps': fps, 'notice': notice,
                          'calibration': self.calibration,
                          'analyses': analyses,
                          'rows': [{'id': r['id'], 'status': r['status'], 'length': r.get('length_mm'),
                                    'estimated': r.get('length_is_estimate', False),
                                    'support': f"{r.get('temporal_hits', 1)}/{r.get('temporal_window', 1)}",
                                    'provisional': r.get('temporal_provisional', False),
                                    'held': r.get('temporal_held', False),
                                    'anchor': r.get('label_anchor_pixels')} for r in rows]}
            key, self.key = self.key, 255
        return key

    def close(self):
        self.closed = True
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
