"""Torch is imported only for commands that actually need a model."""
from pathlib import Path

import numpy as np

POSTPROCESSING_VERSION = 'mask-dedup-v6-same-status-partials'


def device_for(name="auto"):
    import torch
    if name == "auto":
        name = "cuda" if torch.cuda.is_available() else "cpu"
    if name == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA niet beschikbaar. Controleer de PyTorch-installatie of kies --device cpu.")
    return torch.device(name)


def build_model(pretrained=False, min_size=512, max_size=960):
    from torchvision.models.detection import maskrcnn_resnet50_fpn
    from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
    from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor
    model = maskrcnn_resnet50_fpn(
        weights="DEFAULT" if pretrained else None, weights_backbone=None,
        progress=False,
        min_size=min_size, max_size=max_size, box_detections_per_img=100,
    )
    model.roi_heads.box_predictor = FastRCNNPredictor(model.roi_heads.box_predictor.cls_score.in_features, 3)
    model.roi_heads.mask_predictor = MaskRCNNPredictor(model.roi_heads.mask_predictor.conv5_mask.in_channels, 256, 3)
    return model


def load_model(path, device):
    import torch
    if not Path(path).is_file():
        raise ValueError(f"Modelgewichten ontbreken: {path}. Train eerst met echte annotaties.")
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if checkpoint.get("format") != "nibbit-amodal-v1":
        raise ValueError("Dit bestand bevat geen Nibbit Vision-model.")
    model = build_model(False, checkpoint["min_size"], checkpoint["max_size"])
    model.load_state_dict(checkpoint["model"])
    return model.to(device).eval(), checkpoint


def suppress_duplicate_masks(instances):
    """Mask-only suppression, including small contained fragment predictions.

    A true short object lying almost entirely inside another amodal mask can
    also be suppressed. Keep this ambiguity explicit in evaluation.
    """
    kept = []
    for instance in sorted(instances, key=lambda i: i['score'], reverse=True):
        area = int(instance['mask'].sum())
        duplicate = False
        for old in kept:
            old_area = int(old['mask'].sum())
            intersection = int(np.logical_and(instance['mask'], old['mask']).sum())
            union = area + old_area - intersection
            # Suppress a substantial same-status partial duplicate.
            # Keep the stronger mask unchanged: unioning unreliable fragments
            # damaged amodal IoU on development scenes. Crossing partners share
            # little area; almost coincident real sticks remain an ambiguity.
            if (instance['status'] == old['status']
                    and min(area, old_area) >= 0.5 * max(area, old_area)
                    and intersection / max(1, min(area, old_area)) >= 0.80):
                duplicate = True
                break
            if intersection / max(1, union) > 0.85:
                duplicate = True
                break
            # Only discard a lower-confidence small mask almost completely
            # contained in an already retained, substantially larger mask.
            # A normal crossing retains substantial area outside each mask.
            if area <= 0.25 * old_area and intersection / max(1, area) >= 0.98:
                duplicate = True
                break
        if not duplicate:
            # A ghost proposal can combine part of a detected stick with a
            # disconnected patch on its crossing partner. It is not contained
            # in ONE mask. Reject only fragmented proposals already largely
            # explained by higher-confidence masks, including one dominant
            # same-status match. Connected amodal predictions bypass this rule.
            import cv2
            count, _, stats, _ = cv2.connectedComponentsWithStats(instance['mask'].astype(np.uint8))
            areas = sorted(stats[1:, cv2.CC_STAT_AREA], reverse=True)
            fragmented = count > 2 and areas[1] >= max(4, 0.01 * area)
            if fragmented and kept:
                coverage = np.zeros_like(instance['mask'])
                same_status_overlap = 0.0
                for old in kept:
                    coverage |= old['mask']
                    if old['status'] == instance['status']:
                        same_status_overlap = max(same_status_overlap,
                            np.logical_and(instance['mask'], old['mask']).sum() / max(1, area))
                explained = np.logical_and(instance['mask'], coverage).sum() / max(1, area)
                if explained >= 0.85 and same_status_overlap >= 0.70:
                    continue
            # Also reject connected partial duplicates and proposals assembled
            # across different status labels. Use retained masks only: rejected
            # ghosts must never suppress a later, genuinely unexplained stick.
            # Amodal crossing partners normally extend outside this union.
            # A short, almost fully contained real object remains ambiguous.
            if kept:
                coverage = np.zeros_like(instance['mask'])
                for old in kept:
                    coverage |= old['mask']
                if np.logical_and(instance['mask'], coverage).sum() / max(1, area) >= 0.90:
                    continue
            kept.append(instance)
    return kept


def predict(model, image, device, threshold=0.5):
    import torch
    tensor = torch.from_numpy(image[:, :, ::-1].copy()).permute(2, 0, 1).float() / 255
    # Filter proposals before projecting their masks back to a 4K frame. Doing
    # this only afterwards can allocate hundreds of full-resolution masks.
    model.roi_heads.score_thresh = float(threshold)
    with torch.inference_mode():
        result = model([tensor.to(device)])[0]
    output = []
    for mask, label, score in zip(result["masks"], result["labels"], result["scores"]):
        if float(score) < threshold:
            continue
        binary = mask[0].cpu().numpy() >= 0.5
        if not binary.any():
            continue
        output.append({"mask": binary, "status": "occluded" if int(label) == 2 else "visible", "score": float(score)})
    return suppress_duplicate_masks(output)
