"""Bounded temporal support for a fixed scene, not online model training."""
from collections import deque
import math

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment


class SceneConsensus:
    def __init__(self, window=5):
        self.window = window
        self.reset()

    def reset(self):
        self.frames = 0
        self.next_id = 1
        self.tracks = []
        self.lengths = {}

    @staticmethod
    def small(mask):
        h, w = mask.shape
        scale = min(1., 960 / w)
        return cv2.resize(mask.astype(np.uint8), (round(w*scale), round(h*scale)),
                          interpolation=cv2.INTER_NEAREST).astype(bool)

    def update(self, predictions):
        self.frames += 1
        small = [self.small(p['mask']) for p in predictions]
        scores = np.zeros((len(self.tracks), len(predictions)))
        for i, track in enumerate(self.tracks):
            for j, mask in enumerate(small):
                old = track['small']
                if old.shape == mask.shape:
                    intersection = np.count_nonzero(old & mask)
                    scores[i, j] = intersection / max(1, np.count_nonzero(old | mask))
        matches = {}
        if scores.size:
            ii, jj = linear_sum_assignment(-scores)
            matches = {int(i): int(j) for i, j in zip(ii, jj) if scores[i, j] >= .35}
        used = set(matches.values())
        for i, track in enumerate(self.tracks):
            j = matches.get(i)
            track['hits'].append(j is not None)
            track['misses'] = 0 if j is not None else track['misses'] + 1
            if j is not None:
                track['prediction'] = predictions[j]
                track['small'] = small[j]
                track['statuses'].append(predictions[j]['status'])
        for j, prediction in enumerate(predictions):
            if j not in used:
                self.tracks.append({'id': self.next_id, 'prediction': prediction, 'small': small[j],
                    'hits': deque([False] * min(self.frames-1, self.window-1) + [True], maxlen=self.window),
                    'statuses': deque([prediction['status']], maxlen=self.window), 'misses': 0})
                self.next_id += 1
        self.tracks = [t for t in self.tracks if t['misses'] < self.window]
        active_ids = {t['id'] for t in self.tracks}
        self.lengths = {k: v for k, v in self.lengths.items() if k in active_ids}
        output = []
        n = min(self.frames, self.window)
        for t in self.tracks:
            hits = sum(t['hits'])
            # Show the first two frames as provisional. Later reject isolated
            # proposals, and bridge only ONE missed analysis of a supported stick.
            if hits < math.ceil(.6*n) or t['misses'] > 1:
                continue
            status = max(('visible', 'occluded'), key=lambda s: (t['statuses'].count(s), s == t['prediction']['status']))
            output.append({**t['prediction'], 'status': status, 'track_id': t['id'],
                           'temporal_hits': hits, 'temporal_window': n,
                           'temporal_provisional': n < 3, 'temporal_held': t['misses'] > 0})
        return output

    def smooth_lengths(self, rows):
        for row in rows:
            # Keep fallback guesses out of the history of usable measurements.
            value = row.get('length_mm')
            if value is not None:
                history = self.lengths.setdefault(row['id'], deque(maxlen=self.window))
                if not row.get('temporal_held') and not row.get('length_is_estimate'):
                    history.append(value)
                row['current_length_mm'] = value
                if history:
                    row['length_mm'] = float(np.median(history))
                    if row.get('length_is_estimate'):
                        row['length_estimation_method'] = 'historical_consensus'
