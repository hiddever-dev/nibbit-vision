import hashlib
import random
from pathlib import Path

import numpy as np
from scipy.optimize import linear_sum_assignment

from .data import StickDataset, group_split, load_annotations, rasterize
from .io import read_image, write_json
from .model import build_model, device_for, predict, load_model


def evaluate_records(model, records, root, device, threshold=0.5):
    tp = fp = fn = correct_status = 0
    matched_iou = []
    for record in records:
        image = read_image(root / record["file"])
        predictions = predict(model, image, device, threshold)
        truth = [rasterize(i["amodal"], image.shape[:2]) for i in record["instances"]]
        ious = np.zeros((len(truth), len(predictions)))
        for i, mask in enumerate(truth):
            for j, prediction in enumerate(predictions):
                p = prediction["mask"]
                ious[i, j] = np.logical_and(mask, p).sum() / max(1, np.logical_or(mask, p).sum())
        # Prefer the maximum number of >=0.5 matches; use IoU only as a tie-breaker.
        rows, cols = linear_sum_assignment(-((ious >= 0.5) * 1000 + ious))
        matches = [(i, j) for i, j in zip(rows, cols) if ious[i, j] >= 0.5]
        tp += len(matches)
        fp += len(predictions) - len(matches)
        fn += len(truth) - len(matches)
        for i, j in matches:
            matched_iou.append(float(ious[i, j]))
            correct_status += predictions[j]["status"] == record["instances"][i]["status"]
    return {"tp": tp, "fp": fp, "fn": fn, "f1_at_mask_iou_0_5": 2 * tp / max(1, 2 * tp + fp + fn),
            "mean_matched_amodal_iou": float(np.mean(matched_iou)) if matched_iou else None,
            "status_accuracy_on_matches": correct_status / tp if tp else None,
            "score_threshold": threshold}


def train(args):
    import torch
    from torch.utils.data import DataLoader
    if args.epochs < 1 or args.accumulate < 1:
        raise ValueError("epochs en accumulate moeten minstens 1 zijn.")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    document, root = load_annotations(args.annotations)
    records = document["images"]
    train_records, val_records = group_split(records, args.seed)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if (output / "best.pt").exists():
        raise ValueError("Kies een nieuwe uitvoermap; er staat hier al een best.pt.")
    split = {"seed": args.seed, "train": [r["file"] for r in train_records], "val": [r["file"] for r in val_records]}
    write_json(output / "split.json", split)
    device = device_for(args.device)
    print(f"Training: {len(train_records)} beelden; validatie: {len(val_records)}; apparaat: {device}")
    loader = DataLoader(StickDataset(train_records, root, augment=True), batch_size=1,
                        shuffle=True, num_workers=0, collate_fn=lambda batch: tuple(zip(*batch)))
    parent_checkpoint = None
    if getattr(args, 'initial_weights', None):
        model, parent_checkpoint = load_model(args.initial_weights, device)
        model.transform.min_size = (args.min_size,)
        model.transform.max_size = args.max_size
    else:
        model = build_model(True, args.min_size, args.max_size).to(device)
    inherited_groups = set(parent_checkpoint.get('development_groups', [])) if parent_checkpoint else set()
    if inherited_groups & {r['group_id'] for r in val_records}:
        raise ValueError('Validatiegroepen kwamen al voor in het startmodel; kies nieuwe bronnen.')
    # Prior development sources stay development sources after fine-tuning.
    lineage = {'initial_weights': str(args.initial_weights),
               'initial_weights_sha256': hashlib.sha256(Path(args.initial_weights).read_bytes()).hexdigest()} if parent_checkpoint else None
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr, weight_decay=1e-4)
    history, best_key = [], (-1.0, -1.0, -1.0)
    for epoch in range(args.epochs):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        losses = []
        for step, (images, targets) in enumerate(loader):
            images = [i.to(device) for i in images]
            targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
            loss = sum(model(images, targets).values())
            if not torch.isfinite(loss):
                raise ValueError("Niet-eindige trainingsloss; controleer beelden en annotaties.")
            losses.append(float(loss.detach()))
            if step == 0 or (step + 1) % 20 == 0:
                print(f"Epoch {epoch+1}/{args.epochs}, beeld {step+1}/{len(loader)}, loss {losses[-1]:.4f}", flush=True)
            # Normalize the final partial accumulation group by its actual size.
            group_start = (step // args.accumulate) * args.accumulate
            group_size = min(args.accumulate, len(loader) - group_start)
            (loss / group_size).backward()
            if (step + 1) % args.accumulate == 0 or step + 1 == len(loader):
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
        model.eval()
        metrics = evaluate_records(model, val_records, root, device)
        row = {"epoch": epoch + 1, "mean_training_loss": float(np.mean(losses)), **metrics}
        history.append(row)
        write_json(output / "history.json", history)
        print(row, flush=True)
        selection_key = (metrics["f1_at_mask_iou_0_5"], metrics["status_accuracy_on_matches"] or 0.0, metrics["mean_matched_amodal_iou"] or 0.0)
        if selection_key > best_key:
            best_key = selection_key
            torch.save({"format": "nibbit-amodal-v1", "model": model.state_dict(),
                        "min_size": args.min_size, "max_size": args.max_size, "epoch": epoch + 1,
                        "seed": args.seed, "metrics": metrics, "torch_version": str(torch.__version__),
                        "dataset_purpose": document.get('purpose', 'User dataset'),
                        "annotations_sha256": hashlib.sha256(Path(args.annotations).read_bytes()).hexdigest(),
                        "initialization": lineage,
                        "selection_rule": "lexicographic F1, matched status accuracy, matched amodal IoU on validation only",
                        "development_groups": sorted(inherited_groups | {r["group_id"] for r in records} |
                                                     {r["source_parent_group"] for r in records if 'source_parent_group' in r}),
                        "training_configuration": {"lr": args.lr, "accumulate": args.accumulate}}, output / "best.pt")
    print(f"Beste gewichten: {output / 'best.pt'}")
