import os
from pathlib import Path

import cv2
import numpy as np

from .geometry import make_calibration
from .io import read_image, read_json, write_json


def calibrate(args):
    image = read_image(args.image)
    scale = min(1.0, 1200 / image.shape[1], 800 / image.shape[0])
    points = []
    title = "Calibrate: TL, TR, BR, BL | ENTER save | R reset | Q cancel"
    def click(event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN and len(points) < 4:
            points.append([x / scale, y / scale])
    cv2.namedWindow(title)
    cv2.setMouseCallback(title, click)
    try:
        while True:
            display = cv2.resize(image, None, fx=scale, fy=scale)
            for i, p in enumerate(points):
                xy = tuple(np.rint(np.array(p) * scale).astype(int))
                cv2.circle(display, xy, 5, (0, 0, 255), -1)
                cv2.putText(display, str(i + 1), xy, cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            cv2.imshow(title, display)
            key = cv2.waitKey(20) & 0xff
            if key in (27, ord('q')):
                return
            if key == ord('r'):
                points.clear()
            if key == 13 and len(points) == 4:
                calibration = make_calibration(points, args.width_mm, args.height_mm, image.shape, args.setup_id)
                if Path(args.output).exists():
                    raise ValueError("Kalibratiebestand bestaat al; kies een nieuwe --output om overschrijven te voorkomen.")
                write_json(args.output, calibration)
                print(f"Vlakke voorlopige kalibratie opgeslagen: {args.output}. Controleer met onafhankelijke afstanden.")
                return
    finally:
        cv2.destroyAllWindows()


def annotate(args):
    image = read_image(args.image)
    h, w = image.shape[:2]
    scale = min(1.0, 1200 / w, 760 / h)
    destination = Path(args.annotations)
    document = read_json(destination) if destination.exists() else {"schema_version": 1, "images": []}
    name = Path(os.path.relpath(Path(args.image).resolve(), destination.resolve().parent)).as_posix()
    existing = next((r for r in document["images"] if r["file"] == name), None)
    instances = list(existing["instances"]) if existing else []
    if existing and existing["group_id"] != args.group_id:
        raise ValueError("Bestaande afbeelding heeft een andere group-id.")
    current, amodal, visible = [], [], []
    phase = "amodal"
    title = "Annotate: click outline | ENTER polygon | V visible / O occluded | C commit | S save | Q cancel"
    def click(event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            current.append([min(w - 1, max(0, x / scale)), min(h - 1, max(0, y / scale))])
    cv2.namedWindow(title)
    cv2.setMouseCallback(title, click)
    def finish_polygon():
        if current:
            if len(current) < 3:
                raise ValueError("Een polygoon heeft minimaal drie punten nodig.")
            (amodal if phase == "amodal" else visible).append(current.copy())
            current.clear()
    def commit(status):
        instances.append({"id": f"stick-{len(instances) + 1}", "status": status,
                          "z_order": len(instances), "amodal": amodal.copy(),
                          "visible": amodal.copy() if status == "visible" else visible.copy()})
        amodal.clear()
        visible.clear()
    try:
        while True:
            display = cv2.resize(image, None, fx=scale, fy=scale)
            for instance in instances:
                for polygon in instance["amodal"]:
                    cv2.polylines(display, [np.rint(np.array(polygon) * scale).astype(np.int32)], True, (0, 200, 0), 1)
            for polygons, color in ((amodal, (0, 200, 255)), (visible, (255, 150, 0))):
                for polygon in polygons:
                    cv2.polylines(display, [np.rint(np.array(polygon) * scale).astype(np.int32)], True, color, 2)
            if current:
                p = np.rint(np.array(current) * scale).astype(np.int32)
                cv2.polylines(display, [p], False, (255, 0, 255), 2)
                for xy in p:
                    cv2.circle(display, tuple(xy), 3, (255, 0, 255), -1)
            cv2.putText(display, f"{phase.upper()} | {len(instances)} sticks | bottom sticks FIRST | R reset current | D delete last",
                        (8, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (20, 20, 20), 1, cv2.LINE_AA)
            cv2.imshow(title, display)
            key = cv2.waitKey(20) & 0xff
            if key in (27, ord('q')):
                print("Geannuleerd; niets opgeslagen.")
                return
            if key == ord('r'):
                current.clear()
                amodal.clear()
                visible.clear()
                phase = "amodal"
            if key in (8, 127) and current:
                current.pop()
            if key == ord('d') and instances:
                instances.pop()
            if key == 13:
                finish_polygon()
            if key == ord('v') and phase == "amodal":
                finish_polygon()
                if amodal:
                    commit("visible")
            if key == ord('o') and phase == "amodal":
                finish_polygon()
                if amodal:
                    phase = "visible"
            if key == ord('c') and phase == "visible":
                finish_polygon()
                if visible:
                    commit("occluded")
                    phase = "amodal"
            if key == ord('s'):
                if current or amodal or visible:
                    print("Maak eerst de huidige stick af (V/C), of reset hem met R.", flush=True)
                    continue
                record = {"file": name, "size": [w, h], "group_id": args.group_id, "instances": instances}
                document["images"] = [r for r in document["images"] if r["file"] != name] + [record]
                write_json(destination, document)
                print(f"Opgeslagen: {destination}. Voer nu validate uit.")
                return
    finally:
        cv2.destroyAllWindows()
