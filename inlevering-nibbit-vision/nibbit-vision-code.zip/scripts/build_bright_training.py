"""Create a train-only composite extension from new physical training pieces.
All original validation and challenge groups remain separate.
"""
from pathlib import Path
import sys,copy
import cv2,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import *
from nibbit.data import load_annotations,rasterize,group_split
from scripts.generate_overlap_dataset import make_scene

def main():
 out=Path('data/bright-training-v1');out.mkdir(exist_ok=True)
 doc=read_json('data/bright-real-v1/annotations.json');root=Path('data/bright-real-v1');record=doc['images'][1];im=read_image(root/record['file']);sources=[]
 for i,item in enumerate(record['instances']):
  m=np.uint8(rasterize(item['amodal'],im.shape[:2]));x,y,w,h=cv2.boundingRect(m);sources.append((im[y:y+h,x:x+w].copy(),m[y:y+h,x:x+w].copy(),f'bright-physical-{i+1:02d}'))
 background=read_image(root/'empty.png')[250:1700,600:3250];rng=np.random.default_rng(20261112);records=[]
 for j in range(100):
  for attempt in range(100):
   image,instances,ids=make_scene(sources,rng,int(rng.integers(6,24)),background)
   valid=True
   for item in instances:
    full=rasterize(item['amodal'],image.shape[:2]);visible=rasterize(item['visible'],image.shape[:2])
    if not full.any() or not visible.any() or np.any(visible & ~full) or cv2.connectedComponents(np.uint8(full))[0]!=2 or (item['status']=='occluded' and np.array_equal(full,visible)):
     valid=False;break
   if valid:break
  else:raise ValueError('Could not generate valid scene')
  name=f'composite-{j:03d}.jpg';write_image(out/name,image);records.append({'file':name,'size':[1280,720],'group_id':record['group_id'],'split':'train','source_ids':sorted(set(ids)),'instances':instances})
 for path in ['data/bright-real-v1/annotations.json','data/real-overlap-v1/annotations.json']:
  d=read_json(path);base=Path(path).parent
  for r in d['images']:
   r=copy.deepcopy(r);r['file']='../'+base.name+'/'+r['file'];records.append(r)
 document={'schema_version':1,'purpose':'Train-only new bright physical set + real controlled pairs + 100 synthetic composites, with original independent real pair 5 validation. No challenge sources.','seed':20261112,'limitations':['Composite shadows and height not physically rendered','Only one original real validation image; no independent final benchmark','Hidden labels are approximate interpolations from controlled references'],'images':records}
 write_json(out/'annotations.json',document);tr,va=group_split(records);load_annotations(out/'annotations.json');print(len(tr),'train',len(va),'val; sources',len(sources),flush=True)
if __name__=='__main__':main()
