"""Build a metric homography from measured marker separations, without GUI."""
import argparse
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nibbit.geometry import make_calibration, transform_points, verify_calibration
from nibbit.io import read_json, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--markers', required=True)
    parser.add_argument('--width-mm', type=float, required=True)
    parser.add_argument('--height-mm', type=float, required=True)
    parser.add_argument('--tolerance-mm', type=float, default=0)
    parser.add_argument('--setup-id', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.tolerance_mm < 0 or args.tolerance_mm >= min(args.width_mm, args.height_mm):
        raise ValueError('Tolerantie moet positief of nul en kleiner dan de afmetingen zijn.')
    destination = Path(args.output)
    if destination.exists():
        raise ValueError('Uitvoer bestaat al. Kies een nieuwe naam voor een nieuwe kalibratie.')
    source = read_json(args.markers)
    w, h = source['image_size']
    points = source['marker_centers_pixels_tl_tr_br_bl']
    calibration = make_calibration(points, args.width_mm, args.height_mm, (h, w), args.setup_id)
    calibration.update({
        'validation_status': 'preliminary_not_independently_validated',
        'source_image_sha256': source['source_sha256'],
        'source_markers_file': Path(args.markers).as_posix(),
        'reference_dimension_tolerance_mm': args.tolerance_mm,
        'tolerance_interpretation': 'Voor foutbegroting behandeld als +/- tolerantie per referentieafmeting; geen statistische nauwkeurigheid.',
        'applies_to': 'Alleen beelden met dezelfde camera, optiek, framing en resolutie als de markerfoto.',
        'earlier_eight_images': 'Niet toepassen: gebruiker meldt een mogelijke kleine wijziging in de beeldkadering.',
    })
    verify_calibration(calibration, (h, w), args.setup_id)
    expected = np.float64([[0, 0], [args.width_mm, 0],
                           [args.width_mm, args.height_mm], [0, args.height_mm]])
    mapped = transform_points(points, calibration['image_to_mm'])
    error = float(np.linalg.norm(mapped - expected, axis=1).max())
    if error > 0.001:
        raise ValueError('Interne transformatiecontrole mislukt.')
    # This self-consistency check uses the same four fit points, not independent truth.
    calibration['internal_fit_max_error_mm'] = error
    calibration['internal_fit_note'] = 'Geen onafhankelijke meetcontrole; vier paspunten bepalen de transformatie.'
    center = np.float64([[args.width_mm / 2, args.height_mm / 2],
                         [args.width_mm / 2 + 10, args.height_mm / 2],
                         [args.width_mm / 2, args.height_mm / 2 + 10]])
    pixels = transform_points(center, np.linalg.inv(calibration['image_to_mm']))
    calibration['approx_center_pixels_per_mm'] = {
        'horizontal': float(np.linalg.norm(pixels[1] - pixels[0]) / 10),
        'vertical': float(np.linalg.norm(pixels[2] - pixels[0]) / 10),
    }
    calibration['reference_scale_relative_tolerance'] = {
        'horizontal': args.tolerance_mm / args.width_mm,
        'vertical': args.tolerance_mm / args.height_mm,
        'note': 'Alleen referentieafmetingen; lens-, hoogte-, masker- en middenlijnfouten ontbreken.'
    }
    write_json(destination, calibration)
    print(f'Voorlopige kalibratie opgeslagen: {destination}')
    print(calibration['approx_center_pixels_per_mm'])
    print('Numerieke paspuntcontrole geslaagd. Onafhankelijke nauwkeurigheid nog niet gecontroleerd.')


if __name__ == '__main__':
    main()
