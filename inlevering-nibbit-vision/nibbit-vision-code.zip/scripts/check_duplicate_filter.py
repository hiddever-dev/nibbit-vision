"""Regression on development images, not an independent benchmark."""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit import model as models
from nibbit.data import load_annotations
from nibbit.io import write_json
from nibbit.training import evaluate_records

def old_filter(instances):
 kept=[]
 for p in sorted(instances,key=lambda p:p['score'],reverse=True):
  if not any((p['mask'] & q['mask']).sum()/max(1,(p['mask'] | q['mask']).sum())>.95 for q in kept):kept.append(p)
 return kept

def main():
 doc,root=load_annotations('data/real-overlap-v1/annotations.json')
 device=models.device_for('cuda');model,_=models.load_model('runs/bright-overlap-01/best.pt',device)
 new_filter=models.suppress_duplicate_masks;results={}
 for name,fn in [('before',old_filter),('after',new_filter)]:
  models.suppress_duplicate_masks=fn
  results[name]=evaluate_records(model,doc['images'],root,device)
  print(name,results[name],flush=True)
 models.suppress_duplicate_masks=new_filter
 results['scope']='Five existing development/validation pair images, 57 instances. Not an independent benchmark. No thresholds tuned on challenge.'
 write_json('runs/duplicate-filter-v1/regression.json',results)
if __name__=='__main__':main()
