"""Independent paper-strip check using an existing, unchanged calibration."""
import argparse
import hashlib
from pathlib import Path
import shutil
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nibbit.geometry import measure, verify_calibration
from nibbit.io import read_image, read_json, write_image, write_json


def segment_strips(image, threshold):
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    mask = np.zeros((h, w), np.uint8)
    # Exclude calibration marks near the outside corners.
    y0, y1, x0, x1 = round(.15*h), round(.85*h), round(.15*w), round(.85*w)
    mask[y0:y1, x0:x1] = np.uint8(gray[y0:y1, x0:x1] < threshold)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    strips = []
    for contour in contours:
        x, y, cw, ch = cv2.boundingRect(contour)
        if cv2.contourArea(contour) < 5000 or max(cw, ch) / min(cw, ch) < 4:
            continue
        full = np.zeros_like(mask)
        cv2.drawContours(full, [contour], -1, 1, -1)
        strips.append(('horizontal' if cw > ch else 'vertical', full))
    if sorted(direction for direction, _ in strips) != ['horizontal', 'vertical']:
        raise ValueError(f'Bij drempel {threshold} niet precies een horizontale en een verticale strook gevonden.')
    return strips


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--image', required=True)
    p.add_argument('--calibration', required=True)
    p.add_argument('--setup-id', required=True)
    p.add_argument('--reference-mm', type=float, default=50)
    p.add_argument('--output', default='calibration/reference-check-50mm')
    args = p.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    image = read_image(args.image)
    calibration = read_json(args.calibration)
    verify_calibration(calibration, image.shape, args.setup_id)
    before = Path(args.calibration).read_bytes()
    source_copy = output / ('source' + Path(args.image).suffix.lower())
    if source_copy.exists() and source_copy.read_bytes() != Path(args.image).read_bytes():
        raise ValueError('Er staat al een andere bronfoto in deze uitvoermap.')
    if source_copy.resolve() != Path(args.image).resolve():
        shutil.copy2(args.image, source_copy)
    overlay = image.copy()
    checks = []
    for direction, mask in segment_strips(image, 110):
        result = measure(mask, calibration)
        if result['length_mm'] is None:
            raise ValueError(f'Geen geldige lengte voor {direction}: {result["measurement_status"]}')
        error = result['length_mm'] - args.reference_mm
        checks.append({'direction': direction, 'reference_mm': args.reference_mm,
                       'measured_mm': result['length_mm'], 'error_mm': error,
                       'relative_error_percent': error / args.reference_mm * 100,
                       'length_px': result['length_px'], 'spine_pixels': result['spine_pixels']})
        color = (40, 220, 80) if direction == 'horizontal' else (0, 160, 255)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours, -1, color, 4)
        points = np.rint(result['spine_pixels']).astype(np.int32)
        cv2.polylines(overlay, [points], False, (255, 0, 200), 3)
        y, x = np.where(mask)
        cv2.putText(overlay, f'{direction}: {result["length_mm"]:.2f} mm (ref. 50 mm)',
                    (int(x.min()) - 100, int(y.min()) - 30), cv2.FONT_HERSHEY_SIMPLEX, 1.15, color, 3, cv2.LINE_AA)
    sensitivity = {}
    sensitivity_failures = []
    for threshold in [100, 105, 110, 115, 120]:
        try:
            alternatives = segment_strips(image, threshold)
        except ValueError as error:
            sensitivity_failures.append({'threshold': threshold, 'error': str(error)})
            continue
        for direction, mask in alternatives:
            result = measure(mask, calibration)
            sensitivity.setdefault(direction, []).append({'threshold': threshold, 'measured_mm': result['length_mm']})
    report = {'source_sha256': hashlib.sha256(Path(args.image).read_bytes()).hexdigest(),
              'calibration_sha256': hashlib.sha256(before).hexdigest(),
              'calibration_file': Path(args.calibration).as_posix(),
              'setup_id': args.setup_id, 'threshold_used': 110,
              'checks': checks, 'threshold_sensitivity': sensitivity,
              'threshold_sensitivity_failures': sensitivity_failures,
              'method': 'Grayscale segmentation of paper, filled external contours, shared spine measurement; no Nibbit model.',
              'calibration_changed': False,
              'scope': 'Twee door gebruiker als 50 mm opgegeven vlakke rechte stroken, op deze posities en in deze foto.',
              'limitations': 'Geen totale nauwkeurigheidsgarantie. Knip/meetfout van papier onbekend; lens- en hoogtefouten op andere plekken of bij Nibbits niet bepaald.'}
    write_json(output / 'measurement.json', report)
    cv2.putText(overlay, 'REFERENCE CHECK - PAPER SEGMENTATION - NO NIBBIT MODEL', (150, image.shape[0] - 160),
                cv2.FONT_HERSHEY_SIMPLEX, 1.25, (20, 20, 20), 3, cv2.LINE_AA)
    write_image(output / 'measurement.jpg', cv2.resize(overlay, (1536, 864)))
    assert before == Path(args.calibration).read_bytes(), 'Kalibratie mag niet aangepast worden tijdens deze controle.'
    print([{k: v for k, v in row.items() if k != 'spine_pixels'} for row in checks])
    print({k: [r['measured_mm'] for r in v] for k, v in sensitivity.items()})


if __name__ == '__main__':
    main()
