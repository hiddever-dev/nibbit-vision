"""Synthetic amodal pilot data from isolated real cutouts. Not a real test benchmark."""
import argparse
from pathlib import Path
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nibbit.data import load_annotations, rasterize, group_split
from nibbit.io import read_image, read_json, write_image, write_json


def polygons(mask):
    contours, _ = cv2.findContours(np.uint8(mask), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return [c[:, 0, :].tolist() for c in contours if cv2.contourArea(c) > 0]


def transformed(source, rng):
    image, mask, source_id = source
    scale = rng.uniform(.27, .39)
    image = cv2.resize(image, None, fx=scale, fy=scale)
    mask = cv2.resize(mask, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_NEAREST)
    if rng.random() < .3:
        axis = int(rng.integers(2))
        cut = int(mask.shape[axis] * rng.uniform(.25, .75))
        if axis == 0:
            mask[:cut] = 0
        else:
            mask[:, :cut] = 0
        n, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
        if n > 1:
            mask = np.uint8(labels == (1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])))
    side = int(np.hypot(*mask.shape)) + 8
    matrix = cv2.getRotationMatrix2D((mask.shape[1]/2, mask.shape[0]/2), float(rng.uniform(0, 360)), 1)
    matrix[:, 2] += [side/2 - mask.shape[1]/2, side/2 - mask.shape[0]/2]
    image = cv2.warpAffine(image, matrix, (side, side), flags=cv2.INTER_LINEAR)
    mask = cv2.warpAffine(mask, matrix, (side, side), flags=cv2.INTER_NEAREST)
    return image, mask, source_id


def make_group(sources, rng, paired):
    items = []
    canvas = 400
    first = transformed(sources[int(rng.integers(len(sources)))], rng)
    for index in range(2 if paired else 1):
        image, mask, source_id = first if index == 0 else transformed(sources[int(rng.integers(len(sources)))], rng)
        dx, dy = (0, 0) if index == 0 else rng.integers(-25, 26, 2)
        h, w = mask.shape
        x, y = (canvas-w)//2 + int(dx), (canvas-h)//2 + int(dy)
        full = np.zeros((canvas, canvas), np.uint8)
        rgb = np.zeros((canvas, canvas, 3), np.uint8)
        if x < 0 or y < 0 or x+w > canvas or y+h > canvas:
            return None
        full[y:y+h, x:x+w] = mask
        rgb[y:y+h, x:x+w] = image
        items.append((rgb, full, source_id))
    if paired:
        overlap = (items[0][1] > 0) & (items[1][1] > 0)
        visible = (items[0][1] > 0) & ~overlap
        if overlap.sum() < 10 or visible.sum() < max(30, .25 * items[0][1].sum()):
            return None
    union = np.maximum.reduce([m for _, m, _ in items])
    x, y, w, h = cv2.boundingRect(union)
    return [(rgb[y:y+h, x:x+w], m[y:y+h, x:x+w], sid) for rgb, m, sid in items]


def make_scene(sources, rng, count, background_image=None):
    h, w = 720, 1280
    y, x = np.mgrid[:h, :w]
    level = rng.uniform(135, 205) + (x/w-.5)*rng.uniform(-10, 10) + (y/h-.5)*rng.uniform(-10, 10)
    background = np.uint8(np.clip(level + rng.normal(0, .7, (h, w)), 0, 255))
    image = np.repeat(background[:, :, None], 3, axis=2)
    if background_image is not None:
        image = cv2.resize(background_image, (w, h)).copy()
        image = np.uint8(np.clip(image.astype(float) * rng.uniform(.92, 1.08) + rng.uniform(-6, 6), 0, 255))
    occupied = np.zeros((h, w), np.uint8)
    masks, source_ids, status = [], [], []
    for _ in range(1500):
        if len(masks) >= count:
            break
        group = make_group(sources, rng, paired=(len(masks)+2 <= count and rng.random() < .65))
        if group is None:
            continue
        gh, gw = group[0][1].shape
        if gh >= h-40 or gw >= w-40:
            continue
        px, py = int(rng.integers(20, w-gw-20)), int(rng.integers(20, h-gh-20))
        union = np.maximum.reduce([m for _, m, _ in group])
        clearance = cv2.dilate(union, np.ones((7, 7), np.uint8))
        if np.any(occupied[py:py+gh, px:px+gw] & clearance):
            continue
        start = len(masks)
        for gi, (rgb, local, sid) in enumerate(group):
            full = np.zeros((h, w), np.uint8)
            full[py:py+gh, px:px+gw] = local
            selected = local > 0
            image[py:py+gh, px:px+gw][selected] = rgb[selected]
            masks.append(full)
            source_ids.append(sid)
            status.append('occluded' if len(group) == 2 and gi == 0 else 'visible')
        occupied[py:py+gh, px:px+gw] |= union
    if len(masks) < count:
        raise ValueError('Kon geen volledige synthetische scène plaatsen; probeer een andere seed.')
    instances = []
    for i, (full, sid, state) in enumerate(zip(masks, source_ids, status)):
        visible = full if state == 'visible' else np.uint8((full > 0) & (masks[i+1] == 0))
        instances.append({'id': f'stick-{i+1}', 'status': state, 'z_order': i,
                          'amodal': polygons(full), 'visible': polygons(visible), 'source_id': sid})
    return image, instances, source_ids


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--annotations', default='data/isolated-raw-v3/annotations.json')
    p.add_argument('--output', default='data/synthetic-pilot-v1')
    p.add_argument('--train-count', type=int, default=100)
    p.add_argument('--val-count', type=int, default=20)
    p.add_argument('--seed', type=int, default=42)
    args = p.parse_args()
    doc = read_json(args.annotations)
    root = Path(args.annotations).parent
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if (output/'annotations.json').exists():
        raise ValueError('Er bestaat al een dataset; kies een andere uitvoermap.')
    # Use ONE photograph only: its ten masks refer to ten distinct physical sticks.
    # Reusing alternate views without identity matching would leak held-out sticks.
    record = doc['images'][0]
    image = read_image(root/record['file'])
    sources = []
    for i, instance in enumerate(record['instances'], 1):
        mask = np.uint8(rasterize(instance['amodal'], image.shape[:2]))
        x, y, w, h = cv2.boundingRect(mask)
        sources.append((image[y:y+h, x:x+w].copy(), mask[y:y+h, x:x+w].copy(), f'physical-A-{i:02d}'))
    if len(sources) != 10:
        raise ValueError('Deze pilot verwacht de tien gecontroleerde objecten uit de eerste opname.')
    held_out = {1, 2}  # one yellow and one red stick; zero-based indices in first photograph.
    partitions = {'train': [s for i,s in enumerate(sources) if i not in held_out],
                  'val': [s for i,s in enumerate(sources) if i in held_out]}
    rng = np.random.default_rng(args.seed)
    records = []
    for split, count in [('train', args.train_count), ('val', args.val_count)]:
        for number in range(count):
            picture, instances, ids = make_scene(partitions[split], rng, int(rng.integers(8, 21)))
            name = f'{split}_{number:04d}.jpg'
            write_image(output/name, picture)
            records.append({'file': name, 'size': [1280, 720], 'split': split,
                            'group_id': f'synthetic-pilot-A-{split}',
                            'source_parent_group': record['group_id'],
                            'source_ids': sorted(set(ids)), 'instances': instances})
        print(f'{split}: {count} beelden gegenereerd.', flush=True)
    result = {'schema_version': 1, 'purpose': 'SYNTHETIC PILOT ONLY - no real occlusion benchmark',
              'seed': args.seed, 'source_annotations': Path(args.annotations).as_posix(),
              'source_partition': {key: [s[2] for s in pool] for key,pool in partitions.items()},
              'limitations': 'Slechts 10 fysieke bronsticks, 8 train/2 val. Kunstmatige achtergrond en overlap; echte schaduwen, hoogte en andere sticks nog testen.',
              'images': records}
    write_json(output/'annotations.json', result)
    group_split(records)
    load_annotations(output/'annotations.json')
    print(f'Dataset en overlapregels gecontroleerd: {output}')


if __name__ == '__main__':
    main()
