"""Find four dark corner marks. Does not assume physical marker distances."""
import argparse
import hashlib
from pathlib import Path
import shutil
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nibbit.io import read_image, write_image, write_json


def locate(image, expected_points=None, search_radius=60):
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    count, _, stats, centers = cv2.connectedComponentsWithStats(np.uint8(gray < 70))
    corners = []
    targets = expected_points if expected_points is not None else [(0, 0), (w, 0), (w, h), (0, h)]
    if len(targets) != 4:
        raise ValueError('Vier verwachte markerposities nodig.')
    for expected_x, expected_y in targets:
        candidates = [i for i in range(1, count)
                      if 30 <= stats[i, cv2.CC_STAT_AREA] <= 5000
                      and stats[i, cv2.CC_STAT_WIDTH] >= 5
                      and stats[i, cv2.CC_STAT_HEIGHT] >= 5
                      and max(stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT])
                          / min(stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]) < 3
                      and (np.linalg.norm(centers[i] - np.array([expected_x, expected_y])) < search_radius
                           if expected_points is not None else
                           abs(centers[i, 0] - expected_x) < .35 * w
                           and abs(centers[i, 1] - expected_y) < .35 * h)]
        if len(candidates) != 1:
            raise ValueError("Niet precies één donker merkteken per hoek gevonden. Selecteer hoeken handmatig.")
        corners.append(centers[candidates[0]].tolist())
    return corners


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True)
    parser.add_argument('--output', default='calibration/marked-board-pending')
    args = parser.parse_args()
    source, output = Path(args.image), Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    image = read_image(source)
    points = locate(image)
    source_copy = output / ('source' + source.suffix.lower())
    if source.resolve() != source_copy.resolve():
        if source_copy.exists() and source_copy.read_bytes() != source.read_bytes():
            raise ValueError('Er staat al een andere bronfoto in deze map; kies een nieuwe uitvoermap.')
        shutil.copy2(source, source_copy)
    write_json(output / 'markers.pending.json', {
        'schema_version': 1,
        'status': 'MARKERS_ONLY_NOT_A_METRIC_CALIBRATION',
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'image_size': [image.shape[1], image.shape[0]],
        'marker_centers_pixels_tl_tr_br_bl': points,
        'physical_marker_width_mm': None,
        'physical_marker_height_mm': None,
        'pending': ['Werkelijke afstanden tussen de markercentra',
                    'Bevestiging bij welke camera/zoom/uitsnede de foto hoort'],
    })
    display = image.copy()
    cv2.polylines(display, [np.rint(points).astype(np.int32)], True, (0, 180, 255), 5)
    h, w = image.shape[:2]
    for i, (x, y) in enumerate(points):
        cv2.circle(display, (round(x), round(y)), 18, (0, 0, 255), 4)
        tx = 90 if x < w / 2 else w - 750
        ty = 150 if y < h / 2 else h - 130
        cv2.putText(display, f'{i+1}: ({x:.1f}, {y:.1f}) px', (tx, ty),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 160), 3, cv2.LINE_AA)
    cv2.putText(display, 'MARKERINGEN GEVONDEN - AFSTANDEN NOG CONTROLEREN', (100, h // 2),
                cv2.FONT_HERSHEY_SIMPLEX, 1.4, (30, 30, 30), 3, cv2.LINE_AA)
    write_image(output / 'markercontrole.jpg', cv2.resize(display, (1536, 864)))
    print(f'Vier markercentra opgeslagen in {output}. Nog geen mm-kalibratie.')


if __name__ == '__main__':
    main()
