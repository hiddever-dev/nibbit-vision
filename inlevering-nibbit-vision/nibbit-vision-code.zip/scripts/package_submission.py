"""Build the three deliverables and a clonable Git bundle; standard library only."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if git('status', '--porcelain'):
        raise SystemExit('Commit eerst alle codewijzigingen; er zijn nog niet vastgelegde bestanden.')
    metadata = json.loads((ROOT / 'runs/bright-overlap-01/model_manifest.json').read_text())
    checks = {
        'runs/bright-overlap-01/best.pt': metadata['weights_sha256'],
        'runs/pilot-synthetic-01/best.pt': metadata['initialization']['initial_weights_sha256'],
        'data/bright-training-v1/annotations.json': metadata['annotations_sha256'],
    }
    for name, expected in checks.items():
        if sha256(ROOT / name) != expected:
            raise SystemExit(f'Checksum klopt niet: {name}')
    subprocess.run(['git', '-C', str(ROOT), 'archive', '--format=zip',
                    f'--output={output / "nibbit-vision-code.zip"}', 'HEAD'], check=True)
    bundle = output / 'nibbit-vision.git.bundle'
    if bundle.exists():
        bundle.unlink()
    subprocess.run(['git', '-C', str(ROOT), 'bundle', 'create', str(bundle), '--all'], check=True)
    with zipfile.ZipFile(output / 'nibbit-vision-dataset.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
        for path in sorted((ROOT / 'data').rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                archive.write(path, path.relative_to(ROOT).as_posix())
        archive.write(ROOT / 'docs/DATASET.md', 'data/README_DATASET.md')
    with zipfile.ZipFile(output / 'nibbit-vision-weights.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
        for run in ('bright-overlap-01', 'pilot-synthetic-01'):
            for path in sorted((ROOT / 'runs' / run).iterdir()):
                if path.is_file() and path.suffix in ('.pt', '.json', '.txt', '.log'):
                    archive.write(path, path.relative_to(ROOT).as_posix())
    manifest = {'git_commit': git('rev-parse', 'HEAD'), 'model_checks': checks, 'artifacts': {}}
    for path in sorted(output.iterdir()):
        if path.suffix in ('.zip', '.bundle'):
            if path.suffix == '.zip':
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        raise SystemExit(f'Beschadigd archief: {path.name}')
            manifest['artifacts'][path.name] = {'bytes': path.stat().st_size, 'sha256': sha256(path)}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    (output / 'INLEVEREN.txt').write_text(
        'Nibbit Vision - inleverpakket\n\n'
        '1. Clone de Git-bundle: git clone nibbit-vision.git.bundle nibbit-vision\n'
        '   Of pak nibbit-vision-code.zip uit in een lege map.\n'
        '2. Pak nibbit-vision-dataset.zip en nibbit-vision-weights.zip uit IN die projectmap.\n'
        '   Dan staan data/, runs/ en nibbit/ naast elkaar.\n'
        '3. Volg README.md voor installatie, gebruik en opnieuw trainen.\n\n'
        'De Git-bundle bevat de echte Git-repository. Er is geen remote publicatie nodig om te clonen.\n'
        'manifest.json bevat de commit en SHA-256-controlesommen van de bestanden.\n', encoding='utf-8')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
