"""Build draft full-instance labels from isolated lower/reference and crossing images.
Color thresholding and polynomial interpolation are annotation aids, never inference.
"""
from pathlib import Path
import sys,hashlib,shutil
import cv2,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import *
from nibbit.data import load_annotations
from scripts.prepare_isolated_sticks import foreground_masks
from scripts.locate_calibration_markers import locate

def poly(m):
 cs,_=cv2.findContours(np.uint8(m),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 return [c[:,0].tolist() for c in cs if cv2.contourArea(c)>2]
def largest(m):
 n,l,s,_=cv2.connectedComponentsWithStats(np.uint8(m));return np.uint8(l==1+np.argmax(s[1:,4]))
def upper_mask(lower,fg):
 new=(fg>0)&(cv2.dilate(lower,np.ones((17,17),np.uint8))==0)
 yy,xx=np.where(new);pts=np.c_[xx,yy].astype(float);center=pts.mean(0)
 _,_,vh=np.linalg.svd(pts-center,full_matrices=False);axis=vh[0];normal=np.array([-axis[1],axis[0]])
 uv=np.c_[(pts-center)@axis,(pts-center)@normal];bins=np.linspace(uv[:,0].min(),uv[:,0].max(),24)
 means=[];widths=[]
 for a,b in zip(bins[:-1],bins[1:]):
  v=uv[(uv[:,0]>=a)&(uv[:,0]<b)]
  if len(v)>12:means.append([np.mean(v[:,0]),np.mean(v[:,1])]);widths.append(np.quantile(v[:,1],.98)-np.quantile(v[:,1],.02))
 means=np.array(means);fit=np.polyfit(means[:,0],means[:,1],2)
 half=max(5,float(np.median(widths))/2+2)
 y,x=np.mgrid[:fg.shape[0],:fg.shape[1]];u=(x-center[0])*axis[0]+(y-center[1])*axis[1];v=(x-center[0])*normal[0]+(y-center[1])*normal[1]
 tube=np.abs(v-np.polyval(fit,u))<half
 outside=cv2.dilate(lower,np.ones((11,11),np.uint8))==0
 candidate=np.uint8((fg>0)&(tube|(outside&(np.abs(v-np.polyval(fit,u))<half*2))))
 return largest(cv2.morphologyEx(candidate,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))),{'half_width_px':half,'fit_coefficients':fit.tolist()}

def main():
 root=Path('.');fs=sorted((root/'data/raw/training-bright-v1').glob('*.png'));out=root/'data/bright-real-v1';review=root/'review/training-bright-v1';out.mkdir(exist_ok=True)
 records=[];manifest=[];tiles=[];refpoints=locate(read_image(fs[0]));group='training-bright-physical-set-2026-11-12'
 def add(source,instances,name):
  shutil.copy2(source,out/name);records.append({'file':name,'size':[3840,2160],'group_id':group,'split':'train','instances':instances})
 def instance(name,m,upper=None):
  vis=m if upper is None else m&(1-upper)
  return {'id':name,'status':'visible' if upper is None else 'occluded','z_order':1 if name=='upper' else 0,'amodal':poly(m),'visible':poly(vis)}
 add(fs[0],[],'empty.png')
 isolated=foreground_masks(read_image(fs[1]));add(fs[1],[instance(f'piece-{i+1}',m) for i,m in enumerate(isolated)],'isolated.png')
 for k in range(2,len(fs),2):
  idx=(k-2)//2+1;a,b=map(read_image,fs[k:k+2]);old=foreground_masks(a);assert len(old)==1
  fg=largest(np.maximum.reduce(foreground_masks(b)));lower=old[0]
  # Align the reference silhouette to the union within a small translation window.
  x,y,w,h=cv2.boundingRect(fg|lower);pad=25;x0=max(0,x-pad);y0=max(0,y-pad);x1=min(3840,x+w+pad);y1=min(2160,y+h+pad)
  low=lower[y0:y1,x0:x1];fore=fg[y0:y1,x0:x1];best=(-1,None,None)
  for dy in range(-10,11):
   for dx in range(-10,11):
    shifted=cv2.warpAffine(low,np.float32([[1,0,dx],[0,1,dy]]),(low.shape[1],low.shape[0]),flags=cv2.INTER_NEAREST)
    score=float((shifted&fore).sum())/max(1,shifted.sum())-.0001*(dx*dx+dy*dy)
    if score>best[0]:best=(score,(dx,dy),shifted)
  score,shift,low=best;up,fit=upper_mask(low,fore)
  low_vis=(fore>0)&(up==0)&(cv2.distanceTransform(1-low,cv2.DIST_L2,3)<14)
  low=largest(cv2.morphologyEx(np.uint8(low_vis|((low>0)&(up>0))),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8)))
  full_lower=np.zeros_like(lower);full_upper=np.zeros_like(lower);full_lower[y0:y1,x0:x1]=low;full_upper[y0:y1,x0:x1]=up
  instances=[instance('lower',full_lower,full_upper),instance('upper',full_upper)]
  add(fs[k],[instance('lower',old[0])],f'pair-{idx:02d}-before.png');add(fs[k+1],instances,f'pair-{idx:02d}-after.png')
  pts=np.array(locate(b,expected_points=refpoints));shiftmark=float(np.linalg.norm(pts-refpoints,axis=1).max())
  manifest.append({'pair':idx,'before':fs[k].name,'after':fs[k+1].name,'before_sha256':hashlib.sha256(fs[k].read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(fs[k+1].read_bytes()).hexdigest(),'lower_translation_px':list(shift),'reference_coverage_score':score,'marker_shift_px':shiftmark,**fit})
  overlay=b[y0:y1,x0:x1].copy()
  for m,c in [(low,(0,170,255)),(up,(40,230,50))]:
   cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);cv2.drawContours(overlay,cs,-1,c,2)
  sc=min(550/overlay.shape[1],380/overlay.shape[0]);sm=cv2.resize(overlay,None,fx=sc,fy=sc);tile=np.full((420,570,3),240,np.uint8);tile[40:40+sm.shape[0],:sm.shape[1]]=sm
  cv2.putText(tile,f'{idx:02d} LABELS ONLY - orange=lower',(8,27),0,.6,(0,0,0),1);write_image(review/f'labels-{idx:02d}.jpg',tile);tiles.append(tile)
  print(idx,'translation',shift,'coverage',round(score,3),'marker',round(shiftmark,2),flush=True)
 doc={'schema_version':1,'purpose':'Bright real training only; approximate amodal labels from controlled references','review_status':'draft_pending_visual_review','images':records};write_json(out/'annotations.proposals.json',doc);write_json(out/'manifest.json',manifest)
 load_annotations(out/'annotations.proposals.json')
 for n in range(0,len(tiles),6):
  page=tiles[n:n+6]
  if len(page)%2:page.append(np.full_like(tiles[0],240))
  write_image(review/f'label-sheet-{n//6+1}.jpg',np.vstack([np.hstack(page[i:i+2]) for i in range(0,len(page),2)]))
if __name__=='__main__':main()
