"""Prepare instance-mask annotations from isolated sticks; annotation assistance only."""
import argparse
import hashlib
from pathlib import Path
import shutil
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nibbit.data import load_annotations, rasterize
from nibbit.geometry import measure, verify_calibration
from nibbit.io import read_image, read_json, write_image, write_json
from scripts.locate_calibration_markers import locate


def foreground_masks(image, saturation=65):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    white = np.uint8(gray > 80)
    contours, _ = cv2.findContours(white, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    board = max(contours, key=cv2.contourArea)
    if cv2.contourArea(board) < image.shape[0] * image.shape[1] / 3:
        raise ValueError('Geen voldoende groot lichtbord gevonden.')
    board_mask = np.zeros(gray.shape, np.uint8)
    cv2.drawContours(board_mask, [board], -1, 1, -1)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    binary = np.uint8(((hsv[:, :, 0] <= 40) | (hsv[:, :, 0] >= 170)) & (hsv[:, :, 1] > saturation) &
                     (hsv[:, :, 2] > 35) & (board_mask > 0))
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    masks = []
    for contour in contours:
        # This is a noise threshold for this annotation tool, not the 5mm rule.
        if cv2.contourArea(contour) < 1000:
            continue
        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [contour], -1, 1, -1)
        masks.append(mask)
    masks.sort(key=lambda m: (int(np.where(m)[0].min()), int(np.where(m)[1].min())))
    return masks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', default='data/raw/lumina-raw-v3')
    parser.add_argument('--output', default='data/isolated-raw-v3')
    parser.add_argument('--review-dir', default='review/isolated-raw-v3')
    parser.add_argument('--calibration', default='calibration/lumina-raw-v3.json')
    parser.add_argument('--group-id', default='raw-v3-physical-set-A')
    args = parser.parse_args()
    sources = sorted(Path(args.source_dir).glob('*.png'))
    if not sources:
        raise ValueError('Geen PNG-opnames gevonden.')
    output, review = Path(args.output), Path(args.review_dir)
    output.mkdir(parents=True, exist_ok=True)
    review.mkdir(parents=True, exist_ok=True)
    calibration = read_json(args.calibration)
    records, manifest, measurements, tiles = [], [], [], []
    for index, source in enumerate(sources, 1):
        image = read_image(source)
        h, w = image.shape[:2]
        verify_calibration(calibration, image.shape, calibration['setup_id'])
        centers = np.asarray(locate(image, expected_points=calibration['roi_pixels']))
        shift = np.linalg.norm(centers - np.asarray(calibration['roi_pixels']), axis=1)
        if shift.max() > 12:
            raise ValueError(f'Markerposities wijken >12 px af in {source.name}; controleer de opstelling.')
        masks = foreground_masks(image)
        sensitivity = {str(t): len(foreground_masks(image, t)) for t in [55, 65, 75, 85]}
        name = f'{index:02d}_isolated.png'
        target = output / name
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Er bestaat al een ander beeld: {target}')
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        instances = []
        overlay = image.copy()
        for j, mask in enumerate(masks, 1):
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            polygons = [c[:, 0, :].tolist() for c in contours]
            instances.append({'id': f'stick-{j}', 'status': 'visible', 'z_order': 0,
                              'amodal': polygons, 'visible': polygons,
                              'annotation_method': 'HSV contour, filled silhouette; no SAM'})
            result = measure(mask, calibration)
            measurements.append({'image': name, 'instance': f'stick-{j}', **result})
            selected = mask.astype(bool)
            overlay[selected] = np.uint8(overlay[selected] * .65 + np.array([40, 240, 80]) * .35)
            cv2.drawContours(overlay, contours, -1, (50, 240, 80), 3)
            yy, xx = np.where(mask)
            cv2.putText(overlay, str(j), (int(xx.min()), max(40, int(yy.min())-12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (20, 20, 20), 3, cv2.LINE_AA)
        record = {'file': name, 'size': [w, h], 'group_id': args.group_id, 'instances': instances}
        records.append(record)
        manifest.append({'file': name, 'source_file': source.name, 'sha256': digest,
                         'instance_count': len(masks), 'saturation_count_check': sensitivity,
                         'maximum_marker_displacement_px': float(shift.max())})
        write_image(review / f'{index:02d}_masks.jpg', cv2.resize(overlay, (1920, 1080)))
        tile = cv2.resize(overlay, (960, 540))
        header = np.full((40, 960, 3), 20, np.uint8)
        cv2.putText(header, f'{name}: {len(masks)} MASK ANNOTATIONS - NOT MODEL PREDICTIONS',
                    (10, 27), cv2.FONT_HERSHEY_SIMPLEX, .57, (255,255,255), 1, cv2.LINE_AA)
        tiles.append(np.vstack([header, tile]))
        print(f'{source.name}: {len(masks)} instanties; markerafwijking {shift.max():.2f} px; controle {sensitivity}', flush=True)
    document = {'schema_version': 1, 'review_status': 'automatic_masks_pending_visual_review',
                'method': 'Isolated-object annotation assistance by HSV; not a Nibbit recognition model.',
                'source_identity_note': 'Bronsticks mogelijk hergebruikt; alle beelden conservatief dezelfde groep.',
                'images': records}
    write_json(output / 'annotations.proposals.json', document)
    write_json(output / 'manifest.json', manifest)
    write_json(review / 'length_estimates.json', {'note': 'Voorlopige maskerlengtes, geen onafhankelijke referentiemetingen.',
                                                'calibration': args.calibration, 'instances': measurements})
    load_annotations(output / 'annotations.proposals.json')
    blank = np.full_like(tiles[0], 245)
    while len(tiles) % 2:
        tiles.append(blank)
    sheet = np.vstack([np.hstack(tiles[i:i+2]) for i in range(0, len(tiles), 2)])
    write_image(review / 'overzicht.jpg', sheet)
    print(f'Geldig formaat: {len(records)} beelden, {sum(len(r["instances"]) for r in records)} instanties.')


if __name__ == '__main__':
    main()
