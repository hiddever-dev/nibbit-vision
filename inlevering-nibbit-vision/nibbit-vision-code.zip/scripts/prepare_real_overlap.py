"""Prepare controlled before/after overlap labels; session-specific upper-object guides.
Reference photos are annotation aids only and are never required for inference.
"""
from pathlib import Path
import sys,hashlib,shutil
import cv2
import numpy as np
from scipy.optimize import differential_evolution
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import read_image,read_json,write_image,write_json
from nibbit.data import load_annotations
from scripts.prepare_isolated_sticks import foreground_masks
from scripts.locate_calibration_markers import locate

# Manually specified rough upper spines on a 1536x864 preview, not model output.
GUIDES=[[(778,343),(799,352),(824,382),(858,411),(905,448)],
 [(805,360),(841,349),(881,335),(931,318)],
 [(619,563),(635,541),(660,531),(687,536),(710,557),(731,603)],
 [(622,594),(640,552),(660,509),(688,463)],
 [(800,487),(838,497),(876,518),(922,555)]]

def polygons(m):
 cs,_=cv2.findContours(np.uint8(m),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 return [c[:,0].tolist() for c in cs if cv2.contourArea(c)>=3]

def largest(m):
 n,l,s,_=cv2.connectedComponentsWithStats(np.uint8(m));return np.uint8(l==(1+np.argmax(s[1:,4])))

def prepare():
 root=Path(__file__).resolve().parents[1];src=root/'data/raw/overlap-pairs-v1'
 out=root/'data/real-overlap-v1';review=root/'review/real-overlap-v1'
 out.mkdir(exist_ok=True);review.mkdir(parents=True,exist_ok=True)
 fs=sorted(src.glob('*.png'));assert len(fs)==10
 cal=read_json(root/'calibration/lumina-raw-v3.json');records=[];manifest=[];tiles=[]
 for k in range(5):
  a,b=map(read_image,fs[2*k:2*k+2]);h,w=b.shape[:2]
  old=foreground_masks(a);now=foreground_masks(b);fg=np.max(now,axis=0)
  corridor=np.zeros((h,w),np.uint8);guide=np.rint(np.array(GUIDES[k])*2.5).astype(np.int32)
  cv2.polylines(corridor,[guide],False,1,75 if k!=3 else 46)
  hsv=cv2.cvtColor(b,cv2.COLOR_BGR2HSV)
  color=((hsv[:,:,0]<10)|(hsv[:,:,0]>160)) if k in (0,2,4) else ((hsv[:,:,0]>=10)&(hsv[:,:,0]<=40))
  upper=largest((fg>0)&(corridor>0)&(color if k!=3 else True))
  upper=cv2.morphologyEx(upper,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
  # Translation search uses visible pixels only; penalizes extra/missing silhouette.
  inst=[];align=[]
  for j,m in enumerate(old):
   x,y,bw,bh=cv2.boundingRect(m);pad=22;x0=max(0,x-pad);y0=max(0,y-pad);x1=min(w,x+bw+pad);y1=min(h,y+bh+pad)
   local=m[y0:y1,x0:x1];target=fg[y0:y1,x0:x1].astype(bool);u=upper[y0:y1,x0:x1].astype(bool)
   best=(-1,None,None)
   for dy in range(-15,16):
    for dx in range(-15,16):
     moved=cv2.warpAffine(local,np.float32([[1,0,dx],[0,1,dy]]),(local.shape[1],local.shape[0]),flags=cv2.INTER_NEAREST).astype(bool)
     vis=moved&~u
     score=(vis&target).sum()/max(1,(vis| (target&~u)).sum())
     if score>best[0]:best=(score,(dx,dy),moved)
   score,(dx,dy),localmask=best
   if np.any(localmask & u):
    # Fit a small rigid motion of the physical reference, never arbitrary hidden shape.
    dist=cv2.distanceTransform(np.uint8(1-local),cv2.DIST_L2,3)
    restricted=target & ~u & (dist<65)
    center=(x+bw/2-x0,y+bh/2-y0)
    def fit(params,ret=False):
     tx,ty,angle=params
     matrix=cv2.getRotationMatrix2D(center,float(angle),1.0);matrix[:,2]+=[tx,ty]
     warped=cv2.warpAffine(local,matrix,(local.shape[1],local.shape[0]),flags=cv2.INTER_NEAREST).astype(bool)
     vis=warped & ~u
     iou=(vis & restricted).sum()/max(1,(vis|restricted).sum())
     return (iou,warped) if ret else -iou
    optimum=differential_evolution(fit,[(-40,40),(-40,40),(-12,12)],seed=42,popsize=9,maxiter=45,tol=.001,polish=False)
    score,localmask=fit(optimum.x,True)
    dx,dy=map(float,optimum.x[:2])
    rotation=float(optimum.x[2])
   full=np.zeros((h,w),np.uint8);full[y0:y1,x0:x1]=localmask
   occluded=bool(np.any(full&upper))
   if occluded:
    # Use observed after-frame outline where visible; reference only inside upper mask.
    near=cv2.distanceTransform(np.uint8(1-full),cv2.DIST_L2,3)<18
    observed=(fg>0)&(upper==0)&near
    full=np.uint8(observed | ((full>0)&(upper>0)))
    full=largest(cv2.morphologyEx(full,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8)))
   visible=full & (1-upper) if occluded else full
   inst.append({'id':f'stick-{j+1}','status':'occluded' if occluded else 'visible','z_order':0,
    'amodal':polygons(full),'visible':polygons(visible),'annotation_method':'before-frame silhouette, translated against visible after-frame pixels; proposal'})
   align.append({'id':j+1,'translation_px':[dx,dy],'rotation_degrees':rotation if occluded else 0,'visible_alignment_iou':score})
  inst.append({'id':'upper','status':'visible','z_order':1,'amodal':polygons(upper),'visible':polygons(upper),
   'annotation_method':'after-frame color contour with manual spatial guide; proposal'})
  name=f'pair-{k+1:02d}-after.png';shutil.copy2(fs[2*k+1],out/name);shutil.copy2(fs[2*k],out/f'pair-{k+1:02d}-before.png')
  records.append({'file':name,'size':[w,h],'group_id':f'2026-11-12-pair-{k+1:02d}',
   'source_identity_note':'User confirms different physical sticks for each pair','instances':inst})
  shifts=np.linalg.norm(np.array(locate(b,expected_points=cal['roi_pixels']))-cal['roi_pixels'],axis=1)
  manifest.append({'pair':k+1,'before':fs[2*k].name,'after':fs[2*k+1].name,
   'sha256_after':hashlib.sha256(fs[2*k+1].read_bytes()).hexdigest(),'marker_shift_max_px':float(shifts.max()),'alignment':align})
  overlay=b.copy()
  for it in inst:
   c=(0,180,255) if it['status']=='occluded' else (80,230,80)
   for poly in it['amodal']:cv2.polylines(overlay,[np.array(poly,np.int32)],True,c,4)
  # Review enlarged overlap area; annotations explicitly distinguished from predictions.
  xx,yy,bw,bh=cv2.boundingRect(upper);x0=max(0,xx-120);y0=max(0,yy-120);x1=min(w,xx+bw+120);y1=min(h,yy+bh+120)
  crop=overlay[y0:y1,x0:x1];crop=cv2.resize(crop,(800,600));cv2.putText(crop,f'PAIR {k+1}: LABEL PROPOSALS - NOT PREDICTIONS',(10,30),0,.65,(0,0,0),2)
  write_image(review/f'pair-{k+1:02d}-labels.jpg',crop);tiles.append(crop)
  print('pair',k+1,'instances',len(inst),'occluded',sum(i['status']=='occluded' for i in inst),'min alignment',min(x['visible_alignment_iou'] for x in align),flush=True)
 doc={'schema_version':1,'review_status':'proposals_pending_visual_review','purpose':'Controlled real before-after overlap annotation proposals; do not train until reviewed','images':records}
 write_json(out/'annotations.proposals.json',doc);write_json(out/'manifest.json',manifest)
 load_annotations(out/'annotations.proposals.json')
 tiles.append(np.full_like(tiles[0],240));write_image(review/'overzicht.jpg',np.vstack([np.hstack(tiles[i:i+2]) for i in range(0,6,2)]))
if __name__=='__main__':prepare()

