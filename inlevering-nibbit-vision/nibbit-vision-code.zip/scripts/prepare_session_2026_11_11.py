import json
import sys
from pathlib import Path

import cv2
import numpy as np

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from nibbit.io import read_image, write_image, read_json, write_json
from nibbit.data import rasterize, load_annotations

DATA = BASE/'data/session-2026-11-11'
REVIEW = BASE/'review/session-2026-11-11'
REVIEW.mkdir(parents=True,exist_ok=True)

def foreground(image):
    hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    binary=np.uint8((hsv[:,:,1]>90)&(hsv[:,:,2]>40))
    return cv2.morphologyEx(binary,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))

def components(binary,minimum=500):
    count,labels,stats,centers=cv2.connectedComponentsWithStats(np.uint8(binary))
    return [np.uint8(labels==i) for i in range(1,count) if stats[i,cv2.CC_STAT_AREA]>=minimum]

def polygons(mask):
    contours,_=cv2.findContours(mask.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    return [c[:,0,:].tolist() for c in contours if cv2.contourArea(c)>10]

def instance(mask,id,status='visible',z=0,visible=None):
    full=polygons(mask)
    return {'id':id,'status':status,'z_order':z,'amodal':full,
            'visible':full if visible is None else polygons(visible),
            'review_status':'proposal_needs_boundary_review'}

records=[]
for name in ['01_empty','04_broken','05_red_reference']:
    image=read_image(DATA/f'{name}.jpg')
    masks=components(foreground(image))
    masks.sort(key=lambda m: np.where(m)[1].mean())
    record={'file':f'{name}.jpg','size':[3840,2160],'group_id':'2026-11-11-shared-sticks',
            'instances':[instance(m,f'stick-{i+1}') for i,m in enumerate(masks)]}
    records.append(record)

# Use the reference frame as an amodal template. Determine a small translation
# from red visible pixels, excluding the upper yellow stick. This is a proposal.
ref=read_image(DATA/'05_red_reference.jpg')
cross=read_image(DATA/'06_crossing_pair.jpg')
refmask=components(foreground(ref))[0]
hsv=cv2.cvtColor(cross,cv2.COLOR_BGR2HSV)
whole=components(foreground(cross))[0]
yellow0=np.uint8((hsv[:,:,0]>=14)&(hsv[:,:,0]<=35)&(whole>0))
yellow0=cv2.morphologyEx(yellow0,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
yellow0=max(components(yellow0),key=np.sum)
redobs=np.uint8((hsv[:,:,0]<=11)&(whole>0))
redobs=cv2.morphologyEx(redobs,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
ry,rx=np.where(refmask)
x0,x1=max(0,int(rx.min())-30),min(3840,int(rx.max())+31)
y0,y1=max(0,int(ry.min())-30),min(2160,int(ry.max())+31)
refcrop=refmask[y0:y1,x0:x1]
redcrop=redobs[y0:y1,x0:x1]
yellowcrop=cv2.dilate(yellow0,np.ones((9,9),np.uint8))[y0:y1,x0:x1]
valid=yellowcrop==0
best=(-1,None)
for dy in range(-15,16):
    for dx in range(-15,16):
        shifted=cv2.warpAffine(refcrop,np.float32([[1,0,dx],[0,1,dy]]),(refcrop.shape[1],refcrop.shape[0]),flags=cv2.INTER_NEAREST)
        a=(shifted>0)&valid
        b=(redcrop>0)&valid
        score=np.logical_and(a,b).sum()/max(1,np.logical_or(a,b).sum())
        if score>best[0]:best=(score,(dx,dy))
score,(dx,dy)=best
shifted=cv2.warpAffine(refmask,np.float32([[1,0,dx],[0,1,dy]]),(3840,2160),flags=cv2.INTER_NEAREST)
# Expand yellow label boundaries conservatively to include hue transition pixels
# using local nearest-colour assignment between red and yellow seeds.
redseed=(redobs>0).astype(np.uint8)
yellowseed=cv2.erode(yellow0,np.ones((3,3),np.uint8))
dr=cv2.distanceTransform(1-redseed,cv2.DIST_L2,5)
dyellow=cv2.distanceTransform(1-yellowseed,cv2.DIST_L2,5)
upper=np.uint8((whole>0)&(dyellow<dr))
upper=max(components(upper),key=np.sum)
upper=cv2.morphologyEx(upper,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
lower_polygons=polygons(shifted)
upper_polygons=polygons(upper)
lower_full=rasterize(lower_polygons,(2160,3840))
upper_full=rasterize(upper_polygons,(2160,3840))
lower_visible=np.uint8(lower_full&~upper_full)
record={'file':'06_crossing_pair.jpg','size':[3840,2160],'group_id':'2026-11-11-shared-sticks',
        'instances':[instance(lower_full,'red-bottom','occluded',0,lower_visible),instance(upper_full,'yellow-top','visible',1)],
        'amodal_reference':'05_red_reference.jpg',
        'reference_alignment':{'translation_pixels':[dx,dy],'red_visible_iou':float(score),
                               'note':'Automatische uitlijning; geen bewijs dat de fysieke stick onveranderd is.'}}
records.append(record)
document={'schema_version':1,'review_status':'DRAFT_PROPOSALS_NOT_A_FINISHED_DATASET',
          'method':'HSV contours for annotation assistance only. No trained detection model; no SAM.',
          'calibration':None,'images':records,
          'excluded_pending_manual_instances':['02_sticks.jpg','03_sticks.jpg','07_same_color_crossing.jpg','08_pile.jpg']}
write_json(DATA/'annotations.proposals.json',document)
load_annotations(DATA/'annotations.proposals.json')

tiles=[]
for meta in read_json(DATA/'manifest.json'):
    image=read_image(DATA/meta['file'])
    r=next((r for r in records if r['file']==meta['file']),None)
    display=image.copy()
    if r:
        for i,item in enumerate(r['instances']):
            full=rasterize(item['amodal'],image.shape[:2])
            visible=rasterize(item['visible'],image.shape[:2])
            hidden=full&~visible
            color=np.array((60,240,90) if item['status']=='visible' else (255,100,220))
            display[full]=np.uint8(display[full]*.6+color*.4)
            contours,_=cv2.findContours(np.uint8(full),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(display,contours,-1,tuple(int(c) for c in color),3)
            yy,xx=np.where(hidden)
            if len(xx):
                sel=(xx+yy)%16<6
                display[yy[sel],xx[sel]]=(255,0,255)
            y,x=np.where(full)
            cv2.putText(display,f"{i+1}: {item['status']}",(int(x.min()),max(90,int(y.min())-15)),cv2.FONT_HERSHEY_SIMPLEX,1.1,(20,20,20),3,cv2.LINE_AA)
    # Side-by-side details for the paired example, preserving complete originals elsewhere.
    if meta['file'] in ['05_red_reference.jpg','06_crossing_pair.jpg']:
        detail=display[950:1480,880:1570]
        footer=np.full((40,detail.shape[1],3),245,dtype=np.uint8)
        cv2.putText(footer,'ANNOTATIEVOORSTEL - GEEN MODELRESULTAAT',(10,26),cv2.FONT_HERSHEY_SIMPLEX,.6,(30,30,30),1,cv2.LINE_AA)
        write_image(REVIEW/(Path(meta['file']).stem+'_detail.png'),np.vstack([detail,footer]))
    tile=cv2.resize(display,(768,432))
    label=meta['file']+' | '+(f"{len(r['instances'])} MASK PROPOSALS" if r else 'MANUAL INSTANCE REVIEW NEEDED')
    header=np.full((42,768,3),20,dtype=np.uint8)
    cv2.putText(header,label,(8,27),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),1,cv2.LINE_AA)
    tiles.append(np.vstack([header,tile]))
sheet=np.vstack([np.hstack(tiles[i:i+2]) for i in range(0,8,2)])
write_image(REVIEW/'overzicht.jpg',sheet)
print(json.dumps({'alignment':record['reference_alignment'],'draft_images':len(records),
                  'draft_instances':sum(len(r['instances']) for r in records),'sheet':str(REVIEW/'overzicht.jpg')}))
