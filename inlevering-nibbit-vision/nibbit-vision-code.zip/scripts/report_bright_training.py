"""Document a completed run without changing model or thresholds."""
from pathlib import Path
import json,hashlib
import torch

def main():
 root=Path(__file__).resolve().parents[1]
 run=root/'runs/bright-overlap-01';review=root/'runs/challenge-review-bright-v1'
 cp=torch.load(run/'best.pt',map_location='cpu',weights_only=True)
 manifest={k:v for k,v in cp.items() if k!='model'}
 manifest['weights_sha256']=hashlib.sha256((run/'best.pt').read_bytes()).hexdigest()
 manifest['completed_epochs']=len(json.loads((run/'history.json').read_text()))
 (run/'model_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 scores=json.loads((review/'isolated_metrics.json').read_text())
 new=json.loads((review/'results.json').read_text())['images']
 old=json.loads((root/'runs/challenge-review-v1/results.json').read_text())['images']
 lines=['# Resultaat nieuwe training, 12 november 2026','',
 'De training is afgerond, maar de oplossing voldoet nog niet betrouwbaar aan de volledige opdracht.', '',
 '148 trainingsbeelden, 1563 instanties, 8 rondes. Mask R-CNN, geen SAM en geen oriented bounding boxes. Alle nieuwe fysieke bronnen zijn samen in de training gehouden. De 23 challenge-stukken zijn niet gebruikt voor training of modelselectie.', '',
 f"Gekozen ronde: {cp['epoch']}. Eén aparte validatiefoto: 10 juiste detecties, 0 extra, 0 gemist; status van alle gematchte stukken correct. Dit is een kleine validatieset, geen volledige benchmark.", '',
 f"Losse challenge-stukken: {scores['truth_count']} referentiemaskers, {scores['predicted_count']} voorspellingen; {scores['tp_at_mask_iou_0_5']} juist, {scores['fp_at_mask_iou_0_5']} extra, {scores['fn_at_mask_iou_0_5']} gemist bij masker-IoU >= 0,5. De silhouetlabels zijn benaderingen.", '',
 '| Foto | Oud aantal | Nieuw aantal | Verwacht |','|---|---:|---:|---:|']
 for a,b in zip(old,new):
  assert a['file']==b['file']
  lines.append(f"| {b['file']} | {a['model_count_before_5mm_filter']} | {b['model_count_before_5mm_filter']} | 23 |")
 lines += ['', 'Aantallen zijn geen segmentatienauwkeurigheid: dubbele maskers en gemiste stukken kunnen elkaar compenseren. Bij de kruisingen zijn dubbele voorspellingen en foutieve contouren zichtbaar. Niet alle eerdere stressopstellingen zijn gecertificeerd als maximaal één occluder per stick. Voor de hopen bestaan nog geen volledig gecontroleerde amodale referentiemaskers; daarvoor wordt geen F1-score geclaimd.', '',
 'De gekozen gewichten en drempel zijn vóór deze challengecontrole vastgezet. Deze reeds bekeken challenge-set is nu een diagnostische set en mag niet als nieuwe, onaangeroerde eindtest worden gepresenteerd.', '',
 'Live testen: sluit het opnamevenster met Q en start START_GETRAIND_MODEL.cmd. Enter kiest camera 0. Laat de opstelling en lichtsterkte gelijk. De livecamera is tijdens deze training niet getest. Lengtes zijn voorlopig: markerafstanden 400 x 225 mm met opgegeven 5 mm tolerantie; de nieuwe kalibratie heeft nog geen onafhankelijke lengtecontrole en geen lens- of hoogtecorrectie.', '',
 'Volgende ontwikkelstap: fouten analyseren op aparte ontwikkelbeelden, dubbele voorspellingen aanpakken en correcte amodale maskers bij drukke opstellingen verbeteren. Daarna een nieuwe fysieke testset gebruiken voor eindbeoordeling. Ook livevideo en reproductiecontrole blijven nodig.']
 text='\n'.join(lines)+'\n'
 (review/'RESULTAAT.md').write_text(text,encoding='utf-8')
 (run/'RESULTAAT.txt').write_text(text,encoding='utf-8')
 print('Selected epoch',cp['epoch'],'isolated',scores['tp_at_mask_iou_0_5'],scores['fp_at_mask_iou_0_5'],scores['fn_at_mask_iou_0_5'])
 print('New counts',[r['model_count_before_5mm_filter'] for r in new])
if __name__=='__main__':main()
