"""Frozen, read-only challenge inference. Never trains on challenge images."""
import argparse,hashlib,time,sys
from pathlib import Path
from collections import Counter
import cv2,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import *
from nibbit.model import load_model,device_for,predict
from nibbit.inference import render
from scripts.locate_calibration_markers import locate

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--weights',default='runs/pilot-real-overlap-01/best.pt');ap.add_argument('--output',default='runs/challenge-review-v1');args=ap.parse_args()
 out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 sources=sorted(Path('data/raw/challenge-20-v1').glob('*.png'));cal=read_json('calibration/lumina-raw-v3.json')
 dev=device_for('cuda');model,checkpoint=load_model(args.weights,dev)
 group='challenge-2026-11-12-shared-physical-set'
 if group in checkpoint['development_groups']:raise ValueError('Challenge group already used for model development.')
 manifest={'group_id':group,'usage':'frozen_model_diagnostic_holdout_do_not_train','physical_identity':'User confirmed same 23 physical pieces in every image','truth_piece_count':23,'weights':args.weights,'weights_sha256':hashlib.sha256(Path(args.weights).read_bytes()).hexdigest(),'threshold':.5,'images':[]}
 results=[];tiles=[]
 for n,source in enumerate(sources):
  role='isolated_reference' if n==0 else 'initial_pair_layout' if n==1 else 'earlier_complex_layout' if n<6 else 'revised_layout_pending_rule_review'
  im=read_image(source);h,w=im.shape[:2];shift=None;calibration=None
  try:
   markers=np.array(locate(im,expected_points=cal['roi_pixels']));shift=float(np.linalg.norm(markers-cal['roi_pixels'],axis=1).max())
   if shift<=12:calibration=cal
  except ValueError:pass
  started=time.perf_counter();pred=predict(model,im,dev,.5);predict_seconds=time.perf_counter()-started
  annotated,rows,masks=render(im,pred,calibration,min_mm=5)
  stem=source.stem;write_image(out/f'{stem}_detections.jpg',annotated)
  np.savez_compressed(out/f'{stem}_masks.npz',masks=masks)
  record={'file':source.name,'role':role,'group_id':group,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'size':[w,h],'expected_piece_count':23};manifest['images'].append(record)
  result={'file':source.name,'role':role,'model_count_before_5mm_filter':len(pred),'reported_count':len(rows),'expected_piece_count':23,'signed_count_error':len(rows)-23,'predicted_status_counts':dict(Counter(r['status'] for r in rows)),'measurement_status_counts':dict(Counter(r['measurement_status'] for r in rows)),'marker_displacement_max_px':shift,'calibration_applied':calibration is not None,'inference_seconds':predict_seconds,'instances':rows}
  write_json(out/f'{stem}_detections.json',result);results.append(result)
  # Extra large IDs for inspection, separate from model's tiny native labels.
  overlay=im.copy()
  for j,p in enumerate(pred,1):
   m=p['mask'];color=(0,160,255) if p['status']=='occluded' else (50,230,60)
   overlay[m]=np.uint8(overlay[m]*.65+np.array(color)*.35)
   cs,_=cv2.findContours(np.uint8(m),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);cv2.drawContours(overlay,cs,-1,color,3)
   yy,xx=np.where(m);cv2.putText(overlay,f'{j}'+(' O' if p['status']=='occluded' else ' V'),(int(xx.min()),int(yy.min())-6),0,.75,(0,0,0),2,cv2.LINE_AA)
  crop=overlay[280:1950,850:3100];crop=cv2.resize(crop,(1000,742));header=np.full((48,1000,3),240,np.uint8)
  cv2.putText(header,f'{stem[9:15]} | model: {len(pred)} | O=occluded V=visible',(12,32),0,.75,(0,0,0),2)
  tile=np.vstack([header,crop]);write_image(out/f'{stem}_review.jpg',tile);tiles.append(tile)
  print(source.name,role,len(pred),dict(Counter(p['status'] for p in pred)),flush=True)
 write_json(out/'manifest.json',manifest);write_json(out/'results.json',{'note':'Counts alone are not segmentation accuracy. No amodal ground truth for piles. Lengths approximate; no independent length references. No training or threshold tuning performed.','images':results})
 write_image(out/'overzicht.jpg',np.vstack([np.hstack(tiles[i:i+2]) for i in range(0,len(tiles),2)]))
if __name__=='__main__':main()
