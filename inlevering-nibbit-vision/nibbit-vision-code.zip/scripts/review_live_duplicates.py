"""Recheck two reported development failures without modifying originals."""
from pathlib import Path
import sys,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import read_image,read_json,write_image,write_json
from nibbit.model import load_model,device_for,predict,POSTPROCESSING_VERSION
from nibbit.inference import render
from nibbit.data import load_annotations
from nibbit.training import evaluate_records

def main():
 out=Path('runs/duplicate-filter-v3');out.mkdir(parents=True,exist_ok=True)
 weights=Path('runs/bright-overlap-01/best.pt');dev=device_for('cuda');model,_=load_model(weights,dev)
 report={'postprocessing':POSTPROCESSING_VERSION,'weights_sha256':hashlib.sha256(weights.read_bytes()).hexdigest(),
         'scope':'Two reported development failures; counts visually checked. No independent benchmark; masks and length not certified.','images':[]}
 for stem,expected in [('snapshot_20261113T101457_350552Z',8),('snapshot_20261113T101515_089319Z',10)]:
  raw=Path('runs/bright-live')/(stem+'_raw.png');im=read_image(raw)
  old=read_json(raw.with_name(stem+'.json'));pred=predict(model,im,dev)
  annotated,rows,_=render(im,pred,old['calibration']);write_image(out/(stem+'_corrected.png'),annotated)
  write_json(out/(stem+'.json'),{'instances':rows,'postprocessing':POSTPROCESSING_VERSION})
  row={'source':str(raw),'source_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),
       'expected_count':expected,'previous_count':len(old['instances']),'new_count':len(rows)}
  report['images'].append(row);print(row,flush=True)
 doc,root=load_annotations('data/real-overlap-v1/annotations.json')
 report['existing_57_instance_development_regression']=evaluate_records(model,doc['images'],root,dev)
 write_json(out/'verification.json',report);print(report['existing_57_instance_development_regression'],flush=True)
if __name__=='__main__':main()
