"""Reproduce reported live failures; these are development cases, not a test set."""
from pathlib import Path
import hashlib
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cv2
from nibbit.io import read_image, read_json, write_image, write_json
from nibbit.model import load_model, device_for, predict, POSTPROCESSING_VERSION
from nibbit.inference import render


def main():
    out = Path('runs/live-filter-v5')
    out.mkdir(parents=True, exist_ok=True)
    weights = Path('runs/bright-overlap-01/best.pt')
    device = device_for('cuda')
    model, _ = load_model(weights, device)
    report = {'postprocessing': POSTPROCESSING_VERSION, 'threshold': .3,
              'weights_sha256': hashlib.sha256(weights.read_bytes()).hexdigest(),
              'scope': 'Reported development failures. Expected counts are manual scene counts; no complete amodal ground truth or independent accuracy claim.',
              'images': []}
    cases = [('101457_350552', 8), ('101515_089319', 10),
             ('103851_381962', 20), ('104221_557595', 20), ('110337_695959', 20)]
    for timestamp, expected in cases:
        stem = 'snapshot_20261113T' + timestamp + 'Z'
        source = Path('runs/bright-live') / (stem + '_raw.png')
        image = read_image(source)
        previous = read_json(source.with_name(stem + '.json'))
        predictions = predict(model, image, device, .3)
        annotated, rows, _ = render(image, predictions, previous['calibration'])
        write_image(out / (stem + '_corrected.png'), annotated)
        write_image(out / (stem + '_preview.jpg'), cv2.resize(annotated, (1920, 1080)))
        write_json(out / (stem + '.json'), {'instances': rows,
                   'postprocessing': POSTPROCESSING_VERSION, 'threshold': .3})
        result = {'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                  'expected_count': expected, 'previous_count': len(previous['instances']),
                  'new_count': len(rows)}
        report['images'].append(result)
        print(result, flush=True)
    write_json(out / 'verification.json', report)


if __name__ == '__main__':
    main()

