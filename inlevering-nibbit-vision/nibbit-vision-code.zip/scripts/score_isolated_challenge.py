"""Score only the isolated reference using saved, frozen predictions."""
from pathlib import Path
import sys,argparse
import numpy as np
from scipy.optimize import linear_sum_assignment
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nibbit.io import write_json
from nibbit.data import load_annotations,rasterize

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',default='runs/challenge-review-v1');args=ap.parse_args()
 out=Path(args.output);doc,_=load_annotations('data/challenge-evaluation-v1/annotations.json');r=doc['images'][0]
 truth=[rasterize(i['amodal'],(r['size'][1],r['size'][0])) for i in r['instances']]
 pred=np.load(out/'20261112T125941_486274Z_masks.npz')['masks'];ious=np.zeros((len(truth),len(pred)))
 for i,t in enumerate(truth):
  for j,p in enumerate(pred):ious[i,j]=(t&p).sum()/max(1,(t|p).sum())
 rows,cols=linear_sum_assignment(-((ious>=.5)*1000+ious));matches=[(int(i),int(j),float(ious[i,j])) for i,j in zip(rows,cols) if ious[i,j]>=.5]
 tp=len(matches);mt={i for i,j,s in matches};mp={j for i,j,s in matches}
 write_json(out/'isolated_metrics.json',{'scope':'isolated reference only; approximate visually reviewed silhouette labels','truth_count':len(truth),'predicted_count':len(pred),'tp_at_mask_iou_0_5':tp,'fp_at_mask_iou_0_5':len(pred)-tp,'fn_at_mask_iou_0_5':len(truth)-tp,'f1_at_mask_iou_0_5':2*tp/max(1,len(truth)+len(pred)),'mean_matched_iou':float(np.mean([s for i,j,s in matches])) if matches else None,'unmatched_truth_ids':[r['instances'][i]['id'] for i in range(len(truth)) if i not in mt],'unmatched_prediction_ids':[j+1 for j in range(len(pred)) if j not in mp],'matches':[{'truth_id':r['instances'][i]['id'],'prediction_id':j+1,'iou':s} for i,j,s in matches]})
if __name__=='__main__':main()
