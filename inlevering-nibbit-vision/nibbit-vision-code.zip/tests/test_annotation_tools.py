import unittest

import cv2
import numpy as np

from scripts.prepare_isolated_sticks import foreground_masks


class AnnotationToolTests(unittest.TestCase):
    def test_red_hue_wrap_does_not_split_one_isolated_stick(self):
        hsv = np.zeros((200, 400, 3), np.uint8)
        hsv[:, :, 2] = 170
        hsv[80:110, 70:330] = [4, 170, 170]
        hsv[80:110, 170:230] = [178, 170, 170]
        image = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        masks = foreground_masks(image)
        self.assertEqual(len(masks), 1)
        self.assertTrue(masks[0][90, 200])

class BrightReferenceTests(unittest.TestCase):
    def test_same_color_crossing_retains_upper_and_hidden_lower(self):
        from scripts.prepare_bright_pairs import upper_mask
        lower = np.zeros((150, 150), np.uint8)
        upper = np.zeros_like(lower)
        lower[67:82, 15:135] = 1
        upper[15:135, 67:82] = 1
        estimated, _ = upper_mask(lower, lower | upper)
        iou = np.logical_and(estimated, upper).sum() / np.logical_or(estimated, upper).sum()
        self.assertGreater(iou, 0.75)
        self.assertTrue(estimated[75, 75])
        self.assertFalse(estimated[75, 25])
        self.assertTrue(np.any(lower & (1 - estimated)))
