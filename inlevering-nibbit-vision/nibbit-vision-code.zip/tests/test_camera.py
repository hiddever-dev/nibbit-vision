import unittest
from unittest.mock import patch

import cv2
import numpy as np

from nibbit.camera import open_camera


class FakeCapture:
    def __init__(self, opened=True, readable=True):
        self.opened, self.readable, self.released = opened, readable, False
        self.properties = []

    def isOpened(self):
        return self.opened

    def set(self, key, value):
        self.properties.append((key, value))
        return True

    def read(self):
        return (True, np.zeros((20, 30, 3), np.uint8)) if self.readable else (False, None)

    def release(self):
        self.released = True


class CameraTests(unittest.TestCase):
    def test_fallback_to_media_foundation_releases_failed_device(self):
        failed, working = FakeCapture(False), FakeCapture()
        with patch('nibbit.camera.cv2.VideoCapture', side_effect=[failed, working]) as factory:
            cap = open_camera(0, 30, 20)
        self.assertIs(cap, working)
        self.assertTrue(failed.released)
        self.assertFalse(working.released)
        self.assertEqual(factory.call_args_list[1].args, (0, cv2.CAP_MSMF))

    def test_open_but_no_frames_retries_native_format(self):
        bad_format, native = FakeCapture(readable=False), FakeCapture()
        with patch('nibbit.camera.cv2.VideoCapture', side_effect=[bad_format, native]):
            cap = open_camera(2, 30, 20, backend='dshow')
        self.assertIs(cap, native)
        self.assertTrue(bad_format.released)
        self.assertNotIn(cv2.CAP_PROP_FOURCC, [key for key, _ in native.properties])

    def test_failure_does_not_silently_switch_to_another_camera(self):
        devices = [FakeCapture(False) for _ in range(3)]
        with patch('nibbit.camera.cv2.VideoCapture', side_effect=devices) as factory:
            with self.assertRaisesRegex(ValueError, 'Camera 1'):
                open_camera(1, 3840, 2160)
        self.assertTrue(all(c.released for c in devices))
        self.assertEqual([call.args[0] for call in factory.call_args_list], [1, 1, 1])

    def test_invalid_index_is_rejected_before_opening_device(self):
        with patch('nibbit.camera.cv2.VideoCapture') as factory:
            with self.assertRaises(ValueError):
                open_camera(-1, 3840, 2160)
            factory.assert_not_called()


if __name__ == '__main__':
    unittest.main()
