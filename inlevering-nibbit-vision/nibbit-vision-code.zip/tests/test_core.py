import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from nibbit.data import group_split, load_annotations, rasterize
from nibbit.demo import demo
from nibbit.geometry import make_calibration, measure, polyline_length, transform_points, verify_calibration
from nibbit.io import read_json, write_json
from nibbit.inference import render, remove_assigned_fragments


class CoreTests(unittest.TestCase):
    def test_stray_island_assigned_to_neighbor_does_not_block_length(self):
        main = np.zeros((100, 240), dtype=bool)
        main[50:60, 20:200] = True
        neighbor = np.zeros_like(main)
        neighbor[20:30, 100:180] = True
        stray = np.zeros_like(main)
        stray[20:30, 110:130] = True
        predictions = [{'mask': main | stray, 'status': 'visible', 'score': .9},
                       {'mask': neighbor, 'status': 'visible', 'score': .9}]
        cleaned = remove_assigned_fragments(predictions)
        np.testing.assert_array_equal(cleaned[0]['mask'], main)
        self.assertIsNotNone(measure(cleaned[0]['mask'])['length_px'])
        # Without a neighbor explaining the island, refuse the measurement.
        self.assertIsNone(measure(remove_assigned_fragments(predictions[:1])[0]['mask'])['length_px'])
        predictions[0]['status'] = 'occluded'
        np.testing.assert_array_equal(remove_assigned_fragments(predictions)[0]['mask'], main | stray)

    def test_uncalibrated_never_reports_mm_and_calibration_has_known_scale(self):
        mask = np.zeros((120, 240), dtype=np.uint8)
        cv2.rectangle(mask, (30, 50), (210, 70), 1, -1)
        raw = measure(mask)
        self.assertIsNone(raw["length_mm"])
        self.assertAlmostEqual(raw["length_px"], 180, delta=3)
        calibration = make_calibration([[0, 0], [239, 0], [239, 119], [0, 119]], 119.5, 59.5, mask.shape, "test")
        self.assertAlmostEqual(measure(mask, calibration)["length_mm"], 90, delta=2)
        with self.assertRaises(ValueError):
            verify_calibration(calibration, (240, 480), "test")
        with self.assertRaises(ValueError):
            verify_calibration(calibration, mask.shape, "another")

    def test_disconnected_full_mask_not_silently_measured(self):
        mask = np.zeros((80, 180), dtype=np.uint8)
        mask[30:40, 10:70] = 1
        mask[30:40, 100:150] = 1
        result = measure(mask)
        self.assertEqual(result["measurement_status"], "disconnected_mask")
        self.assertIsNone(result["length_px"])

    def test_curved_spine_follows_arc_instead_of_endpoint_chord(self):
        mask = np.zeros((220, 220), dtype=np.uint8)
        cv2.ellipse(mask, (110, 110), (70, 70), 0, 0, 180, 1, 11)
        result = measure(mask)
        self.assertAlmostEqual(result["length_px"], np.pi * 70 + 11, delta=12)
        self.assertGreater(result["length_px"], 200)

    def test_straight_strip_with_slanted_caps_does_not_measure_corner_branches(self):
        mask = np.zeros((120, 240), dtype=np.uint8)
        # Both cut edges are slanted; cap midpoints are still 180 pixels apart.
        polygon = np.array([[26, 50], [206, 50], [214, 70], [34, 70]], np.int32)
        cv2.fillPoly(mask, [polygon], 1)
        result = measure(mask)
        self.assertAlmostEqual(result["length_px"], 180, delta=3)

    def test_spine_crop_preserves_global_coordinates_and_length(self):
        from nibbit.geometry import spine
        small = np.zeros((100, 240), np.uint8)
        cv2.rectangle(small, (30, 40), (210, 60), 1, -1)
        large = np.zeros((1800, 3000), np.uint8)
        large[700:800, 1100:1340] = small
        a, _ = spine(small)
        b, _ = spine(large)
        np.testing.assert_allclose(b-a, np.tile([1100, 700], (len(a), 1)), atol=1e-6)
        self.assertAlmostEqual(measure(small)['length_px'], measure(large)['length_px'])

    def test_homography_handles_perspective(self):
        pixels = [[35, 15], [190, 35], [170, 180], [15, 140]]
        cal = make_calibration(pixels, 100, 80, (200, 220), "test")
        mapped = transform_points(pixels, cal["image_to_mm"])
        np.testing.assert_allclose(mapped, [[0, 0], [100, 0], [100, 80], [0, 80]], atol=1e-5)
        self.assertAlmostEqual(polyline_length(mapped[:2]), 100)

    def test_annotation_masks_can_overlap_and_visible_fragments_share_one_instance(self):
        with tempfile.TemporaryDirectory() as directory:
            demo(directory)
            doc, _ = load_annotations(Path(directory) / "annotations.json")
            instances = doc["images"][0]["instances"]
            self.assertEqual(len(instances), 2)
            a, b = [rasterize(i["amodal"], (480, 640)) for i in instances]
            self.assertTrue(np.any(a & b))
            visible = rasterize(instances[0]["visible"], (480, 640))
            self.assertEqual(cv2.connectedComponents(visible.astype(np.uint8))[0] - 1, 2)
            # A visible mask outside its full mask must fail validation.
            doc["images"][0]["instances"][0]["visible"] = [[[0, 0], [10, 0], [10, 10]]]
            write_json(Path(directory) / "bad.json", doc)
            with self.assertRaises(ValueError):
                load_annotations(Path(directory) / "bad.json")

    def test_group_split_prevents_source_leakage(self):
        records = [{"file": str(i), "group_id": f"source-{i // 4}"} for i in range(24)]
        train, val = group_split(records)
        self.assertTrue(train and val)
        self.assertFalse({i["group_id"] for i in train} & {i["group_id"] for i in val})
        self.assertEqual((train, val), group_split(records))

    def test_explicit_synthetic_split_rejects_reused_physical_stick(self):
        records = [{'group_id': 'train-group', 'split': 'train', 'source_ids': ['stick-A']},
                   {'group_id': 'val-group', 'split': 'val', 'source_ids': ['stick-B']}]
        train, val = group_split(records)
        self.assertEqual(train, records[:1])
        self.assertEqual(val, records[1:])
        records[1]['source_ids'] = ['stick-A']
        with self.assertRaisesRegex(ValueError, 'fysieke bronstick'):
            group_split(records)

    def test_minimum_mm_filter_requires_calibration_and_roi_is_enforced(self):
        image = np.zeros((120, 240, 3), dtype=np.uint8)
        mask = np.zeros((120, 240), dtype=bool)
        mask[50:55, 60:73] = True
        predictions = [{"mask": mask, "status": "visible", "score": 0.9}]
        _, uncalibrated, _ = render(image, predictions)
        self.assertEqual(len(uncalibrated), 1)
        self.assertIsNone(uncalibrated[0]["length_mm"])
        cal = make_calibration([[0, 0], [239, 0], [239, 119], [0, 119]], 23.9, 11.9, mask.shape, "test")
        _, calibrated, _ = render(image, predictions, cal)
        self.assertEqual(calibrated, [])  # ~1.3 mm at this known scale.
        narrow_roi = make_calibration([[80, 0], [239, 0], [239, 119], [80, 119]], 15.9, 11.9, mask.shape, "test")
        self.assertIsNone(measure(mask, narrow_roi)["length_mm"])
        self.assertEqual(measure(mask, narrow_roi)["measurement_status"], "outside_calibrated_roi")


if __name__ == "__main__":
    unittest.main()
