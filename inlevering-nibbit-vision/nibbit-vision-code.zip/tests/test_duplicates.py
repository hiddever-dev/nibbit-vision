import unittest
import numpy as np
from nibbit.model import suppress_duplicate_masks

class DuplicateTests(unittest.TestCase):
    def item(self, mask, score=.9, status='visible'):
        return dict(mask=mask.astype(bool), score=score, status=status)

    def test_fragment_removed_but_crossing_and_short_isolated_preserved(self):
        vertical=np.zeros((120,120),bool);vertical[10:110,50:62]=True
        horizontal=np.zeros_like(vertical);horizontal[52:64,10:110]=True
        fragment=np.zeros_like(vertical);fragment[20:28,52:60]=True
        short=np.zeros_like(vertical);short[5:12,5:20]=True
        output=suppress_duplicate_masks([self.item(vertical),self.item(horizontal,.85,'occluded'),
                                        self.item(fragment,.6,'occluded'),self.item(short,.7)])
        self.assertEqual(len(output),3)
        self.assertTrue(any(np.array_equal(p['mask'],short) for p in output))

    def test_near_duplicate_different_status_keeps_higher_score(self):
        a=np.zeros((120,120),bool);a[10:100,30:40]=True
        b=a.copy();b[10:15,30:40]=False
        output=suppress_duplicate_masks([self.item(b,.6,'occluded'),self.item(a,.9)])
        self.assertEqual(len(output),1)
        self.assertEqual(output[0]['status'],'visible')

    def test_higher_confidence_small_mask_is_not_silently_deleted(self):
        a=np.zeros((120,120),bool);a[10:100,30:40]=True
        b=np.zeros_like(a);b[20:30,32:38]=True
        self.assertEqual(len(suppress_duplicate_masks([self.item(a,.6),self.item(b,.9)])),2)

    def test_fragmented_ghost_explained_by_crossing_is_removed(self):
        a=np.zeros((160,160),bool);a[60:74,10:150]=True
        b=np.zeros_like(a);b[10:150,75:89]=True
        ghost=np.zeros_like(a);ghost[60:74,40:140]=True;ghost[20:28,75:89]=True
        output=suppress_duplicate_masks([self.item(a,.99,'occluded'),self.item(b,.98),self.item(ghost,.6,'occluded')])
        self.assertEqual(len(output),2)

    def test_unexplained_disconnected_stick_is_preserved(self):
        a=np.zeros((160,160),bool);a[60:74,10:150]=True
        b=np.zeros_like(a);b[10:58,75:89]=True;b[76:150,75:89]=True
        self.assertEqual(len(suppress_duplicate_masks([self.item(a,.99),self.item(b,.6,'occluded')])),2)

    def test_connected_partial_duplicate_across_status_is_removed(self):
        a=np.zeros((120,120),bool);a[10:110,40:52]=True
        b=np.zeros_like(a);b[25:95,40:52]=True
        self.assertEqual(len(suppress_duplicate_masks([self.item(a,.99),self.item(b,.7,'occluded')])),1)

    def test_low_confidence_crossing_still_adds_a_real_object(self):
        a=np.zeros((120,120),bool);a[10:110,40:52]=True
        b=np.zeros_like(a);b[50:62,10:110]=True
        self.assertEqual(len(suppress_duplicate_masks([self.item(a,.99),self.item(b,.35,'occluded')])),2)

    def test_partial_occluded_duplicate_keeps_stronger_mask_unchanged(self):
        a=np.zeros((120,120),bool);a[10:85,40:52]=True
        b=np.zeros_like(a);b[20:100,40:52]=True
        result=suppress_duplicate_masks([self.item(a,.7,'occluded'),self.item(b,.4,'occluded')])
        self.assertEqual(len(result),1)
        self.assertTrue(np.array_equal(result[0]['mask'],a))

    def test_partial_visible_duplicate_keeps_stronger_mask_unchanged(self):
        a=np.zeros((120,120),bool);a[10:85,40:52]=True
        b=np.zeros_like(a);b[20:100,40:52]=True
        result=suppress_duplicate_masks([self.item(a,.7),self.item(b,.4)])
        self.assertEqual(len(result),1)
        self.assertTrue(np.array_equal(result[0]['mask'],a))

    def test_same_status_crossing_sticks_remain_separate(self):
        a=np.zeros((120,120),bool);a[10:110,40:52]=True
        b=np.zeros_like(a);b[50:62,10:110]=True
        self.assertEqual(len(suppress_duplicate_masks([self.item(a,.9),self.item(b,.7)])),2)
