import unittest
import numpy as np
from nibbit.geometry import measure, estimate_missing_length
from nibbit.inference import render
from nibbit.temporal import SceneConsensus

class LengthFallbackTests(unittest.TestCase):
    def setUp(self):
        self.mask = np.zeros((120,240), bool)
        self.mask[50:61,30:211] = True
        self.cal = {'image_to_mm': np.eye(3).tolist(), 'roi_pixels': [[0,0],[239,0],[239,119],[0,119]]}
    def test_outside_roi_keeps_reason_but_estimates_same_spine(self):
        cal = {**self.cal, 'roi_pixels': [[40,0],[239,0],[239,119],[40,119]]}
        original = measure(self.mask, cal)
        self.assertIsNone(original['length_mm'])
        result = estimate_missing_length(self.mask, cal, original)
        self.assertAlmostEqual(result['length_mm'], measure(self.mask,self.cal)['length_mm'])
        self.assertEqual(result['measurement_status'], 'outside_calibrated_roi')
        self.assertTrue(result['length_is_estimate'])
    def test_disconnected_includes_gap(self):
        self.mask[:,100:130] = False
        result = estimate_missing_length(self.mask,self.cal,measure(self.mask,self.cal))
        self.assertTrue(175 < result['length_mm'] < 185)
        self.assertEqual(result['length_estimation_method'], 'reconstructed_centreline')
    def test_valid_result_unchanged_and_no_scale_invents_no_mm(self):
        result = measure(self.mask,self.cal)
        self.assertIs(estimate_missing_length(self.mask,self.cal,result),result)
        self.assertIsNone(estimate_missing_length(self.mask,None,measure(self.mask))['length_mm'])
    def test_render_and_border_fallback(self):
        self.mask[50:61,:40] = True
        _, rows, _ = render(np.zeros((120,240,3),np.uint8),[dict(mask=self.mask,status='visible',score=.9)],self.cal,dashboard=False)
        self.assertGreater(rows[0]['length_mm'],200)
        self.assertTrue(rows[0]['length_is_estimate'])
        self.assertEqual(rows[0]['measurement_status'],'truncated_at_image_border')
    def test_guesses_do_not_pollute_history_and_reset_clears_it(self):
        c = SceneConsensus()
        c.smooth_lengths([dict(id=1,length_mm=50.)])
        rows = [dict(id=1,length_mm=90.,length_is_estimate=True)]
        c.smooth_lengths(rows)
        self.assertEqual(rows[0]['length_mm'],50.)
        self.assertEqual(len(c.lengths[1]),1)
        self.assertEqual(rows[0]['length_estimation_method'],'historical_consensus')
        c.reset()
        rows = [dict(id=1,length_mm=90.,length_is_estimate=True)]
        c.smooth_lengths(rows)
        self.assertEqual(rows[0]['length_mm'],90.)
