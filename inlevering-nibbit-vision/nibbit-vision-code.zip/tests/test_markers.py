import unittest

import cv2
import numpy as np

from scripts.locate_calibration_markers import locate


class MarkerTests(unittest.TestCase):
    def image(self):
        image = np.zeros((600, 1000, 3), np.uint8)
        image[50:570, 100:910] = 170
        expected = np.float64([[130, 90], [870, 90], [870, 490], [130, 490]])
        for x, y in expected:
            cv2.circle(image, (int(x), int(y)), 8, (20, 20, 20), -1)
        # A thin dark fragment is not a corner dot.
        cv2.line(image, (230, 130), (230, 180), (0, 0, 0), 1)
        return image, expected

    def test_markers_inside_black_camera_border_are_found(self):
        image, expected = self.image()
        np.testing.assert_allclose(locate(image), expected, atol=0.1)

    def test_multiple_plausible_marks_require_review_instead_of_guessing(self):
        image, _ = self.image()
        cv2.circle(image, (260, 140), 7, (20, 20, 20), -1)
        with self.assertRaises(ValueError):
            locate(image)

    def test_known_positions_exclude_distant_dark_objects(self):
        image, expected = self.image()
        cv2.circle(image, (260, 140), 7, (20, 20, 20), -1)
        np.testing.assert_allclose(locate(image, expected_points=expected), expected, atol=0.1)
