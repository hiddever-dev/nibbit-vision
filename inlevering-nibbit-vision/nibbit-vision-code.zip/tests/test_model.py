"""Optional integration smoke check. Random weights prove wiring, not recognition."""
import importlib.util
import tempfile
import unittest
from pathlib import Path


@unittest.skipUnless(importlib.util.find_spec("torch") and importlib.util.find_spec("torchvision"), "Modelbibliotheken optioneel")
class ModelSmokeTest(unittest.TestCase):
    def test_forward_backward_checkpoint_and_inference(self):
        import torch
        from nibbit.model import build_model, load_model, predict
        import numpy as np
        torch.set_num_threads(2)
        torch.manual_seed(0)
        model = build_model(False, 64, 96)
        # Keep the integration test bounded while exercising both heads and overlapping targets.
        model.rpn._pre_nms_top_n = {"training": 60, "testing": 40}
        model.rpn._post_nms_top_n = {"training": 30, "testing": 20}
        masks = torch.zeros((2, 96, 96), dtype=torch.uint8)
        masks[0, 35:49, 10:86] = 1
        masks[1, 10:86, 40:54] = 1
        target = {"boxes": torch.tensor([[10, 35, 86, 49], [40, 10, 54, 86]], dtype=torch.float32),
                  "labels": torch.tensor([2, 1]), "masks": masks}
        model.train()
        losses = model([torch.rand(3, 96, 96)], [target])
        self.assertIn("loss_mask", losses)
        total = sum(losses.values())
        self.assertTrue(torch.isfinite(total))
        total.backward()
        self.assertIsNotNone(model.roi_heads.mask_predictor.mask_fcn_logits.weight.grad)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "random_test_only.pt"
            torch.save({"format": "nibbit-amodal-v1", "model": model.state_dict(),
                        "min_size": 64, "max_size": 96, "epoch": 0}, path)
            loaded, _ = load_model(path, torch.device("cpu"))
            predictions = predict(loaded, np.full((96, 96, 3), 150, dtype=np.uint8), torch.device("cpu"), 0.99)
            self.assertIsInstance(predictions, list)


if __name__ == "__main__":
    unittest.main()
