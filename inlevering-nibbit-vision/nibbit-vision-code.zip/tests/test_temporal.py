import json
import unittest
from urllib.request import Request, urlopen

import numpy as np

from nibbit.temporal import SceneConsensus
from nibbit.live_window import LiveWindow


def prediction(vertical=False, ghost=False):
    mask = np.zeros((100, 100), bool)
    if ghost:
        mask[5:10, 5:30] = True
    elif vertical:
        mask[20:80, 45:55] = True
    else:
        mask[45:55, 20:80] = True
    return dict(mask=mask, status='visible', score=.9)


class TemporalTests(unittest.TestCase):
    def test_stable_ids_when_crossed_sticks_change_order(self):
        c = SceneConsensus()
        a, b = prediction(), prediction(True)
        c.update([a, b])
        out = c.update([b, a])
        self.assertEqual([p['track_id'] for p in out], [1, 2])
        self.assertTrue(np.array_equal(out[0]['mask'], a['mask']))
        self.assertEqual(out[0]['temporal_hits'], 2)

    def test_isolated_ghost_and_brief_miss(self):
        c = SceneConsensus()
        for _ in range(5):
            c.update([prediction()])
        out = c.update([prediction(), prediction(ghost=True)])
        self.assertEqual(len(out), 1)
        out = c.update([])
        self.assertEqual(len(out), 1)
        self.assertTrue(out[0]['temporal_held'])
        self.assertEqual(c.update([]), [])

    def test_reset_and_bounded_support(self):
        c = SceneConsensus()
        for _ in range(12):
            out = c.update([prediction()])
        self.assertEqual(out[0]['temporal_hits'], 5)
        c.reset()
        self.assertEqual(c.frames, 0)
        self.assertEqual(c.tracks, [])
        self.assertTrue(c.update([prediction()])[0]['temporal_provisional'])

    def test_unknown_length_stays_unknown(self):
        c = SceneConsensus()
        for value in (50., 51., 99.):
            rows = [dict(id=1, length_mm=value)]
            c.smooth_lengths(rows)
        self.assertEqual(rows[0]['length_mm'], 51.)
        rows = [dict(id=1, length_mm=None)]
        c.smooth_lengths(rows)
        self.assertIsNone(rows[0]['length_mm'])

    def test_browser_reset_rejects_inflight_result(self):
        w = LiveWindow(launch=False)
        try:
            frame = np.zeros((20, 20, 3), np.uint8)
            w.show(frame, [], 1., analyses=4, expected_generation=0)
            urlopen(Request(w.url+'action', data=b'r', method='POST')).close()
            self.assertEqual(w.generation, 1)
            w.show(frame, [], 1., analyses=5, expected_generation=0)
            with urlopen(w.url+'state') as response:
                state = json.load(response)
            self.assertEqual(state['analyses'], 0)
            self.assertEqual(state['rows'], [])
            w.show(frame, [], 1., analyses=1, expected_generation=1)
            self.assertEqual(w.state['analyses'], 1)
        finally:
            w.close()
